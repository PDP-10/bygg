/*
** routines in sysdep.c:
*/

extern int sy_getgmtoffset(void);
extern char* sy_getsystem(void);
