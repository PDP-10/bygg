/*
   Copyright (c) 2015-2018, Johnny Eriksson
   All rights reserved.

   Redistribution and use in source and binary forms, with or without
   modification, are permitted provided that the following conditions
   are met:

   1. Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

   2. Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in the
      documentation and/or other materials provided with the distribution.

   THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
   "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
   LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
   FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
   COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
   INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
   BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
   OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
   AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
   OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
   THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH
   DAMAGE.
*/

#include <ctype.h>
#include <signal.h>
#include <stddef.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

#include <pcap/pcap.h>

#include <pthread.h>

/*
 *  Saved packet, used for restoring the time line of traffic.
 */

#define PKTMAX 1500		/* Max saved packet data. */

typedef struct packet {		/* Saved packet: */
  struct packet*  pkt_next;	/*   Next in list. */
  struct sb*      pkt_source;	/*   Packet source. */
  int             pkt_ttl;	/*   Number of 'ticks' until printout. */
  struct pcap_pkthdr pkt_header; /* Header from PCAP. */
  u_char          pkt_data[PKTMAX]; /* Copy of data. */
} pkt;

/* Do NOT rearrange the following: */

enum {				/* Packet types: */
  D_NULL,			/*   None we know of. */
  D_DDCMP_TCP,			/*   DDCMP in TCP. */
  D_DDCMP_UDP,			/*   DDCMP in UDP. */
  D_MULTI_TCP,			/*   Multinet in TCP. */
  D_BRIDGE_UDP,			/*   HECnet bridge, UDP. */
  D_ETHER_ANF,			/*   ANF-10 over ethernet. */
  D_ETHER_DEC,			/*   DECnet over ethernet. */
  D_ETHER_LAT,			/*   LAT over ethernet. */
  D_ETHER_MOP,			/*   MOP over ethernet. */
};

/* How to print (DDCMP) frames: */

enum {
  PRINT_NONE,			/* None specified. */
  PRINT_ANF10,			/* ANF-10. */
  PRINT_DECNET,			/* DECnet. */
  PRINT_HEX,			/* HEX data. */
};

struct ep {
  struct ep* ep_next;
  u_short    ep_proto;
};

struct sb {			/* Source block: */
  struct sb* sb_next;		/*   Next in line. */
  u_short    sb_flags;		/*   Flags. */
#   define  SBF_FILE   0x0001	/*     -r <file> in progress. */
#   define  SBF_NOCRC  0x0002	/*     DDCMP w/o CRC bytes. */
  u_short    sb_print;		/*   How to print data. */
  u_short    sb_dtype;		/*   Data type. */
  u_short    sb_proto;		/*   TCP/UDP port or eth. protocol. */
  u_short    sb_ltype;		/*   Link type. */
  struct ep* sb_plist;		/*   Ethernet protocol list. */
  char*      sb_iface;		/*   Interface to use. */
  pcap_t*    sb_ph;		/*   PCAP handle. */
  pthread_t  sb_thread;		/*   Thread handle. */
};

/* Map unsigned values to strings: */

struct i2s {
  u_int i;
  char* s;
};

char* interface = NULL;

int linktype;			/* Data link type. */
u_short dtype = D_ETHER_ANF;
u_short proto = 0x6016;		/* (Ethernet) protocol. */
struct ep* plist = NULL;	/* Accumulated list. */
int argflag = 0;		/* Seen start of subcommand? */
int brgflag = 0;		/* Seen -b? */

pkt* outqueue = NULL;		/* Queue of packets to print. */

struct sb* currsb;		/* Source of current packet. */

struct sb* sbhead = NULL;	/* List of things to listen to. */
int sbcount = 0;		/* Count of them. */
int gotint = 0;			/* Seen -i? */

pkt* pkt_freelist = NULL;	/* List of unused packets. */
int pk_count = 0;               /* Count of packets malloc()ed. */
int pk_free = 0;                /* Count of free packets. */
int pk_alloc = 0;               /* Count of packet allocs. */

char* programname;              /* What we were called as. */

time_t gmtdiff;			/* Diff from gmt. */

pthread_t qthread;		/* Handle for qmgr thread. */
pthread_cond_t qstart;		/* Signal queue got non-empty. */
pthread_mutex_t dblock;		/* Database lock. */

u_char defprint = PRINT_NONE;	/* Default print of DDCMP. */

u_char colourflag = 0;		/* Use colours for output. */
u_char monitorflag = 0;		/* Monitor mode when writing file. */
u_char verbose = 0;		/* Verbose level. */
u_char debug = 0;		/* Debug flag. */
u_char xxflag = 0;		/* Dump data flag. */

char* filename = NULL;		/* -r argument. */
char* outname = NULL;		/* -w argument. */
int oftype;			/* Data link type of -w file. */
pcap_dumper_t* outfile = NULL;	/* Dump file we are writing to. */

char errbuf[PCAP_ERRBUF_SIZE];

/*
 *  The rest of our variables are used when deconstructing packets.
 *
 *  Should be used by one thread at a time, and protected with DB mutex.
 */

u_int sec, usec;		/* Time stamp from packet. */
u_char* packet;			/* Full (?) packet. */
int caplen;			/* Captured length. */

u_char* pptr;			/* pkt pointer, moves while we parse. */
int plen;			/* len of data left in above. */

u_char* xxptr;			/* -X pointer. */
int xxlen;			/* -X length. */

u_char* ethdst;			/* Ethernet destination addr. */
u_char* ethsrc;			/* Ethernet source addr. */
int ethtyp;			/* Ethernet type code. */
int ethlen;			/* Ethernet payload length. */

u_char* ip4hdr;			/* IPv4 header. */
u_char* ip4dst;			/* IPv4 destination addr. */
u_char* ip4src;			/* IPv4 source addr. */
u_char  ip4proto;		/* IPv4 protocol. */
u_short ip4dport;		/* IPv4 destination port. */
u_short ip4sport;		/* IPv4 source port. */

u_char* tcphdr;
u_char* udphdr;

/*
 *  ANF-10 thingies:
 */

u_char NCT;			/* NCT byte. */
#  define NCT_TYPE 0x07		/*   Three bits of type field. */
#    define NCTT_DATA     0	/*     Data message. */
#    define NCTT_ACK      1	/*     ACK. */
#    define NCTT_NAK      2	/*     NAK. */
#    define NCTT_REP      3     /*     REP. */
#    define NCTT_START    4	/*     START. */
#    define NCTT_STACK    5	/*     STACK. */
#    define NCTT_NODEID   6	/*     NODE-ID. */
#    define NCTT_UNUSED   7	/*     unused. */
#    define NCTT_CONTROL  8	/*     (pseudo-type) num. control. */
#  define NCT_RH   0x08		/*   SNA/DNA present. */
#  define NCT_TR   0x10		/*   Trace. */
#  define NCT_IT   0x20		/*   Interrupt. */
#  define NCT_SQ   0x40		/*   Sequential node. */
#  define NCT_EX   0x80		/*   Extensible bit (not used). */

#define STRSIZE 128		/* Should handle better. */

u_char TYPE;			/* Extracted type code. */

int SNA, DNA;			/* Source and destination nw addr. (opt) */
int NCA, NCN;			/* NW control ack and number. */

int SLA;			/* Source link address. */
int DLA;			/* Destination link address. */

int RSN;
int HST;
int DQR;
int OBJ;
int NDV;

char PID[STRSIZE];
int PLN;

int MML;
int RLN;
int DVT;
int DVU;
int DVV;

char DFT[STRSIZE];		/* "forms type" (connect) */

int NNUM;			/* Node number. (START/NODEID) */
int NVR;			/* NCL version. (START/NODEID) */
int NIT;			/* NodeID type. (NODEID) */
#  define NIT_PP 0		/*   Point-to-point link. */
#  define NIT_BC 1		/*   Broadcast link. */

int NIS;			/* NodeID sequence number. (NODEID) */

char SNM[STRSIZE];		/* System name. (START/NODEID) */
char SID[STRSIZE];		/* System ID.   (START/NODEID) */
char DAT[STRSIZE];		/* System date. (START/NODEID) */

/*
 *  DECnet thingies:
 */

u_char d_vers;			/* Three-octet version/ECO/uECO. */
u_char d_ECO;
u_char d_uECO;

/* do more of these. */

/* ********************************************************************** */

struct i2s lat_cmds[] = {
  {  0, "Run" },
  {  1, "Start" },
  {  2, "Stop" },
  { 10, "Service" },
  { 12, "Command" },
  { 13, "Status" },
  { 14, "Solicit" },
  { 15, "Response" },
  { 0, NULL },
};

/* ********************************************************************** */

/*
 *  General printout routines:
 */

void timestamp(void)
{
  u_int s = (sec + gmtdiff) % 86400;
  u_int us = usec;

  printf("%02d:%02d:%02d.%06u ", s/3600, (s%3600)/60, s%60, us);
}

/*
 *  Check a mac address for being decnet-style:
 */

int is_dnmac(u_char* mac)
{
  static u_char HIORD[4] = { 0xaa, 0x00, 0x04, 0x00 };

  return memcmp(mac, HIORD, 4) == 0;
}

/*
 *  Print a 16-bit number as DECnet area and node number:
 */

void printnode(u_short node)
{
  printf("%d.%d", node >> 10, node & 0x03ff);
}

void printmac(u_char* mac)
{
  printf("%02x:%02x:%02x:%02x:%02x:%02x",
	 mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);
}

void printdnmac(u_char* mac)
{
  static u_char HIORD[4] = { 0xaa, 0x00, 0x04, 0x00 };
  u_short node;

  node = mac[4] + (mac[5] << 8);
  printmac(mac);

  if (memcmp(mac, HIORD, 4) == 0) {
    printf(" (");
    printnode(node);
    printf(")");
  }
}

void printipa(u_char* ipa)
{
  printf("%d.%d.%d.%d", ipa[0], ipa[1], ipa[2], ipa[3]);
}

/*
 *  Convert an unsigned int to a string:
 */

char* i2s(u_int i, struct i2s* x, char* urk)
{
  while (x->s != NULL) {
    if (x->i == i)
      return x->s;
    x++;
  }
  return urk;
}

/*
 *  Allocate a packet to queue up, and copy current data to it.
 */

pkt* pkt_alloc(struct sb* s, struct pcap_pkthdr* h, u_char* data)
{
  pkt* p;
  int len;

  pk_alloc += 1;
  if (pkt_freelist != NULL) {
    p = pkt_freelist;
    pkt_freelist = p->pkt_next;
    pk_free -= 1;
  } else {
    p = malloc(sizeof(struct packet));
    pk_count += 1;
  }

  len = h->caplen;
  if (len > PKTMAX)
    len = PKTMAX;

  p->pkt_next = NULL;
  p->pkt_source = s;
  p->pkt_ttl = 2;
  (void) memcpy(&p->pkt_header, h, sizeof(struct pcap_pkthdr));
  (void) memcpy(&p->pkt_data, data, len);

  return p;
}

/*
 *  Deallocate a packet, i.e. put it on the free list.
 */

void pkt_free(pkt* p)
{
  pk_free += 1;
  p->pkt_next = pkt_freelist;
  pkt_freelist = p;
}

/*
 *  Routines to pick data apart:
 */

u_char getbyte(void)
{
  if (plen-- < 0)
    return 0;
  return *pptr++;
}

u_short getword(void)
{
  u_short word;

  word = getbyte();
  word += getbyte() << 8;

  return word;
}

u_int getebi(void)
{
  unsigned int num, shift;
  u_char c;

  num = 0;
  shift = 0;

  for (;;) {
    c = getbyte();
    num += (c & 0x7f) << shift;
    if (!(c & 0x80))
      return num;
    shift += 7;
  }
}

int geteascii(char* str)
{
  u_char c;
  int i;

  for  (i = 1;; i += 1) {
    c = getbyte();
    if (i < STRSIZE)
      *str++ = c & 0x7f;
    if (!(c & 0x80)) {
      *str = 0;
      return i;
    }
  }
}

void getfeat(void)
{
  MML = getebi();
  RLN = getebi();
  DVT = getebi();
  DVU = getebi();
  DVV = getebi();
  (void) geteascii(DFT);
}

/*
 *  DECnet parsing routines:
 */

void getvers(void)
{
  d_vers = getbyte();
  d_ECO = getbyte();
  d_uECO = getbyte();
}

u_char* getptr(u_int length)
{
  u_char* ptr;

  ptr = pptr;
  pptr += length;
  plen -= length;

  return ptr;
}

/*
 *  For an ethernet protocol that uses DEC packet padding, pick up
 *  the embedded length field and update our variables.
 */

void eth_getlength(void)
{
  u_short length;

  length = getbyte();
  length += getbyte() << 8;

  if (plen > length)
    plen = length;
}

char hex[16] = "0123456789abcdef";

void dumphex(u_char* p, int len)
{
  u_char c;
  int i, j;

  for (i = 0; i < len; i += 16) {
    printf("    ");
    for (j = i; j < (i + 16); j += 1) {
      if ((j & 15) == 8) {
	putchar(' ');
      }
      if (j < len) {
	c = p[j];
	putchar(hex[c >> 4]);
	putchar(hex[c & 15]);
	putchar(' ');
      } else {
	printf("   ");
      }
    }
    printf("  |");
    for (j = i; j < (i + 16); j += 1) {
      if (j < len) {
	c = p[j];
	if ((c < 32) || (c >= 127)) {
	  c = ' ';
	}
	putchar(c);
      } else {
	putchar(' ');
      }
    }    
    printf("|\n");
  }
}

void xxdump(void)
{
  if (xxlen <= 0)
    return;

  switch (xxflag) {
  case 1:
    printf("  Protocol data:\n");
    dumphex(xxptr, xxlen);
    break;
  case 2:
    printf(" Packet data:\n");
    dumphex(xxptr, xxlen);
    break;
  }
}

char* msgtyp(int typ) {
  switch (typ) {
  case 0: return "DATA";
  case 1: return "ACK";
  case 2: return "NAK";
  case 3: return "REP";
  case 4: return "START";
  case 5: return "STACK";
  case 6: return "NODEID";
    /* this is unused */
  case 8: return "CONTROL";
  default: return "???";
  }
}

char* objname(int obj)
{
  static char foo[20];

  switch (obj) {
  case 0: return "MCR";
  case 1: return "TTY";
  case 2: return "CDR";
  case 3: return "LPT";
  case 4: return "PTR";
  case 5: return "PTP";
  case 6: return "PLT";
  case 7: return "MTA";
  case 8: return "DTA";
  case 9: return "TSK";
  case 10: return "RDA";
  case 11: return "CDP";
  case 12: return "DDP";
  default:
    sprintf(foo, "<%d>", obj);
    return foo;
  }
}

char* ddcmp_nak_name(int reason)
{
  switch (reason) {
  case 1:  return "hdr CRC error";
  case 2:  return "data CRC error";
  case 3:  return "REP response";
  case 8:  return "buffer unav.";
  case 9:  return "xcvr overrun";
  case 16: return "msg too long";
  case 17: return "hdr fmt error";
  }
  return "unknown";
}

char* opname[] = {
  "",				/* 0 */
  "connect",			/* 1 */
  "disconnect",			/* 2 */
  "neighbours",			/* 3 */
  "request config",		/* 4 */
  "configuration",		/* 5 */
  "data request",		/* 6 */
  "station id",			/* 7 */
};

void anf_print_staxx(void)
{
  printf("  Node %o (%s), %s %s\n", NNUM, SNM, SID, DAT);
  printf("  NCL version %d\n", NVR);
}

void anf_print_nodeid(void)
{
  printf("  Node %o (%s), %s %s\n", NNUM, SNM, SID, DAT);
  printf("  NCL version %d, ", NVR);
  switch (NIT) {
  case NIT_PP:
    printf("P-T-P link.\n");
    break;
  case NIT_BC:
    printf("Broadcast link, seq = %d\n", NIS);
    break;
  default:
    printf("link type %d\n", NIT);
    break;
  }
}

void anf_print_conn_args(char* head)
{
  int i;
  u_char c;

  OBJ = getebi();
  PLN = geteascii(PID);

  printf("  %s OBJ = %d (%s), PID = ", head, OBJ, objname(OBJ));
  for (i = 0; i < PLN; i += 1) {
    c = PID[i];
    printf("%02x ", c);
    if ((c < 32) || (c >= 177)) {
      PID[i] = ' ';
    }
  }
  printf(" (%s)\n", PID);
}

void anf_print_feat(void)
{
  getfeat();
  printf("  MML = %d, RLN = %d, DVT = %d, DVU = %d, DVV = %d, DFT = '%s'\n",
	 MML, RLN, DVT, DVU, DVV, DFT);
}

void anf_print_control(void)
{
  int len, op;

  len = getebi();
  op = getebi();

  printf("  len = %d, op = %d (%s)",
	 len, op, ((op < 1) && (op > 7))? "unknown" : opname[op]);

  switch (op) {
  case 1:			/* Connect */
    DLA = getebi();
    SLA = getebi();
    printf(", DLA = %d, SLA = %d\n", DLA, SLA);
    anf_print_conn_args("dst");
    anf_print_conn_args("src");
    anf_print_feat();
    break;
  case 2:			/* Disconnect */
    DLA = getebi();
    SLA = getebi();
    RSN = getebi();
    printf(", DLA = %d, SLA = %d, RSN = %d", DLA, SLA, RSN);
    if (RSN == 010) {
      HST = getebi();
      printf(", HST = %o", HST);
    }
    printf("\n");
    break;
  case 3:			/* Neighbours */
    printf("\n");
    while (plen > 0) {
      printf("  Neighbour %o", getebi());
      printf("(%u)\n", getebi());
    }
    break;
  case 4:			/* Request config */
    printf("\n");		/* (has no parameters) */
    break;
  case 5:			/* Configuration */
    printf("\n   ");
    while (plen > 0) {
      OBJ = getebi();
      NDV = getebi();
      (void) getebi();		/* XXX what is this? */
      printf(" %s[%d]", objname(OBJ), NDV);
    }
    printf("\n");
    break;
  case 6:			/* Data request */
    DLA = getebi();
    DQR = getebi();
    printf(", DLA = %d, DQR = %d\n", DLA, DQR);
    break;
  case 7:			/* Station ID */
    /* This needs work. */
    printf("\n");
    break;
  default:
    printf("\n");
  }
  dumphex(pptr, plen);
  while (plen-- > 0)
    (void) getbyte();
}

void anf_print_data(void)
{
  if (DLA == 0) {
    while (plen > 0) {
      anf_print_control();
    }
  } else {
    dumphex(pptr, plen);
  }
}

/*
 *  Print a datagram as ANF-10:
 */

void anf_print(void)
{
  u_char* anfdata = pptr;
  int anflen = plen;

  /* XXX Check packet length for all of ANF data bytes? */

  NCA = 0; NCN = 0;

  NCT = getbyte();
  if (NCT & NCT_RH) {
    /*
     * XXX  The spec (netprm.mac) claims SNA comes first.  It seems
     * XXX  that the spec is wrong here...
     */
    DNA = getebi();
    SNA = getebi();
  }
  NCA = getbyte();
  NCN = getbyte();

  TYPE = NCT & NCT_TYPE;

  switch (TYPE) {
  case NCTT_DATA:
    DLA = getebi();
    if (DLA == 0)
      TYPE = NCTT_CONTROL;	/* Pseudo-type. */
    break;
  case NCTT_START:
  case NCTT_STACK:
    NNUM = getebi();
    (void) geteascii(SNM);
    (void) geteascii(SID);
    (void) geteascii(DAT);
    NVR = getebi();
    break;
  case NCTT_NODEID:
    NNUM = getebi();
    (void) geteascii(SNM);
    (void) geteascii(SID);
    (void) geteascii(DAT);
    NIT = getbyte();
    if (NIT == NIT_BC) {
      NIS = getebi();
    }
    NVR = getebi();
    break;
  }

  /* Now pointing to (more or less) data. */

  printf("  %s", msgtyp(TYPE));
  if (NCT & NCT_RH) printf(", RH");
  if (NCT & NCT_TR) printf(", TR");
  if (NCT & NCT_IT) printf(", IT");
  if (NCT & NCT_SQ) printf(", NSQ");
  if (NCT & NCT_EX) printf(", EX");
  
  if (NCT & NCT_RH) {
    printf(", src = %o, dst = %o", SNA, DNA);
  }
  printf(", NCA = %u, NCN = %u", NCA, NCN);
  if (TYPE == NCTT_DATA)
    printf(", DLA = %d", DLA);
  printf("\n");

  switch (TYPE) {
  case NCTT_DATA:
  case NCTT_CONTROL:
    anf_print_data();
    return;
  case NCTT_ACK:
  case NCTT_NAK:
  case NCTT_REP:
    break;
  case NCTT_STACK:
  case NCTT_START:
    anf_print_staxx();
    break;
  case NCTT_NODEID:
    anf_print_nodeid();
    break;
  case NCTT_UNUSED:
    dumphex(anfdata, anflen);
    return;
  }

  /* Get here, dump rest of data (if any) in hex. */

  dumphex(pptr, plen);
}

/*
 *  Decode and print a DECnet routing vector:
 */

void dcn_print_routing(u_char level)
{
  u_short node, start, count, info;
  char* type = (level == 1) ? "node" : "area";

  node = getword();

  (void) getbyte();

  printf("  Routing (level %d), ", level);
  printnode(node);
  printf("\n");

  while (plen > 2) {
    count = getword();
    start = getword();
    printf("    %s %d - %d\n", type, start, start + count - 1);

    if (verbose > 0) {
      for (node = start; count-- > 0; node += 1) {
	info = getword();
	if (info != 0x7fff) {
	  printf("      %s %d: cost %d hops %d\n", type, node,
		 info & 0x3f, info >> 10);
	}
      }
    } else {
      (void) getptr(2 * count);
    }
  }
  info = getword();		/* Checksum. */
}

/*
 *  Decode and print ethernet hello messages:
 */

void dcn_print_eth_hello(u_char endnode)
{
  u_char info, prio;
  u_char* xid;
  u_char* neighb;
  u_short bsiz, timr;

  getvers();
  xid = getptr(6);
  info = getbyte();
  bsiz = getword();

  if (!endnode) {
    prio = getbyte();
  }

  (void) getbyte();		/* area, should be zero. */

  if (endnode) {
    (void) getptr(8);		/* Skip eight-byte seed. */
    neighb = getptr(6);
  }

  timr = getword();

  (void) getbyte();		/* MPD. */
  
  if (endnode)
    printf("  Ethernet endnode hello, ");
  else
    printf("  Ethernet hello, ");

  printdnmac(xid);
  printf("\n");
  printf("   info %d size %d ver %d/%d/%d timer %d",
	 info, bsiz, d_vers, d_ECO, d_uECO, timr);
  if (endnode) {
    printf(", router ");
    printdnmac(neighb);
  } else {
    printf(", prio %d", prio);
  }

  printf("\n");

  if (verbose > 0 && !endnode) {
    (void) getptr(8);		/* Skip length & ID fields. */
    (void) getbyte();
    while (plen > 0) {
      xid = getptr(6);
      prio = getbyte();
      printf("    router ");
      printdnmac(xid);
      printf(" prio %d\n", prio & 0x7f);
    }
  }
}

/*
 *  We got a decnet control message.  Decode it.
 */

void dcn_print_control(u_char flags)
{
  u_char ctype = (flags & 0x0e) >> 1;
  u_char info;
  u_short bsiz, timr;
  u_short node;

  switch (ctype) {
  case 0:
    node = getword();
    info = getbyte();
    bsiz = getword();
    getvers();
    timr = getword();
    /* single zero byte here? */    
    printf("  Init, ");
    printnode(node);
    printf(" info %d size %d ver %d/%d/%d timer %d\n",
	   info, bsiz, d_vers, d_ECO, d_uECO, timr);
    break;
  case 1:
    node = getword();
    /* can have an image field */
    printf("  Verification, ");
    printnode(node);
    printf("\n");
    break;
  case 2:
    node = getword();
    /* test data, image field */
    printf("  Hello/test, ");
    printnode(node);
    printf("\n");
    break;
  case 3:
    dcn_print_routing(1);
    break;
  case 4:
    dcn_print_routing(2);
    break;
  case 5:
    dcn_print_eth_hello(0);
    break;
  case 6:
    dcn_print_eth_hello(1);
    break;
  default:
    printf("  Unknown control message (%d)\n", ctype);
    break;
  }
}

/* ********************************************************************** */

/*
 *  NSP routines.
 */

void nsp_ports(void)
{
  u_short dst, src;

  dst = getword();
  src = getword();

  printf(", %d > %d", dst, src);
}

struct i2s ack_name[] = {
  { 0, "ack" },
  { 1, "nak" },
  { 2, "xack" },
  { 3, "xnak" },
  { 0, NULL },
};

void nsp_ack_seg(void)
{
  u_short word;
  u_char ack;

  word = getword();
  if (word & 0x8000) {
    word &= 0x7fff;
    ack = word >> 12;
    printf(", %s %d", i2s(ack, ack_name, "?ack"), word);
    word = getword();
  }
  if (word & 0x8000) {
    word &= 0x7fff;
    ack = word >> 12;
    printf(", %s %d", i2s(ack, ack_name, "?ack"), word);
    word = getword();
  }
  printf(", seg %d", word & 0x0fff);
}

void nsp_ack(void)
{
  u_short word;
  u_char ack;

  word = getword();
  word &= 0x7fff;
  ack = word >> 12;
  printf(", %s %d", i2s(ack, ack_name, "?ack"), word);

  word = getword();
  if (word & 0x8000) {
    word &= 0x7fff;
    ack = word >> 12;
    printf(", %s %d", i2s(ack, ack_name, "?ack"), word);
  }  
}

void nsp_cinfo(void)
{
  u_char srv, inf;
  u_short siz;

  static struct i2s srv_names[] = {
    { 0x04, " (seg)" },
    { 0x08, " (msg)" },
    { 0, NULL },
  };

  static struct i2s inf_names[] = {
    { 0, "3.2" },
    { 1, "3.1" },
    { 2, "4.0" },
    { 3, "4.1" },
    { 0, NULL },
  };

  srv = getbyte();
  inf = getbyte();
  siz = getword();

  printf(", srv %d%s", srv, i2s(srv & 0x0c, srv_names, ""));
  printf(", info %d (%s)", inf, i2s(inf & 3, inf_names, ""));
  printf(", size %d", siz);
}

/*
 *  Print an NSP data segment.
 */

void nsp_print_data(u_char msgflg)
{
  printf("   data");
  if (msgflg & 0x20)
    printf(", bm");
  if (msgflg & 0x40)
    printf(", em");

  nsp_ports();
  nsp_ack_seg();

  printf(", length %d\n", plen);
  if (verbose > 0) {
    dumphex(pptr, plen);
  }
}

void nsp_print_lsrv(void)
{
  printf("   lserv");
  nsp_ports();
  nsp_ack_seg();

  printf(", lsflags 0x%02x", getbyte());
  printf(", fcval %d", getbyte());

  printf("\n");

  /* should not have any data. */
  dumphex(pptr, plen);
}

void nsp_print_int(void)
{
  printf("   interrupt-data");
  nsp_ports();
  nsp_ack_seg();

  printf(", length %d\n", plen);
  if (verbose > 0) {
    dumphex(pptr, plen);
  }
}

void nsp_print_ack(void)
{
  printf("   ack");
  nsp_ports();
  nsp_ack();
  printf("\n");

  /* should not have any data. */
  dumphex(pptr, plen);
}

void nsp_print_oack(void)
{
  printf("   o-ack");
  nsp_ports();
  nsp_ack();
  printf("\n");

  /* should not have any data. */
  dumphex(pptr, plen);
}

void nsp_print_cack(void)
{
  printf("   conn-ack, %d\n", getword());

  /* should not have any data. */
}

void nsp_print_noop(void)
{
  printf("   noop, length %d\n", plen);

  /* this is test data. */
  if (verbose > 0) {
    dumphex(pptr, plen);
  }
}

void pistring(u_char maxlen, u_char show)
{
  u_char len = getbyte();
  u_char c;

  putchar('"');
  while (len-- > 0) {
    c = getbyte();
    if (isprint(c) && show)
      putchar(c);
    else
      putchar('.');
  }
  putchar('"');
}

struct i2s dcn_obj_name[] = {
  {  1, "DAPv1" },
  {  2, "URD" },
  {  3, "ATS" },
  {  4, "CTS" },
  {  5, "RSX-11M Task Control 1" },
  {  6, "Operator Services Interface" },
  {  7, "Node Resource Manager" },
  {  8, "IBM 3270-BSC Gateway" },
  {  9, "IBM 2780-BSC Gateway" },
  { 10, "IBM 3790-SDLC Gateway" },
  { 11, "TPS Application" },
  { 12, "RT-11 DIBOL Application" },
  { 13, "Tops Terminal Handler" },
  { 14, "Tops Remote Spooler" },
  { 15, "RSX-11M Task Control 2" },
  { 16, "TLK Utility" },
  { 17, "DAPv4" },
  { 18, "RSX-11S Remote Task Loader" },
  { 19, "NICE" },
  { 20, "RSTS/E Media Transfer Program (NETCPY)" },
  { 21, "RSTS/E Homogeneous Network Command Terminal Handler" },
  { 22, "Mail-11" },
  { 23, "Host Terminal" },
  { 24, "Concentrator Terminal Handler" },
  { 25, "Loopback Mirror" },
  { 26, "Event Receiver" },
  { 27, "VAX/VMS Personal Message Utility" },
  { 28, "FTS" },
  { 29, "PHONE" },
  { 30, "Distributed Data Management Facility (DDMF)" },
  { 31, "X.25 Gateway Server" },
  { 32, "UETP" },
  { 33, "VAX/VMS MAIL Utility" },
  { 34, "X.29 Terminal Server" },
  { 35, "Calendar system" },
  { 36, "X.25 Gateway access" },
  { 37, "SNA Gateway access" },
  { 38, "SNA RJE Utility" },
  { 42, "CTERM" },
  { 66, "Distributed Queuing Service" },
  { 123, "PSTHRU" },
  { 201, "MS server" },
  { 0, NULL },
};

void pciuser(void)
{
  u_char fmt = getbyte();
  u_char obj;
  char* objn;
  u_short grp, usr;

  switch (fmt) {
  case 0:
    obj = getbyte();
    printf(" obj %d", obj);
    objn = i2s(obj, dcn_obj_name, NULL);
    if (objn != NULL)
      printf(" (%s)", objn);
    break;
  case 1:
    (void) getbyte();		/* zero byte (obj type) */
    pistring(16, 1);
    break;
  case 2:
    (void) getbyte();		/* zero byte (obj type) */
    grp = getword();
    usr = getword();
    printf(" grp %o usr %o, ", grp, usr);
    pistring(16, 1);
    break;
  default:
    break;
  }
  printf("\n");
}

void printbits(u_int bits, struct i2s* names)
{
  int n = 0;

  if (bits != 0) {
    printf(" (");
    while (names->i != 0) {
      if (names->i & bits) {
        if (n++ > 0)
          printf(", ");
        printf("%s", names->s);
      }
      names++;
    }
    printf(")");
  }
}

struct i2s bits_menuver[] = {
  { 0x01, "userid, passwd, account" },
  { 0x02, "userdata" },
  { 0, NULL },
};

void nsp_print_cinit(u_char rexmit)
{
  u_char menuver;

  if (rexmit)
    printf("   resent connect");
  else
    printf("   connect");
  nsp_ports();
  nsp_cinfo();

  printf(", length %d\n", plen);

  /*  Data is in three parts:
   *  - destination "user"
   *  - source "user"
   *  - bit map of optional fields + session ctrl version.
   */

  if (verbose < 1)
    return;

  printf("    dst user:");
  pciuser();
  printf("    src user:");
  pciuser();
  menuver = getbyte();
  printf("    bits: %02x", menuver);
  printbits(menuver, bits_menuver);
  printf("\n");

  if (verbose < 2)
    return;

  if (menuver & 0x01) {
    printf("      username: "); pistring(39, 1); printf("\n");
    printf("      password: "); pistring(39, 0); printf("\n");
    printf("      account:  "); pistring(39, 1); printf("\n");
  }
  if (menuver & 0x02) {
    /* user data present */
  }
  
  if (verbose > 0) {
    dumphex(pptr, plen);
  }
}

void nsp_print_cconf(void)
{
  printf("   conn-cfm");
  nsp_ports();
  nsp_cinfo();

  printf(", length %d\n", plen);
  if (verbose > 0) {
    /* image string here. */
    dumphex(pptr, plen);
  }
}

void nsp_print_dinit(void)
{
  printf("   disconnect");
  nsp_ports();
  printf(", reason %d", getword());
  printf("\n");

  if (verbose > 0) {
    /* image string here. */
    dumphex(pptr, plen);
  }
}

void nsp_print_dconf(void)
{
  printf("   disc. confirm");
  nsp_ports();
  printf(", reason %d", getword());
  printf("\n");

  /* should not have any data. */
  dumphex(pptr, plen);
}

void dcn_print_nsp(void)
{
  u_char msgflg = getbyte();

  switch (msgflg) {
  case 0x00:			/* Data: */
  case 0x20:
  case 0x40:
  case 0x60:
    nsp_print_data(msgflg);
    break;
  case 0x10:			/* Link service: */
    nsp_print_lsrv();
    break;
  case 0x30:			/* Interrupt data: */
    nsp_print_int();
    break;
  case 0x04:			/* Data ack: */
    nsp_print_ack();
    break;
  case 0x14:			/* Other data ack: */
    nsp_print_oack();
    break;
  case 0x24:			/* Connect ack: */
    nsp_print_cack();
    break;
  case 0x08:			/* No-op: */
    nsp_print_noop();
    break;
  case 0x18:			/* Connect: */
    nsp_print_cinit(0);
    break;
  case 0x28:			/* Connect confirm: */
    nsp_print_cconf();
    break;
  case 0x38:			/* Disconnect: */
    nsp_print_dinit();
    break;
  case 0x48:			/* Disconnect confirm: */
    nsp_print_dconf();
    break;
  case 0x68:			/* Resent connect: */
    nsp_print_cinit(1);
    break;
  case 0x58:			/* reserved (phase II node init). */
  default:
    printf("   NSP type %d subtype %d len %d\n",
	   (msgflg & 0x0b) >> 2, (msgflg & 0x70) >> 4, plen);
    dumphex(pptr, plen);
    break;
  }
}

/*
 *  Print a DECnet short data message:
 */

void dcn_print_short(u_char flags)
{
  u_short src, dst;
  u_char inf;

  dst = getword();
  src = getword();
  inf = getbyte();

  printf("  DECnet data, short format, ");
  printnode(src);
  printf(" -> ");
  printnode(dst);
  if (flags & 0x10)
    printf(", RTS");
  if (flags & 0x08)
    printf(", RQR");
  printf(", hops %d\n", inf);

  dcn_print_nsp();
}

/*
 *  Print a DECnet long data message:
 */

void dcn_print_long(u_char flags)
{
  u_char* hdr;
  u_short src, dst;

  hdr = getptr(20);
  src = hdr[14] + (hdr[15] << 8);
  dst = hdr[6] + (hdr[7] << 8);

  printf("  DECnet data, long format, ");
  printnode(src);
  printf(" -> ");
  printnode(dst);
  if (flags & 0x20)
    printf(", I-E");
  if (flags & 0x10)
    printf(", RTS");
  if (flags & 0x08)
    printf(", RQR");

  printf(", hops %d\n", hdr[17]);
  
  //  dumphex(hdr, 20);

  dcn_print_nsp();
}

/*
 *  Print a DECnet message.
 */

void dcn_print(void)
{
  u_char flags;

  /* Check length here? */

  flags = getbyte();

  if (flags & 0x80) {		/* Padding? */
    flags &= 0x7f;
    while (flags > 1) {
      (void) getbyte();
      flags -= 1;
    }
    flags = getbyte();
  }

  if (flags & 0x01) {
    dcn_print_control(flags);
    return;
  }
  
  switch (flags & 0x07) {
  case 2:
    dcn_print_short(flags);
    break;
  case 6:
    dcn_print_long(flags);
    break;
  default:
    printf("  Unknown DECnet message format, flags %02x\n", flags);
    dumphex(pptr, plen);
    break;
  }
}

/*
 *  Print a MOP datagram:
 */

void mop_print(void)
{
  printf("  MOP datagram.\n");
}

/*
 *  Print a SCA datagram:
 */

void sca_print(void)
{
  printf("  SCA datagram.\n");
}

/*
 *  Print a LAT run data message:
 */

void lat_print_run(void)
{
  u_char nslots;
  u_short msgdid, msgsid, msgack;
  u_char sltdid, sltsid, sltcnt, slttcr;
  u_char* sltmsg;
  u_char slot;

  (void) getbyte();		/* Skip command byte. */
  nslots = getbyte();
  msgdid = getword();
  msgsid = getword();
  msgack = getword();

  printf(", sid %u did %u ack %u, %d slot(s)\n",
	 msgsid, msgdid, msgack, nslots);

  if (verbose == 0)
    return;

  for (slot = 0; slot < nslots; slot += 1) {
    sltdid = getbyte();
    sltsid = getbyte();
    sltcnt = getbyte();
    slttcr = getbyte();
    sltmsg = getptr(sltcnt);
    if (sltcnt & 1)
      (void) getbyte();
    printf("   slot %d src %d dst %d cnt %d tcr %02x\n",
	   slot, sltsid, sltdid, sltcnt, slttcr);
    dumphex(sltmsg, sltcnt);
  }

  /*
   *  Slot types:
   *
   *   0 - DATA A
   *   9 - Start
   *  10 - DATA B
   *  11 - Attention
   *  12 - Reject
   *  13 - Stop
   */
}

/*
 *  Print a LAT service announce message:
 */

void pcstring(u_char* name, u_char len)
{
  char c;

  putchar('"');
  while (len-- > 0) {
    c = *name++;
    if (isprint(c))
      putchar(c);
    else
      putchar('.');
  }
  putchar('"');
}

void lat_print_service(void)
{
  u_short node;

  u_char l_sct;
  u_char l_hpv, l_lpv, l_cpv, l_eco;
  u_char l_msginc;
  u_char l_cflags;
  u_short l_dlsize;
  u_char l_mtimer;
  u_char l_status;
  u_char l_grplen;
  u_char* l_groups;
  u_char l_namelen;
  u_char* l_name;
  u_char l_desclen;
  u_char* l_desc;
  u_char l_scount;
  u_char l_rating;

  (void) getbyte();
  l_sct = getbyte();
  l_hpv = getbyte();
  l_lpv = getbyte();
  l_cpv = getbyte();
  l_eco = getbyte();
  l_msginc = getbyte();
  l_cflags = getbyte();
  l_dlsize = getword();
  l_mtimer = getbyte();
  l_status = getbyte();
  l_grplen = getbyte();
  l_groups = getptr(l_grplen);
  l_namelen = getbyte();
  l_name = getptr(l_namelen);
  l_desclen = getbyte();
  l_desc = getptr(l_desclen);
  l_scount = getbyte();

  printf(", ");
  pcstring(l_name, l_namelen);
  if (is_dnmac(ethsrc)) {
    node = ethsrc[4] + (ethsrc[5] << 8);
    printf(" (");
    printnode(node);
    printf(")");
  }
  putchar('\n');

  if (verbose > 0) {
    printf("   Desc: ");
    pcstring(l_desc, l_desclen);
    printf("\n   proto %d/%d/%d, eco %d", l_lpv, l_hpv, l_cpv, l_eco);
    printf(", timer %d ms, mtu %d, srv count %d\n",
	   l_sct * 10, l_dlsize, l_scount);
  }

  if (verbose > 1) {
    while (l_scount-- > 0) {
      l_rating = getbyte();
      l_namelen = getbyte();
      l_name = getptr(l_namelen);
      l_desclen = getbyte();
      l_desc = getptr(l_desclen);
      printf("    %d ", l_rating);
      pcstring(l_name, l_namelen);
      printf(", ");
      pcstring(l_desc, l_desclen);
      printf("\n");
    }
  }
}

/*
 *  Print an ethernet frame as LAT data:
 */

void lat_print(void)
{
  u_char bits = pptr[0] & 0x03;
  u_char cmd =  pptr[0] >> 2;
  char* name = i2s(cmd, lat_cmds, NULL);

  printf("  LAT packet, cmd = %d", cmd);
  if (name != NULL)
    printf(" (%s)", name);

  if (bits != 0) {
    printf(", ");
    if (bits & 0x01)
      putchar('R');
    else
      putchar(' ');
    if (bits & 0x02)
      putchar('H');
  }

  /*
   *  We don't print a newline here, next level printer might want to
   *  put more information on this line.
   */

  switch (cmd) {
  case 0:
    lat_print_run();
    break;
  case 10:
    lat_print_service();
    break;
  default:
    putchar('\n');
    if (verbose > 0)
      dumphex(pptr, plen);
    break;
  }
}

/*
 *  Print an ethernet header.
 */

void print_eth_header(void)
{
  if (colourflag)
    printf("\033[31m");
  timestamp();
  if (interface != NULL)
    printf("%s ", interface);
  printf("ETH %04x ", ethtyp);
  printmac(ethsrc);
  printf(" > ");
  printmac(ethdst);
  printf(" len %d\n", ethlen);
  if (colourflag)
    printf("\033[39m");
}

/*
 *  Print out IP header information (and port numbers from the TCP/UDP
 *  header).
 */

void print_ip_header(char* msg)
{
  if (colourflag)
    printf("\033[34m");
  timestamp();
  if (interface != NULL)
    printf("%s ", interface);

  printf("%s ", msg);		/* TCP/UDP/... */
  printipa(ip4src);
  printf(".%d > ", ip4sport);
  printipa(ip4dst);
  printf(".%d len %d\n", ip4dport, plen);

  if (colourflag)
    printf("\033[39m");
}

/*
 *  Decode a DDCMP control message:
 */

void ddcmp_print_ctrl(void)
{
  int r;

  switch (plen) {
  case 6:
    currsb->sb_flags |= SBF_NOCRC;
    break;
  case 8:
    currsb->sb_flags &= ~SBF_NOCRC;
    break;
  }

  switch (pptr[1]) {
  case 1:
    printf(" ACK, ack=%d", pptr[3]);
    break;
  case 2:
    r = pptr[2] & 0x3f;
    printf(" NAK, rsn=%d (%s), ack=%d", r, ddcmp_nak_name(r), pptr[3]);
    break;
  case 3:
    printf(" REP, msg=%d", pptr[4]);
    break;
  case 6:
    printf(" START, msg=%d", pptr[4]);
    break;
  case 7:
    printf(" STACK, ack=%d, msg=%d", pptr[3], pptr[4]);
    break;
  default:
    printf(" CTRL (%d)", pptr[1]);
    break;
  }

  if (!(currsb->sb_flags & SBF_NOCRC)) {
    /* should check CRC here. */
  }

  printf("\n");

  if (xxflag == 1) {
    xxlen = 0;
  }
}

/*
 *  Decode a DDCMP data message:
 */

void ddcmp_print_data(void)
{
  int len = pptr[1] + ((pptr[2] & 0x3f) << 8);
		       
  printf(" DATA, ack=%d, msg=%d, len = %d", pptr[3], pptr[4], len);

  if (!(currsb->sb_flags & SBF_NOCRC)) {
    /* should check CRC's here. */
    pptr += 8;
    plen -= 10;
  } else {
    pptr += 6;
    plen -= 6;
  }
  printf("\n");

  if (xxflag == 1) {
    xxptr = pptr;
    xxlen = plen;
  }

  switch (defprint) {
  case PRINT_NONE:
    /* nothing to do here. */
    break;
  case PRINT_ANF10:
    anf_print();
    break;
  case PRINT_DECNET:
    dcn_print();
    break;
  case PRINT_HEX:
    dumphex(pptr, plen);
    break;
  }
}

/*
 *  Decode a DDCMP maint message:
 */

void ddcmp_print_maint(void)
{
  int len = pptr[1] + ((pptr[2] & 0x3f) << 8);

  printf(" MAINT, len =%d", len);

  if (!(currsb->sb_flags & SBF_NOCRC)) {
    /* should check CRC's here. */
    pptr += 8;
    plen -= 10;
  } else {
    pptr += 6;
    plen -= 6;
  }
  printf("\n");

  if (xxflag == 1) {
    xxptr = pptr;
    xxlen = plen;
  }
}

/*
 *  Print out the packet payload as DDCMP data.
 */

void ddcmp_print_frame(void)
{
  switch (pptr[0]) {
  case 0005:
    ddcmp_print_ctrl();
    break;
  case 0201:
    ddcmp_print_data();
    break;
  case 0220:
    ddcmp_print_maint();
    break;
  default:
    printf(" -- unknown DDCMP frame type (%o) --\n", pptr[0]);
    break;
  }
}

/*
 *  Print out a multinet frame, always DECnet.
 */

void multi_print_frame(void)
{
  int len = pptr[0] + (pptr[1] << 8) + (pptr[2] << 16) + (pptr[3] << 24);

  printf(" Multinet, len = %d\n", len);
  pptr += 4;
  plen -= 4;

  if (xxflag == 1) {
    xxptr = pptr;
    xxlen = plen;
  }

  dcn_print();			/* We only do decnet. */
}

/*
 *  Dispatch on type for an ethernet datagram.
 */

void disp_eth(struct sb* sb)
{
  switch (ethtyp) {
  case 0x6001:
  case 0x6002:
    eth_getlength();
    mop_print();
    break;
  case 0x6003:
    eth_getlength();
    dcn_print();
    break;
  case 0x6004:
    /* LAT does not use the DEC length padding... */
    lat_print();
    break;
  case 0x6007:
    eth_getlength();
    sca_print();
    break;
  case 0x6006:
  case 0x6016:
    eth_getlength();
    anf_print();
    break;
  default:
    //    printf(" Ether type unknown\n");
    break;
  }
}

void handle_bridge(struct sb* sb)
{
  struct ep* ep;

  ethdst = &pptr[0];
  ethsrc = &pptr[6];
  ethtyp = pptr[13] + (pptr[12] << 8);
  ethlen = plen;

  pptr += 14;
  plen -= 14;

  if (sb->sb_plist == NULL)
    goto match;

  for (ep = sb->sb_plist; ep != NULL; ep = ep->ep_next) {
    if (ep->ep_proto == ethtyp)
      goto match;
  }
  return;

 match:

  print_ip_header("UDP");
  printf(" HECnet %04x ", ethtyp);
  printmac(ethsrc);
  printf(" > ");
  printmac(ethdst);
  printf("\n");
  //  printf(" len %d\n", plen);

  disp_eth(sb);
}

/*
 *  Do heuristics on TCP data.  It can be one of the following:
 *
 *   DDCMP.
 *
 *   Multinet.
 */

void guess_tcp(struct sb* sb)
{
  int len;

  switch (pptr[0]) {
  case 0005:			/* DDCMP control? */
    if (plen == 8) {
      switch (pptr[1]) {
      case 1:
      case 2:
      case 3:
      case 6:
      case 7:
	dtype = D_DDCMP_TCP;
	return;
      }
    }
    break;
  case 0201:			/* DDCMP data? */
  case 0220:			/* DDCMP maint? */
    len = pptr[1] + (pptr[2] << 8);
    len &= 0x3fff;
    if ((len + 10) == plen) {
      dtype =  D_DDCMP_TCP;
      return;
    }
    break;
  }

  len = pptr[0] + (pptr[1] << 8) + (pptr[2] << 16) + (pptr[3] << 24);
  if ((len + 4) == plen) {
    dtype = D_MULTI_TCP;
    return;
  }
  
  /* we don't know. */
}

/*
 *  Here when we get a TCP segment.  We should collect them into a stream
 *  before parsing them, since we might not have one segment/ddcmp frame.
 */

void handle_tcp(struct sb* sb)
{
  if (plen > 0) {
    print_ip_header("TCP");
    if (dtype == D_NULL)
      guess_tcp(sb);

    switch (dtype) {
    case D_DDCMP_TCP:
      ddcmp_print_frame();
      break;
    case D_MULTI_TCP:
      multi_print_frame();
      break;
    default:
      printf(" <unknown TCP>\n");
      break;
    }
  } else {
    xxlen = 0;			/* Don't print non-data frames. */
  }
}

/*
 *  Do heuristics on UDP data.  It can be one of the following:
 *
 *    DDCMP (with or without checksums).
 *
 *    HECnet bridge frames, i.e. payload is an ethernet datagram.
 */

void guess_udp(struct sb* sb)
{
  int len;

  switch (pptr[0]) {
  case 0005:
    if (plen == 8 || plen == 6) {
      switch (pptr[1]) {
      case 1:
      case 2:
      case 3:
      case 6:
      case 7:
	dtype = D_DDCMP_UDP;
	return;
      }
    }
    break;
  case 0201:			/* DDCMP data? */
  case 0220:			/* DDCMP maint? */
    len = pptr[1] + (pptr[2] << 8);
    len &= 0x3fff;
    if ((len + 10) == plen) {
      dtype =  D_DDCMP_UDP;
      return;
    }
    if ((len + 6) == plen) {	/* W/O checksums? */
      dtype =  D_DDCMP_UDP;
      return;
    }
    break;
  }

  /* can be an ethernet frame. */

  if (plen >= 14 && (pptr[6] & 0x01) == 0) {
    dtype = D_BRIDGE_UDP;
    return;
  }

  /* No match. */
}

/*
 *  Here when we get an UDP datagram.  Since we now can do both DDCMP
 *  and HECnet bridge packets, we need to handle that situation.
 */

void handle_udp(struct sb* sb)
{
  if (dtype == D_NULL)
    guess_udp(sb);

  switch (dtype) {
  case D_DDCMP_UDP:
    print_ip_header("UDP");
    ddcmp_print_frame();
    break;
  case D_BRIDGE_UDP:
    /* delay printing header, we might filter out this packet. */
    handle_bridge(sb);
    break;
  default:
    print_ip_header("UDP");
    printf(" <unknown UDP, plen = %d>\n", plen);
  }

  /*
   *  Now we need to handle bridge/udp packets...
   */
}

/*
 *  Handle an IPv4 packet:
 */

void handle_ipv4(struct sb* sb)
{
  struct sb* nsb;
  u_char ihl = (pptr[0] & 0x0f) << 2;
  u_char phl = 0;
  int len = (pptr[2] << 8) + pptr[3];

  xxptr = pptr;
  xxlen = plen;

  ip4hdr = pptr;
  ip4src = &pptr[12];
  ip4dst = &pptr[16];
  ip4proto = pptr[9];
  
  if (plen > len)
    plen = len;

  pptr += ihl;
  plen -= ihl;
  
  ip4sport = (pptr[0] << 8) + pptr[1];
  ip4dport = (pptr[2] << 8) + pptr[3];

  if (sb->sb_flags & SBF_FILE) {
    if (sbhead == NULL)
      goto match;
    for (nsb = sbhead; nsb != NULL; nsb = nsb->sb_next) {
      switch (nsb->sb_dtype) {
      case D_DDCMP_TCP:
      case D_MULTI_TCP:
	if (ip4proto != 6)
	  continue;
	break;
      case D_DDCMP_UDP:
      case D_BRIDGE_UDP:
	if (ip4proto != 17)
	  continue;
	break;
      default:
	continue;
      }
      if (nsb->sb_proto == 0) {
	sb = nsb;
	goto match;
      }
      if (ip4sport == nsb->sb_proto) {
	sb = nsb;
	goto match;
      }
      if (ip4dport == nsb->sb_proto) {
	sb = nsb;
	goto match;
      }
    }
    return;
  }

 match:

  switch (ip4proto) {		/* IP protocol. */
  case 6:
    tcphdr = pptr;
    phl = (pptr[12] & 0xf0) >> 2;
    pptr += phl;
    plen -= phl;
    handle_tcp(sb);
    break;
  case 17:
    udphdr = pptr;
    pptr += 8;
    plen -= 8;
    handle_udp(sb);
    break;
  default:
    print_ip_header("IP ");
    break;
  }

  xxdump();
}

/*
 *  Handle an ethernet datagram:
 */

void handle_eth(struct sb* sb)
{
  if (ethtyp == 0x0800) {
    handle_ipv4(sb);
    return;
  }

  print_eth_header();

  xxptr = pptr;
  xxlen = plen;

  disp_eth(sb);

  xxdump();
}

/*
 *  Save a packet to a save file, possibly molesting it a bit...
 */

void save_packet(struct sb* sb, struct pcap_pkthdr* h, u_char* p)
{
  u_char fakebuf[10 + PKTMAX];
  struct pcap_pkthdr fakehdr;

  switch (sb->sb_ltype) {
  case DLT_NULL:
    switch (oftype) {
    case DLT_NULL:
      (void) pcap_dump((u_char*) outfile, h, p);
      return;
    case DLT_EN10MB:
      (void) memcpy(&fakebuf[0], &p[0], 4);
      (void) memcpy(&fakebuf[14], &p[4], h->caplen - 4);
      fakebuf[12] = 0x08;
      fakebuf[13] = 0x00;
      (void) memcpy(&fakehdr, h, sizeof(fakehdr));
      fakehdr.caplen += 10;
      fakehdr.len += 10;
      fakehdr.len |= 0x10000;
      (void) pcap_dump((u_char*) outfile, &fakehdr, fakebuf);
      return;
    default:
      /* error */
      break;
    }
    break;
  case DLT_EN10MB:
    switch (oftype) {
    case DLT_NULL:
      /* error */
      break;
    case DLT_EN10MB:
      (void) pcap_dump((u_char*) outfile, h, p);
      return;
    default:
      /* error */
      break;
    }
    break;
  default:
    /* error */
    break;
  }

  /* Error, could not handle. */

}

/*
 *  Print a packet.  Called with lock held.
 */

void print_packet(struct sb* sb, struct pcap_pkthdr* h, u_char* p)
{
  if (outfile != NULL) {
    save_packet(sb, h, p);
    if (!monitorflag)
      return;
  }

  currsb = sb;

  linktype = sb->sb_ltype;
  dtype = sb->sb_dtype;
  interface = sb->sb_iface;

  if (sb->sb_flags & SBF_FILE &&
      sb->sb_ltype == DLT_EN10MB &&
      h->len & 0x10000 &&
      h->caplen > 10) {
    h->len &= ~0x10000;
    h->len -= 10;
    h->caplen -= 10;
    (void) memcpy(&p[10], &p[0], 4);
    p += 10;
    linktype = DLT_NULL;
  }

  packet = (u_char*) p;
  caplen = h->caplen;

  sec = h->ts.tv_sec;
  usec = h->ts.tv_usec;

  switch (linktype) {
  case DLT_NULL:
    /* get protocol from first four bytes of data, dispatch on it. */
    pptr = &packet[4];
    plen = caplen - 4;
    handle_ipv4(sb);
    break;
  case DLT_EN10MB:
    ethdst = &packet[0];
    ethsrc = &packet[6];
    ethtyp = packet[13] + (packet[12] << 8);
    ethlen = caplen;
    pptr = &packet[14];
    plen = ethlen - 14;
    handle_eth(sb);
    break;
  default:
    /* should not happen, we should notice when opening pcap handle. */
    break;
  }
}

/* ********************************************************************** */

int cmp_time(pkt* p, pkt* q)
{
  if (p->pkt_header.ts.tv_sec > q->pkt_header.ts.tv_sec ||
      p->pkt_header.ts.tv_usec > q->pkt_header.ts.tv_usec)
    return 0;
  return 1;
}

/*
 *  Here to put the a packet into the sorter.  Called with lock held.
 */

void queue_packet(struct sb* sb, struct pcap_pkthdr* h, u_char* data)
{
  pkt* p;
  pkt* this;
  int i = 0;

  p = pkt_alloc(sb, h, data);
  if (debug)
    printf("Q");

  if (outqueue == NULL) {
    outqueue = p;
    if (debug)
      printf("f");
    goto done;
  }

  if (cmp_time(p, outqueue)) {
    p->pkt_next = outqueue;
    outqueue = p;
    if (debug)
      printf("0");
    goto done;
  }

  for (this = outqueue; this != NULL; this = this->pkt_next) {
    i += 1;
    if (this->pkt_next == NULL) {
      this->pkt_next = p;
      if (debug)
	printf("l");
      goto done;
    }
    if (cmp_time(p, this->pkt_next)) {
      p->pkt_next = this->pkt_next;
      this->pkt_next = p;
      if (debug)
	printf("%d", i);
      goto done;
    }
  }

 done:

  if (debug)
    printf("\n");

  for (this = p; this != NULL; this = this->pkt_next) {
    this->pkt_ttl = p->pkt_ttl;
  }

  (void) pthread_cond_signal(&qstart);
}

/*
 *  Callback from pcap when we get a packet.  If we have one source, i.e.
 *  reading from file or only using one PCAP handle, send it directly to
 *  the printer, else queue it up for a handful of milliseconds so that
 *  we can print the packets in correct order, timewise.
 */

void input_packet(u_char* user, const struct pcap_pkthdr* h, const u_char* p)
{
  struct sb* sb;
  struct pcap_pkthdr* header;
  u_char* packet;

  (void) pthread_mutex_lock(&dblock);

  sb = (struct sb*) user;
  header = (struct pcap_pkthdr*) h;
  packet = (u_char*) p;

  if (sbcount > 1)
    queue_packet(sb, header, packet);
  else
    print_packet(sb, header, packet);

  (void) pthread_mutex_unlock(&dblock);
}

/*
 *  Main program, command line parsing and associated routines.
 */

void pcaperror(char* prefix)
{
  fprintf(stderr, "%s: %s\n", prefix, errbuf);
  exit(EXIT_FAILURE);
}

void usage(int shortflag)
{
  if (shortflag) {
    fprintf(stderr, "Type %s -h for help\n", programname);
    exit(EXIT_FAILURE);
  }

  printf("Usage: %s [options] [filename]\n", programname);
  printf(
"\n"
"   General options:\n"
"\n"
"     -a           Print DDCMP data as ANF-10\n"
"     -d           Print DDCMP data as DECnet\n"
"     -h           Print this help text\n"
"     -v           Increase verbose level\n"
"     -x           Print DDCMP data in hex\n"
"\n"
"     -D           Turn on debugging\n"
"     -M           Monitor packets to terminal even if doing -w\n"
"     -X           Print packets in hex\n"
"\n"
"   Input/output options:\n"
"\n"
"     -r <file>    Read saved PCAP data from file\n"
"     -w <file>    Write a PCAP file\n"
"\n"
"     -b <port>    Listen for HECnet bridge on UDP <port>\n"
"     -m <port>    Listen for Multinet on TCP <port>\n"
"     -p <proto>   Listen for Ethernet protocol\n"
"     -t <port>    Listen for DDCMP on TCP <port>\n"
"     -u <port>    Listen for DDCMP on UDP <port>\n"
"\n"
"     -i <if>      Listen on this interface\n"
"\n"
"   When combining -p/-t/-u with -i, -i needs to be last, like:\n"
"     -p 6006 -i em0\n"
"\n"
"   Multiple listeners can be specified, with different interfaces.\n"
"\n"
"   Ethernet protocol defaults to 6016, interface to system default.\n"
"\n"
"   When reading file, interfaces are ignored, but filters work.\n"
"\n"
	 );
  exit(EXIT_SUCCESS);
}

/*
 *  Catch signals to clean up after us (close output file(s) etc).
 */

void cleanup(int sig)
{
  /*
   *  We shold possibly call pcap_breakloop() on all handles we have.
   */

  /* print information/statistics? */

  printf("Signal!\n");
  exit(0);
}

/*
 *  Generate a lookup block from global data, and
 *  re-init some variables:
 */

void gen_sb(void)
{
  struct sb* sb;

  sb = malloc(sizeof(*sb));
  sb->sb_dtype = dtype;
  sb->sb_proto = proto;
  sb->sb_plist = plist;
  sb->sb_iface = interface;

  sb->sb_next = sbhead;
  sbhead = sb;

  if (interface != NULL)
    gotint = 1;

  sbcount += 1;

  interface = NULL;
  dtype = D_ETHER_ANF;
  proto = 0x6016;
  plist = NULL;
  argflag = 0;
  brgflag = 0;
}

/*
 *  Add an entry to the plist.
 */

void gen_plist(u_short eproto)
{
  struct ep* ep;

  ep = malloc(sizeof(*ep));

  ep->ep_next = plist;
  ep->ep_proto = eproto;

  plist = ep;
}

/*
 *  Run the queue manager thread.
 */

void* run_qmgr(void* arg)
{
  pkt* p;
  pkt* prev;
  pkt* next;
  struct timespec ts;

  (void) pthread_mutex_lock(&dblock);

  for (;;) {
    (void) pthread_cond_wait(&qstart, &dblock);
    while (outqueue != NULL) {
      (void) pthread_mutex_unlock(&dblock);

      ts.tv_sec = 0;
      ts.tv_nsec = 2000000;	/* Sleep for two milliseconds. */
      (void) nanosleep(&ts, NULL);

      (void) pthread_mutex_lock(&dblock);

      if (debug)
	printf("Qs\n");

      prev = NULL;
      for (p = outqueue; p != NULL; p = next) {
	next = p->pkt_next;
	p->pkt_ttl--;
	if (p->pkt_ttl <= 0) {
	  print_packet(p->pkt_source, &p->pkt_header, p->pkt_data);
	  if (prev != NULL)
	    prev->pkt_next = next;
	  else
	    outqueue = next;
	  pkt_free(p);
	} else {
	  prev = p;
	}
      }
    }
  }

  return NULL;
}

/*
 *  Run a listening thread.
 */

void* run_listener(void* arg)
{
  struct sb* sb = arg;

  (void) pcap_loop(sb->sb_ph, -1, input_packet, (u_char*) sb);

  return NULL;
}

/*
 *  Start a listening thread:
 */

void start_listener(struct sb* sb)
{
  int ret;

  if (debug)
    printf("starting thread for %s\n", sb->sb_iface);

  ret = pthread_create(&sb->sb_thread, NULL, run_listener, sb);
  /* should check return value. */
}

/*
 *  Main program, command and option decoding.
 */

int main(int argc, char* argv[])
{
  int ch;
  struct tm* tm;
  struct sb* sb;
  struct ep* ep;
  struct bpf_program filter;
  char filterstr[1000];		/* Where to build pcap filter. */
  int max, pos;			/* Variables for above. */
  pcap_t* wph;			/* "write" template handle. */

  programname = argv[0];        /* Keep for later. */

  struct sb filesb;		/* Used when reading dump file. */

  /* Compute our GMT offset for timestamping: */

  gmtdiff = 86400;
  tm = localtime(&gmtdiff);
  gmtdiff = tm->tm_hour * 3600 + tm->tm_min * 60;
  if (tm->tm_mday == 1) {
    gmtdiff -= 86400;
  }

  /* Set up mutex in case we need it: */

  (void) pthread_mutex_init(&dblock, NULL);

  /* Parse commands: */

  while ((ch = getopt(argc, argv, "ab:cdhi:m:p:r:t:u:vw:xDMX")) != -1) {
    switch(ch) {
    case 'a':			/* Set default DDCMP decode to ANF-10. */
      defprint = PRINT_ANF10;
      break;
    case 'b':			/* Listen to UDP <port>, HECnet bridge. */
      if (argflag)
	gen_sb();
      dtype = D_BRIDGE_UDP;
      proto = (short) strtol(optarg, NULL, 10);
      argflag = 1;
      brgflag = 1;
      break;
    case 'c':			/* Use colours. */
      colourflag = 1;
      break;
    case 'd':			/* Set default DDCMP decode to DECNET. */
      defprint = PRINT_DECNET;
      break;
    case 'h':			/* Give help. */
      usage(0);
      break;
    case 'i':			/* Set interface. */
      interface = optarg;
      gen_sb();
      break;
    case 'm':			/* Listen to TCP <port>, multinet. */
      if (argflag)
	gen_sb();
      dtype = D_MULTI_TCP;
      proto = (short) strtol(optarg, NULL, 10);
      argflag = 1;
      break;
    case 'p':			/* Set protocol number for ethernet. */
      if (brgflag) {
	gen_plist((short) strtol(optarg, NULL, 16));
      } else {
	if (argflag)
	  gen_sb();
	dtype = D_ETHER_ANF;
	proto = (short) strtol(optarg, NULL, 16);
	argflag = 1;
      }
      break;
    case 'r':			/* Read from PCAP file. */
      filename = optarg;
      break;
    case 't':			/* Listen to TCP <port>, DDCMP. */
      if (argflag)
	gen_sb();
      dtype = D_DDCMP_TCP;
      proto = (short) strtol(optarg, NULL, 10);
      argflag = 1;
      break;
    case 'u':			/* Listen to UDP <port>, DDCMP. */
      if (argflag)
	gen_sb();
      dtype = D_DDCMP_UDP;
      proto = (short) strtol(optarg, NULL, 10);
      argflag = 1;
      break;
    case 'v':			/* Verbose level. */
      verbose += 1;
      break;
    case 'w':			/* Write to PCAP file. */
      outname = optarg;
      break;
    case 'x':			/* Set default DDCMP decode to HEX. */
      defprint = PRINT_HEX;
      break;
    case 'D':			/* Turn on debugging. */
      debug = 1;
      break;
    case 'M':			/* Turn on monitor mode. */
      monitorflag = 1;
      break;
    case 'X':			/* Dump-data-in-hex. */
      if (xxflag < 2)
	xxflag += 1;
      break;
    default:
      usage(1);
      break;
    }
  }
  argc -= optind;
  argv += optind;

  if (argflag)
    gen_sb();

  if (filename == NULL)
    filename = argv[0];

  /*
   *  Catch signals etc.
   */

  (void) signal(SIGINT, cleanup);
  (void) signal(SIGTERM, cleanup);

  /*
   *  Maybe do some debugging output:
   */

  if (debug) {
    for (sb = sbhead; sb != NULL; sb = sb->sb_next) {
      switch (sb->sb_dtype) {
      case D_DDCMP_TCP:
	printf("TCP, DDCMP, port %u, if ", sb->sb_proto);
	break;
      case D_MULTI_TCP:
	printf("TCP, Multinet, port %u, if ", sb->sb_proto);
	break;
      case D_DDCMP_UDP:
	printf("UDP, DDCMP, port %u, if ", sb->sb_proto);
	break;
      case D_BRIDGE_UDP:
	printf("UDP, HECnet, port %u, if ", sb->sb_proto);
	break;
      case D_ETHER_ANF:
	printf("ETH, proto %04x, if ", sb->sb_proto);
	break;
      default:
	printf("type %u; proto %u (0x%04x); if ",
	       sb->sb_dtype, sb->sb_proto, sb->sb_proto);
	break;
      }
      if (sb->sb_iface != NULL)
	printf("%s\n", sb->sb_iface);
      else
	printf("<NULL>\n");
      for (ep = sb->sb_plist; ep != NULL; ep = ep->ep_next) {
	printf("  proto %x\n", ep->ep_proto);
      }
    }
  }

  /*
   *  If we are reading a file, set up the filter from the lb blocks,
   *  and verify that we don't have any interfaces specified.
   */

  if (filename != NULL) {
    filesb.sb_ph = pcap_open_offline(filename, errbuf);
    if (filesb.sb_ph == NULL) {
      pcaperror("pcap_open_offline");
    }

    filesb.sb_flags = SBF_FILE;
    filesb.sb_dtype = D_NULL;
    filesb.sb_ltype = pcap_datalink(filesb.sb_ph);
    filesb.sb_iface = NULL;
    filesb.sb_plist = NULL;

    pos = 0;
    max = sizeof(filterstr);

    for (sb = sbhead; sb != NULL; sb = sb->sb_next) {
      if (pos > 0)
	pos += snprintf(&filterstr[pos], max - pos, " or ");
      switch (sb->sb_dtype) {
      case D_ETHER_ANF:
	pos += snprintf(&filterstr[pos], max - pos,
			"ether proto %u", sb->sb_proto);
	break;
      case D_DDCMP_TCP:
      case D_MULTI_TCP:
	pos += snprintf(&filterstr[pos], max - pos, "tcp");
	if (sb->sb_proto != 0)
	  pos += snprintf(&filterstr[pos], max - pos, " port %u",
			  sb->sb_proto);
	break;
      case D_DDCMP_UDP:
      case D_BRIDGE_UDP:
	pos += snprintf(&filterstr[pos], max - pos, "udp");
	if (sb->sb_proto != 0)
	  pos += snprintf(&filterstr[pos], max - pos, " port %u",
			  sb->sb_proto);
	break;
      default:
	/* error? */
	break;
      }
    }

    if (debug)
      printf("filter: %s\n", filterstr);

    if (pos > 0) {
      if (pcap_compile(filesb.sb_ph, &filter, filterstr, 0, -1) < 0) {
	pcaperror("pcap_compile");
      }
      if (pcap_setfilter(filesb.sb_ph, &filter) < 0) {
	pcaperror("pcap_setfilter");
      }
    }

    (void) pcap_loop(filesb.sb_ph, -1, input_packet, (u_char*) &filesb);
    
    return 0;
  }

  /*
   *  Reading from live interface(s).
   *
   *  If we have > 1 packet sources, we need a queue manager
   *  thread.  Start it now.
   */

  if (sbcount > 1) {
    (void) pthread_cond_init(&qstart, NULL);
    (void) pthread_create(&qthread, NULL, run_qmgr, NULL);  
  }
  
  /*
   *  Step 1, set up all listeners and install filters.
   */

  wph = NULL;

  for (sb = sbhead; sb != NULL; sb = sb->sb_next) {
    if (sb->sb_iface == NULL) {
      sb->sb_iface = pcap_lookupdev(errbuf);
      if (sb->sb_iface == NULL) {
	pcaperror("pcap_lookupdev");
      }
    }

    sb->sb_ph = pcap_open_live(sb->sb_iface, PKTMAX, 1, 1, errbuf);
    if (sb->sb_ph == NULL) {
      pcaperror("pcap_open_live");
    }

    sb->sb_ltype = pcap_datalink(sb->sb_ph);

    switch (sb->sb_ltype) {
    case DLT_NULL:
      if (wph == NULL) {
	wph = sb->sb_ph;
	oftype = DLT_NULL;
      }
      break;
    case DLT_EN10MB:
      wph = sb->sb_ph;
      oftype = DLT_EN10MB;
      break;
    default:
      /* error */
      break;
    }

    switch (sb->sb_dtype) {
    case D_ETHER_ANF:
      if (sb->sb_ltype != DLT_EN10MB) {
	printf("Link type (%d) not ethernet\n", sb->sb_ltype);
      }
      (void) sprintf(filterstr, "ether proto 0x%x", sb->sb_proto);
      break;
    case D_DDCMP_TCP:
    case D_MULTI_TCP:
      if (sb->sb_proto != 0)
	(void) sprintf(filterstr, "tcp port %d", sb->sb_proto);
      else
	(void) sprintf(filterstr, "tcp");
      break;
    case D_DDCMP_UDP:
    case D_BRIDGE_UDP:
      if (sb->sb_proto != 0)
	(void) sprintf(filterstr, "udp port %d", sb->sb_proto);
      else
	(void) sprintf(filterstr, "udp");
      break;
    default:
      /* what to do here? */
      break;
    }

    if (pcap_compile(sb->sb_ph, &filter, filterstr, 0, -1) < 0) {
      pcaperror("pcap_compile");
    }
    if (pcap_setfilter(sb->sb_ph, &filter) < 0) {
      pcaperror("pcap_setfilter");
    }
  }

  /*
   *  If we are writing to a file, set that up now.
   */

  if (outname != NULL) {
    if (wph == NULL) {
      printf("No input, nothing to write to file.\n");
      exit(0);
    }
    outfile = pcap_dump_open(wph, outname);
    if (outfile == NULL)
      pcaperror("pcap_dump_open");

    /* Do we need to do more? */
  }

  /*
   *   Start a thread for all sb blocks except the last one.
   */

  for (sb = sbhead; sb != NULL; sb = sb->sb_next) {
    if (sb->sb_next != NULL) {
      start_listener(sb);
    } else {
      (void) pcap_loop(sb->sb_ph, -1, input_packet, (u_char*) sb);
    }
  }

  return 0;
}
