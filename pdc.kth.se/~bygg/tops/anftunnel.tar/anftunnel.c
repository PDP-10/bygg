/*
   Copyright (c) 2015-2018, Johnny Eriksson
   All rights reserved.

   Redistribution and use in source and binary forms, with or without
   modification, are permitted provided that the following conditions
   are met:

   1. Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

   2. Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in the
      documentation and/or other materials provided with the distribution.

   THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
   "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
   LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
   FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
   COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
   INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
   BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
   OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
   AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
   OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
   THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH
   DAMAGE.
*/

#include <ctype.h>
#include <stdarg.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <errno.h>
#include <limits.h>
#include <signal.h>
#include <time.h>

#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/select.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include <pthread.h>

#include <pcap/pcap.h>

#include "prng.h"

/*
 *  The main chunk of data is the object:
 *  (I have no good explanation for this name)
 */

typedef struct object {
  struct object*   obj_next;	/* Next object in list. */
  struct object*   obj_parent;	/* Parent.  NULL if top level. */
  struct object*   obj_chlist;	/* Child list head. */
  struct object*   obj_chtail;	/* Child list tail. */
  char*            obj_name;
  pthread_t        obj_thread;
  pthread_mutex_t  obj_lock;
  int              obj_timer;
  u_short          obj_flags;	/* Flags: */
#   define OBF_UP     0x0001	/*   Object is "up". */
#   define OBF_THR    0x0002    /*   Thread is running. */
#   define OBF_WSUB   0x0004	/*   Writer sub-thread is up. */

#   define OBF_QUIT   0x0010	/*   Quit flag (for IP conns). */

#   define OBF_READY  0x0100	/*   Object is ready for writes. */
#   define OBF_DDCMP  0x0200	/*   Terminate DDCMP here. */
#   define OBF_ETHER  0x0400	/*   Ethernet target. */
#   define OBF_NEIGHB 0x0800	/*   Eth. neighbour "up". */

  u_char           obj_type;	/* Object type: */
#   define OBT_NONE   0		/*   None yet. */
#   define OBT_BRIDGE 1		/*   Bridge. */
#   define OBT_ETHER  2		/*   Ethernet. */
#   define OBT_TUNNEL 3		/*   Tunnel. */
#   define OBT_SYNC   4		/*   Sync line over TCP. */
#   define OBT_UDP    5		/*   Sync line over UDP. */
#   define OBT_LOG    6		/*   Log object. */
#   define OBT_MLT    7		/*   Multinet/TCP. */
#   define OBT_CMD    8		/*   Remote command handler. */

  u_short          obj_eproto;	/* Ethernet protocols to handle: */
#   define OBP_ANF10  0x0001	/*   ANF-10. */
#   define OBP_DECNET 0x0002	/*   DECnet. */
#   define OBP_LAT    0x0004	/*   LAT. */
#   define OBP_IPV4   0x0008	/*   IPv4. */
#   define OBP_IPV6   0x0010	/*   IPv6. */
#   define OBP_CHAOS  0x0020	/*   Chaosnet. */

  u_char           obj_4flag;	/* -4 (ipv4) given. */
  u_char           obj_6flag;	/* -6 (ipv6) given. */
  u_char           obj_aflag;	/* -a given. */
  u_char           obj_cflag;	/* -c (chaos) given. */
  u_char           obj_dflag;	/* -d given. */
  u_char           obj_eflag;	/* -e given. */
  u_char           obj_lflag;	/* -l (lat flag) given. */
  u_char           obj_rflag;	/* -r (read-only) given. */
  u_char           obj_vflag;	/* -v (verbose) given. */

  u_char           obj_node;	/* -n arg */
  u_char           obj_maxnode;	/* -m arg */
  u_char           obj_tag;	/* -t arg */
  u_short          obj_port;	/* -p arg */
  u_short          obj_lport;	/* -l arg */
  char*            obj_remote;	/* -r arg */
  char*            obj_key;	/* -k arg */
  char*            obj_iface;	/* -i arg */

  struct object*   obj_xcon;	/* What we are cross-connected to. */

  /*
   *  Data used by the ether <-> sync conversion:
   */

  struct packet*   obj_nidpkt;	/* Template for synth. NodeIDs. */
  u_int            obj_serial;	/* Last recv'd nodeid serial. */
  u_char           obj_peermac[6]; /* Mac address of eth. peer. */
  u_short          obj_peerpty;	/* Protocol type of eth. peer. */
  u_char           obj_srcnode;	/* Source node (serial). */

  /*
   *  Type-specific data:
   */

  struct ddcmp*    obj_ddcmp;	/* sync. */
  struct ipcon*    obj_ipcon;	/* sync, tunnel, multinet. */
  struct nodedata* obj_route;	/* ethernet. */
  struct tagblock* obj_tags;	/* tunnel. */
  pcap_t*          obj_pcap;	/* ethernet. */
  struct bridge*   obj_bridge;	/* ethernet. */

  /*
   *  For objects that use a writer sub-thread:
   */

  pthread_t        obj_writer;	/* Writer thread handle. */
  pthread_cond_t   obj_wcond;	/* Semaphore. */
  struct packet*   obj_oqhead;	/* Packet queue head. */
  struct packet*   obj_oqtail;	/* Packet queue tail. */
  u_int            obj_oqlen;	/* Packet queue length. */
  u_int            obj_oqmax;	/* Max value of above. */
  u_int            obj_oqdrop;	/* Number of dropped packets. */
  u_int            obj_oqsize;	/* Max number of pkts to allow in queue. */
  u_int            obj_oqspeed;	/* Speed (compute delay). */
  u_int            obj_oqdly;	/* Delay between xmits (us). */
} object;

/*
 *  Data to keep track of a DDCMP link.
 */

typedef struct ddcmp {
  struct object* dd_object;	/* Our master. */
  struct ipcon*  dd_ipcon;	/* Our IP connection. */
  int            dd_timer;	/* General timer. */
  struct packet* dd_ackqhead;	/* Queue of un-acked packets, head. */
  struct packet* dd_ackqtail;	/* Queue of un-acked packets, tail. */
  int            dd_ackqlen;	/* Number of packets on queue. */
  struct packet* dd_outqhead;	/* Queue of packets to send, head. */
  struct packet* dd_outqtail;	/* Queue of packets to send, tail. */
  int            dd_outqlen;	/* Number of packets on queue. */
  u_short        dd_flags;	/* Various flags: */
#   define DDF_ANF    0x0001	/*   Running ANF style DDCMP. */
#   define DDF_TIMER  0x0002	/*   Timer is running. */
#   define DDF_NOCRC  0x0004	/*   UDP link w/o CRC bytes. */

  u_char         dd_state;	/* DDCMP state. */
#   define DDS_HALT    0	/*   Halted. */
#   define DDS_START   1	/*   Sending START. */
#   define DDS_STACK   2	/*   Sending STACK. */
#   define DDS_RUN     3	/*   Up and running. */

  u_char         dd_req;	/* Request bits: */
#   define DDRQ_START 0x20	/*   Need to send a start. */
#   define DDRQ_STACK 0x10	/*   Need to send a stack. */
#   define DDRQ_NAK   0x08	/*   Need to send a nak. */
#   define DDRQ_REP   0x04	/*   Need to send a rep. */
#   define DDRQ_DATA  0x02	/*   Need to send data. */
#   define DDRQ_ACK   0x01	/*   Need to send an ack. */

  u_char         dd_xnk;	/* NAK reason. */
#   define NAK_HCK    1		/*   Header CRC error. */
#   define NAK_DCK    2		/*   Data CRC error. */
#   define NAK_REP    3		/*   REP response. */
#   define NAK_BTU    8		/*   Buffer unavailable. */
#   define NAK_OVR    9		/*   Receiver overrun. */
#   define NAK_M2L   16		/*   Message too long. */
#   define NAK_HFA   17		/*   Header format error. */

  u_char         dd_rmn;	/* Receive msg number. */
  u_char         dd_lmx;	/* Last msg xmitted. */
  u_char         dd_lma;	/* Last msg ack'ed. */
  u_short        dd_rpc;	/* REP counter. */

  /* statistics: */

  u_int          dd_c_ctlrec;
  u_int          dd_c_ctlxmt;

} ddcmp;

/*
 *  DDCMP control msg types and bits etc:
 */

#define DDC_ACK         1	/* Ack. */
#define DDC_NAK         2	/* Nak. */
#define DDC_REP         3	/* Rep. */
#define DDC_START       6	/* Start. */
#define DDC_STACK       7	/* Stack. */

#define DDB_QSYNC    0100	/* QSync bit. */
#define DDB_SELECT   0200	/* Select bit. */

#define DDCMP_REPMAX   20	/* For dead line detection. */
#define DDCMP_STARTSEC  5	/* Seconds between Starts. */
#define DDCMP_STACKSEC  2	/* Seconds between Stacks. */
#define DDCMP_REPSEC    3	/* Seconds between Reps. */
#define DDCMP_MAXOUT   10	/* Max. number unacked msgs. */

/*
 *  Data to keep track of an open IP connection.
 */

typedef struct ipcon {
  struct object* ip_object;	/* Our master. */
  struct ddcmp*  ip_ddcmp;	/* Our DDCMP data, if any. */
  int            ip_socket;	/* Working socket. */
  int            ip_master;	/* Master socket. */
  u_short        ip_flags;	/* Various flags: */
#   define IPF_MASTER  0x0001	/*   Master socket set up. */
#   define IPF_CRYPTO  0x0002	/*   Crypto active. */
#   define IPF_NBLOCK  0x0004	/*   Non-blocking I/O set. */
  int            ip_state;	/* Connection state: */
#   define IPS_DOWN    0	/*   Not connected. */
#   define IPS_WAIT    1	/*   Waiting for incoming connect. */
#   define IPS_AUTH    2	/*   Doing authentication. */
#   define IPS_UP      3	/*   Up and running. */
  u_short        ip_isiz;	/* Number of bytes in input buffer. */
  u_short        ip_ipos;	/* Position in input buffer. */
  u_char         ip_ibuf[100];	/* The actual input buffer. */
  prng*          ip_rxcrypt;	/* Receive crypto. */
  prng*          ip_txcrypt;	/* Transmit crypto. */
} ipcon;

/*
 *  Bridge database (for ethernet-type objects).
 */

#define EHASHSIZE 251		/* Size of mac addr hash table. */

typedef struct bridge {
  pthread_mutex_t br_lock;	/* Our lock. */
  int             br_count;	/* Total number of entries. */
  struct ethost*  br_host[EHASHSIZE]; /* Some linked lists. */
  struct member*  br_members;	/* Member objects. */
} bridge;

typedef struct ethost {
  struct ethost* eth_next;	/* Next on this list. */
  struct object* eth_obj;	/* Where to send packets to us. */
  u_short        eth_ttl;	/* Our TTL. */
  u_char         eth_tag;	/* Tag to use. */
  u_char         eth_mac[6];	/* Our MAC address. */
} ethost;

typedef struct member {
  struct member* mbr_next;	/* Next on list. */
  struct bridge* mbr_bridge;	/* Bridge we belong to. */
  struct object* mbr_obj;	/* Object we point to. */
  u_char         mbr_tag;	/* Tag, for tunnels. */
} member;

/*
 *  Packet structure, with lots of meta-data.
 */

#define SSIZ 32			/* Size of strings in NCL messages. */
#define PSIZ 1800		/* Size of packet buffer. */

typedef struct packet {
  struct packet* pkt_next;	/* Linked list. */
  struct object* pkt_src;	/* Source object for this packet. */

  u_short        pkt_len;	/* Length of data in buffer. */
  u_char*        pkt_data;	/* Pointer to packet data. */
  u_char*        pkt_sptr;	/* Store pointer. */
  u_short        pkt_pre;	/* Amount of space before data. */
  u_short        pkt_post;	/* Amount of space after data. */

  u_char         pkt_seq;	/* DDCMP sequence number. */
  u_char         pkt_node;	/* Node. */
  u_char         pkt_srcnode;	/* Source node. */
  u_char         pkt_tag;	/* Tag. */
  u_char         pkt_type;	/* Packet type: */

  /* XXX These are globally known, do NOT renumber them. */

#   define PKT_RAW   1		/*   Raw data. */
#   define PKT_DDCMP 2		/*   DDCMP hdr + data. */
#   define PKT_ETHER 3		/*   Ethernet packet. */

  u_char         pkt_proto;	/* Protocol: */

  /* XXX These are globally known, do NOT renumber them. */

#   define PROTO_NONE    0	/*   None set. */
#   define PROTO_ANF10   1	/*   ANF10. */
#   define PROTO_DECNET  2	/*   DECnet. */
#   define PROTO_LAT     3	/*   LAT. */
#   define PROTO_IPV4    4	/*   IPv4. */
#   define PROTO_IPV6    6	/*   IPv6. */
#   define PROTO_CHAOS   7	/*   Chaosnet. */

  u_short        pkt_flags;	/* Flags. */
#   define PKF_APARSE   0x0001	/*   ANF-10 parse done. */
#   define PKF_ANF      0x0002	/*   Valid ANF-10 packet.  */
#   define PKF_FREE1    0x0004	/*   Free flag. */
#   define PKF_OVRRUN   0x0008	/*   Data overrun. */
#   define PKF_SEQUENCE 0x0010	/*   DDCMP sequence number has been set. */

  u_char         pkt_buf[PSIZ];	/* Buffer for packet data. */

  /*
   *  Decoded stuff from ANF packets:
   */

  u_char         anf_nct;	/* NCT byte. */
#   define NCT_TYPE 0x07	/*   Three bits of type field. */
#     define NCTT_DATA     0	/*     Data message. */
#     define NCTT_ACK      1	/*     ACK. */
#     define NCTT_NAK      2	/*     NAK. */
#     define NCTT_REP      3	/*     REP. */
#     define NCTT_START    4	/*     START. */
#     define NCTT_STACK    5	/*     STACK. */
#     define NCTT_NODEID   6	/*     NODE-ID. */
#     define NCTT_UNUSED   7	/*     unused. */
#     define NCTT_CONTROL  8	/*     (pseudo-type) num. control. */
#     define NCTT_NEIGHB   9	/*     (pseudo-type) neighb. announce. */
#   define NCT_RH   0x08	/*   SNA/DNA present. */
#   define NCT_TR   0x10	/*   Trace. */
#   define NCT_IT   0x20	/*   Interrupt. */
#   define NCT_SQ   0x40	/*   Sequential node. */
#   define NCT_EX   0x80	/*   Extensible bit (not used). */

  u_char         anf_type;	/* Extracted type code. */
  u_short        anf_dna;	/* Destination nw addr. */
  u_short        anf_sna;	/* Source nw addr. */
  u_char         anf_nca;	/* NW control ack. */
  u_char         anf_ncn;	/* NW control number. */
  u_char         anf_dla;	/* DLA for data messages. */

  u_short        anf_nnum;	/* Node number. (START/NODEID) */
  u_short        anf_nvr;	/* NCL version. (START/NODEID) */
  u_char         anf_nit;	/* NodeID type. (NODEID) */
#   define NIT_PP 0		/*   Point-to-point link. */
#   define NIT_BC 1		/*   Broadcast link. */
  u_int          anf_nis;	/* NodeID sequence. (NODEID) */
  u_char         anf_snm[SSIZ];	/* NodeID system name. */
  u_char         anf_sid[SSIZ];	/* NodeID system ID. */
  u_char         anf_dat[SSIZ];	/* NodeID system date. */

  u_char*        anf_data;	/* Sub-data pointer. */
  u_char*        anf_nitptr;	/* Sub-sub-data pointer. */
} packet;

/*
 *  The tag block is used by tunnel objects.
 */

typedef struct tagblock {
  struct object* tag_target;
} tagblock;

/*
 *  The nodedata structure is used by ethernet objects.
 */

typedef struct nodedata {
  struct object* nd_target;	/* Object hosting this node. */
  int            nd_ttl;	/* Time to live. */
  u_short        nd_flags;	/* Flags: */
#   define NDF_VALID   0x0001	/*   Valid block. */
#   define NDF_LOCAL   0x0002	/*   Local node for us. */
#   define NDF_SYNC    0x0004	/*   Node is on a sync line. */

  u_char         nd_tag;	/* Tag to use. */
  u_char         nd_peer;	/* Peer node on ethernet. */
  u_char         nd_mac[6];	/* MAC address. */
  
  /* The following are from the nodes NodeID msg: */

  u_short        nd_nvr;	/* NCL version. */
  u_int          nd_nis;	/* (BC link) sequence number. */
  u_char         nd_nit;	/* NodeID type. */
  u_char         nd_nam[SSIZ];	/* Node name. */
  u_char         nd_sid[SSIZ];	/* System ID. */
  u_char         nd_dat[SSIZ];	/* System date. */
} nodedata;

/*
 *  Helper struct for mapping ints (or bits) to strings:
 */

struct i2s {
  u_int i;
  char* s;
};

/*
 *  Helper struct for ANF parsers:
 */

typedef struct anfstream {
  int ctr;
  u_char* ptr;
} anfs;

/*
 *  Command descriptor block:
 */

typedef struct cmdb {
  char* cmd;			/* The actual command. */
  int (*handler)(object* obj, struct cmdb* cmd);
  int offset;			/* Random offset. */
  int radix;			/* Radix for numbers. */
  int lower, upper;		/* Range for numbers. */
} cmdb;

/*
 ************************************************************************
 *
 *  Our global variables:
 *
 ************************************************************************
 */

char* programname;		/* What we were called as. */

time_t gmtdiff;			/* Offset from GMT. */

int verbose = 0;		/* Verbose level. */

int frozen = 0;			/* (debug) freeze pkt forwarding & timer. */

int nocmdhflag = 0;		/* No command handler flag. */
int detachflag = 0;		/* Detach flag. */

object* objlist = NULL;		/* List of all known objects. */
object* objtail = NULL;		/* Tail of list. */

pthread_mutex_t ctylock =	/* Grab this before printing on console. */
  PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t memlock =	/* Grab this when allocating buffers. */
  PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t cmdlock =	/* Grab this when executing commands. */
  PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t pcaplock =	/* Grab this when initing a pcap instance. */
  PTHREAD_MUTEX_INITIALIZER;

pthread_t cmdhthread;		/* Thread handle for command decoder. */

packet* pkt_freelist = NULL;	/* List of unused packets. */

int pk_count = 0;		/* Count of packets malloc()ed. */
int pk_free = 0;		/* Count of free packets. */
int pk_alloc = 0;		/* Count of packet allocs. */

ethost* eth_freelist = NULL;	/* List of unused ethosts. */

int et_count = 0;		/* Count of ethosts malloc()ed. */
int et_free = 0;		/* Count of free ethosts. */
int et_alloc = 0;		/* Count of ethost allocs. */

member* mbr_freelist = NULL;	/* List of unused members. */

int mb_count = 0;		/* Count of members malloc()ed. */
int mb_free = 0;		/* Count of free members. */
int mb_alloc = 0;		/* Count of member allocs. */

object* obj_freelist = NULL;	/* List of unused objects. */

int ob_count = 0;		/* Count of objects malloc()ed. */
int ob_free = 0;		/* Count of free objects. */
int ob_alloc = 0;		/* Count of object allocs. */

/*
 *  Command scanner variables:
 */

char* cmtext;			/* Text line we are about to handle. */
int   cmtype;			/* Type of command handler: */
#  define CMDT_NONE  0		/*   Type = none active. */
#  define CMDT_CTY   1		/*   Type = console terminal. */
#  define CMDT_TCPIP 2		/*   Type = TCP/IP object. */

object* cmobj;			/* Object doing commands, if any. */

int   cmlres;			/* What did cm_lookup() find? */
#  define CML_NOMATCH 0		/*   No matching keyword. */
#  define CML_MATCH   1		/*   One matching keyword. */
#  define CML_AMBIG   2		/*   Ambigous, two or more matches. */

char* cmtoken;			/* Last token we parsed. */

/*
 *  Names of various flags:
 */

struct i2s obj_flag_names[] = {
  { OBF_UP,     "up" },
  { OBF_THR,    "thread" },
  { OBF_WSUB,   "wsub" },
  { OBF_READY,  "ready" },
  { OBF_DDCMP,  "ddcmp" },
  { OBF_ETHER,  "ether" },
  { OBF_NEIGHB, "neighb" },
  { OBF_QUIT,   "quit" },
  { 0, NULL },
};

struct i2s obj_proto_names[] = {
  { OBP_ANF10,  "ANF10" },
  { OBP_CHAOS,  "Chaos" },
  { OBP_DECNET, "DECnet" },
  { OBP_LAT,    "LAT" },
  { OBP_IPV4,   "IPv4" },
  { OBP_IPV6,   "IPv6" },
  { 0, NULL },
};

struct i2s ip_flag_names[] = {
  { IPF_MASTER, "master" },
  { IPF_CRYPTO, "crypto" },
  { IPF_NBLOCK, "non-blocking" },
  { 0, NULL },
};

struct i2s pkt_flag_names[] = {
  { PKF_APARSE, "aparse" },
  { PKF_ANF,    "anf" },
  { PKF_OVRRUN, "ovrrun" },
  { 0, NULL },
};

struct i2s ddc_flag_names[] = {
  { DDF_ANF,    "ANF" },
  { DDF_TIMER,  "timer on" },
  { DDF_NOCRC,  "no crc" },
  { 0, NULL },
};

struct i2s ddc_req_names[] = {
  { DDRQ_START, "start" },
  { DDRQ_STACK, "stack" },
  { DDRQ_NAK,   "nak" },
  { DDRQ_REP,   "rep" },
  { DDRQ_DATA,  "data" },
  { DDRQ_ACK,   "ack" },
  { 0, NULL },
};

struct i2s nd_flag_names[] = {
  { NDF_VALID, "valid" },
  { NDF_LOCAL, "local" },
  { NDF_SYNC,  "sync" },
  { 0, NULL },
};

/*
 *  Other names:
 */

struct i2s pkt_type_names[] = {
  { PKT_RAW,   "raw data" },
  { PKT_DDCMP, "ddcmp frame" },
  { PKT_ETHER, "ethernet frame" },
  { 0, NULL },
};

struct i2s proto_names[] = {
  { PROTO_NONE,   "none" },
  { PROTO_ANF10,  "anf-10" },
  { PROTO_CHAOS,  "chaos" },
  { PROTO_DECNET, "decnet" },
  { PROTO_LAT,    "lat" },
  { PROTO_IPV4,   "ipv4" },
  { PROTO_IPV6,   "ipv6" },
  { 0, NULL },
};

struct i2s obj_type_names[] = {
  { OBT_NONE,   "none" },
  { OBT_BRIDGE, "bridge" },
  { OBT_ETHER,  "ethernet" },
  { OBT_LOG,    "log" },
  { OBT_MLT,    "multinet" },
  { OBT_TUNNEL, "tunnel" },
  { OBT_SYNC,   "sync" },
  { OBT_UDP,    "udp" },
  { OBT_CMD,    "cmd" },
  { 0, NULL },
};

struct i2s ip_state_names[] = {
  { IPS_DOWN,  "down" },
  { IPS_WAIT,  "waiting" },
  { IPS_AUTH,  "auth" },
  { IPS_UP,    "up/run" },
  { 0, NULL },
};

struct i2s ddcmp_state_names[] = {
  { DDS_HALT,  "Halted" },
  { DDS_START, "Start" },
  { DDS_STACK, "Stack" },
  { DDS_RUN,   "Running" },
  { 0, NULL },
};

/*
 *  Forward declarations:
 */

u_short ddcmp_crc(u_char* data, int len);
void ddcmp_fixup_crc(packet* pkt);
void ddcmp_xmit(object* obj, packet* pkt);
void ddcmp_recv(object* obj, packet* pkt);
void ddcmp_dcd_on(object* obj);
void ddcmp_dcd_off(object* obj);
void ddcmp_cty_print(char* msg, packet* pkt);

int   cm_dispatch(object* obj, cmdb* cmds, char* token);
void  cm_enter(int type, object* obj);
void  cm_exit(void);
void  cm_line(char* cmd);
cmdb* cm_lookup(cmdb* table, char* token);
object* cm_object(void);
char* cm_string(void);
object* cm_tk2obj(char* token);
char* cm_token(void);

/*
 *************************************************************************
 *
 *  General helper routines:
 *
 *************************************************************************
 */

/*
 *  Sleep for a number of nanoseconds:
 */

void nssleep(int ns)
{
  struct timespec ts;

  ts.tv_sec = ns / 1000000000;
  ts.tv_nsec = ns % 1000000000;

  (void) nanosleep(&ts, NULL);
}

/*
 *  Printf wrapper.  This will be augmented to redirect output to
 *  other places than the controlling terminal.
 */

void printx(char* fmt, ...)
{
  char buffer[2000];
  int len;
  va_list ap;
  ipcon* ipc;

  va_start(ap, fmt);

  switch (cmtype) {
  case CMDT_NONE:
  case CMDT_CTY:
    vprintf(fmt, ap);
    break;
  case CMDT_TCPIP:
    ipc = cmobj->obj_ipcon;

    vsnprintf(buffer, sizeof(buffer), fmt, ap);
    len = strlen(buffer);

    if (ipc->ip_flags & IPF_CRYPTO)
      prng_encrypt(ipc->ip_txcrypt, (u_char*) buffer, len);

    (void) send(ipc->ip_socket, buffer, len, 0);
    break;
  }

  va_end(ap);
}

/*
 *  Print our version number:
 */

void prvers(void)
{
#include "hgedit.h"
#include "hghash.h"

  printx("anftunnel 1.0, edit %s, commit id %s\n", hgedit, hghash);
}

/*
 *  Print a timestamp.
 */

void timestamp(void)
{
  struct timespec ts;
  int s, us;

  (void) clock_gettime(CLOCK_REALTIME, &ts);

  s = (ts.tv_sec + gmtdiff) % 86400;
  us = ts.tv_nsec / 1000;

  printx("%02d:%02d:%02d.%06u ", s/3600, (s%3600)/60, s%60, us);
}

/*
 *  Print a mac address:
 */

void printmac(u_char* mac)
{
  printx("%02x:%02x:%02x:%02x:%02x:%02x",
	 mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);
}

/*
 *  Print the DECnet address of a mac d:o, if there is one.
 */

void printdna(u_char* mac)
{
  static u_char dnstart[4] = { 0xaa, 0x00, 0x04, 0x00 };
  int dnaddr;
  int area, node;
  char buf[10];

  if (memcmp(mac, dnstart, 4) == 0) {
    dnaddr = mac[4] + (mac[5] << 8);
    area = mac[5] >> 2;
    node = mac[4] + ((mac[5] & 3) << 8);
    sprintf(buf, "%d.%d", area, node);
    printx(" %7s", buf);
  } else {
    printx("        ");
  }
}

/*
 *  Print out the names of a set of bits, inside (), or nothing if
 *  there are no bits set.
 */

void printbits(u_int bits, struct i2s* names)
{
  int n = 0;

  if (bits != 0) {
    printx(" (");
    while (names->i != 0) {
      if (names->i & bits) {
	if (n++ > 0)
	  printx(", ");
	printx("%s", names->s);
      }
      names++;
    }
    printx(")");
  }
}

/*
 *  Locked version of printf().
 */

void ctyprintf(char* fmt, ...)
{
  va_list ap;

  va_start(ap, fmt);

  (void) pthread_mutex_lock(&ctylock);
  timestamp();
  vprintf(fmt, ap);
  printf("\n");
  (void) pthread_mutex_unlock(&ctylock);

  va_end(ap);
}

/*
 *  Convert an unsigned int to a string:
 */

char* i2s(u_int i, struct i2s* x)
{
  while (x->s != NULL) {
    if (x->i == i)
      return x->s;
    x++;
  }
  return "<unknown>";
}

/*
 ************************************************************************
 *
 *  Routines to get/free/manipulate packets:
 *
 ************************************************************************
 */

/*
 *  Allocate a new packet (or get one from the free list), init the
 *  major variables and set up the (new) packet type.
 */

packet* pkt_alloc(u_char type)
{
  packet* pkt;

  (void) pthread_mutex_lock(&memlock);
  pk_alloc += 1;
  if (pkt_freelist != NULL) {
    pkt = pkt_freelist;
    pkt_freelist = pkt->pkt_next;
    pk_free -= 1;
  } else {
    pkt = malloc(sizeof(struct packet));
    pk_count += 1;
  }
  (void) pthread_mutex_unlock(&memlock);

  bzero(pkt, sizeof(struct packet));

  pkt->pkt_type = type;
  pkt->pkt_data = &pkt->pkt_buf[100];
  pkt->pkt_len = 0;
  pkt->pkt_pre = 100;
  pkt->pkt_post = PSIZ - 100;
  pkt->pkt_sptr = pkt->pkt_data;

  return pkt;
}

/*
 *  Deallocate a packet, i.e. put it on the free list.
 */

void pkt_free(packet* pkt)
{
  (void) pthread_mutex_lock(&memlock);
  pk_free += 1;
  pkt->pkt_next = pkt_freelist;
  pkt_freelist = pkt;
  (void) pthread_mutex_unlock(&memlock);
}

/*
 *  Make a copy of a packet.
 */

packet* pkt_copy(packet* src)
{
  packet* dst;

  dst = pkt_alloc(src->pkt_type);
  if (dst != NULL) {
    (void) memcpy(dst, src, sizeof(struct packet));
    dst->pkt_data = &dst->pkt_buf[dst->pkt_pre];
  }

  return dst;
}

/*
 *  Prepend a block of data to a packet, optionally shifting down the
 *  start of the data.  In other words, make room for a new header.
 */

void pkt_prepend(packet* pkt, int amount, int shift)
{
  u_char* src = &pkt->pkt_data[0];
  u_char* dst = &pkt->pkt_data[-amount];

  pkt->pkt_data = dst;
  pkt->pkt_len += amount;
  pkt->pkt_pre -= amount;
  if (shift > 0) {
    (void) memmove(dst, src, shift);
  }
  bzero(&dst[shift], amount);
}

/*
 *  Append a block of data to a packet, i.e. make room for a trailer.
 */

void pkt_append(packet* pkt, int amount)
{
  bzero(&pkt->pkt_data[pkt->pkt_len], amount);
  pkt->pkt_len += amount;
  pkt->pkt_post -= amount;
}

/*
 *  Trim off header and trailer bytes from a packet.
 */

void pkt_trim(packet* pkt, int pre, int post)
{
  pkt->pkt_data += pre;
  pkt->pkt_pre  += pre;
  pkt->pkt_len  -= pre;

  pkt->pkt_post += post;
  pkt->pkt_len  -= post;
}

/*
 *  Store a byte to a packet.
 */

void pkt_store(packet* pkt, u_char c)
{
  if (pkt->pkt_post > 0) {
    *pkt->pkt_sptr++ = c;
    pkt->pkt_post -= 1;
    pkt->pkt_len += 1;
  } else {
    pkt->pkt_flags |= PKF_OVRRUN;
  }
}

/*
 *  Store an integer in a packet, in ANF-10 extensible binary format.
 */

void pkt_putebi(packet* pkt, u_int i)
{
  while (i > 0177) {
    pkt_store(pkt, (i & 0177) + 0200);
    i >>= 7;
  }
  pkt_store(pkt, i);
}

/*
 ************************************************************************
 *
 *  Ethernet (bridge table) routines:
 *
 ************************************************************************
 */

/*
 *  Allocate a new ethernet bridge table.
 */

ethost* eth_alloc(void)
{
  ethost* eth;

  (void) pthread_mutex_lock(&memlock);
  et_alloc += 1;
  if (eth_freelist != NULL) {
    eth = eth_freelist;
    eth_freelist = eth->eth_next;
    et_free -= 1;
  } else {
    eth = malloc(sizeof(struct ethost));
    et_count += 1;
  }
  (void) pthread_mutex_unlock(&memlock);

  bzero(eth, sizeof(struct ethost));

  return eth;
}

/*
 *  Deallocate an ethernet bridge table.
 */

void eth_free(ethost* eth)
{
  (void) pthread_mutex_lock(&memlock);
  et_free += 1;
  eth->eth_next = eth_freelist;
  eth_freelist = eth;
  (void) pthread_mutex_unlock(&memlock);
}

/*
 *  Lookup a mac address in an ethernet bridge.
 */

ethost* eth_lookup(bridge* br, u_char* mac, int create)
{
  ethost* eh;
  int hash;

  hash = ((mac[4] << 8) + mac[5]) % EHASHSIZE;

  for (eh = br->br_host[hash]; eh != NULL; eh = eh->eth_next) {
    if (memcmp(eh->eth_mac, mac, 6) == 0)
      return eh;
  }

  if (create) {
    (void) pthread_mutex_lock(&br->br_lock);
    eh = eth_alloc();
    memcpy(eh->eth_mac, mac, 6);
    eh->eth_next = br->br_host[hash];
    br->br_host[hash] = eh;
    br->br_count += 1;
    (void) pthread_mutex_unlock(&br->br_lock);
  }

  return eh;
}

/*
 *  Update an existing entry in a bridge table.  If unkown, make a new
 *  entry.  Set the (new) TTL to 300 seconds.
 */

void eth_update(bridge* br, u_char* mac, object* obj, u_char tag)
{
  ethost* eh;

  eh = eth_lookup(br, mac, 1);
  
  eh->eth_ttl = 300;
  eh->eth_obj = obj;
  eh->eth_tag = tag;
}

/*
 *  Do once/second timing of a bridge.
 */

void eth_tick(bridge* br)
{
  ethost* prev;
  ethost* this;
  ethost* next;
  int i;

  (void) pthread_mutex_lock(&br->br_lock);

  for (i = 0; i < EHASHSIZE; i += 1) {
    prev = NULL;
    for (this = br->br_host[i]; this != NULL; this = next) {
      next = this->eth_next;
      if (this->eth_ttl == 0) {
	if (prev != NULL) {
	  prev->eth_next = next;
	} else {
	  br->br_host[i] = next;
	}
	eth_free(this);
	br->br_count -= 1;
      } else {
	this->eth_ttl -= 1;
	prev = this;
      }
    }
  }

  (void) pthread_mutex_unlock(&br->br_lock);
}

/*
 *  Fake up a mac address for an ANF-10 node.  Used by the ETHER-SYNC
 *  conversion process.
 */

void eth_anfmac(u_char* mac, u_char node)
{
  mac[0] = 0xaa;
  mac[1] = 0x00;
  mac[2] = 0x04;
  mac[3] = 0x01;
  mac[4] = node >> 6;
  mac[5] = node & 0x3f;
  mac[5] += node & 0x38;
}

/*
 *  Update the eproto mask in an object according to the objects config.
 *
 *  Should possibly be obj_seteproto() instead.
 */

void eth_setproto(object* obj)
{
  obj->obj_eproto = 0;
  if (obj->obj_aflag) obj->obj_eproto |= OBP_ANF10;
  if (obj->obj_cflag) obj->obj_eproto |= OBP_CHAOS;
  if (obj->obj_dflag) obj->obj_eproto |= OBP_DECNET;
  if (obj->obj_lflag) obj->obj_eproto |= OBP_LAT;
  if (obj->obj_4flag) obj->obj_eproto |= OBP_IPV4;
  if (obj->obj_6flag) obj->obj_eproto |= OBP_IPV6;

  if (obj->obj_eproto == 0)
    obj->obj_eproto = OBP_ANF10;
}

/*
 ************************************************************************
 *
 *  bridge member alloc/free/etc. routines:
 *
 ************************************************************************
 */

member* mbr_alloc(void)
{
  member* mbr;

  (void) pthread_mutex_lock(&memlock);
  mb_alloc += 1;
  if (mbr_freelist != NULL) {
    mbr = mbr_freelist;
    mbr_freelist = mbr->mbr_next;
    mb_free -= 1;
  } else {
    mbr = malloc(sizeof(struct member));
    mb_count += 1;
  }
  (void) pthread_mutex_unlock(&memlock);

  bzero(mbr, sizeof(struct member));

  return mbr;
}

void mbr_free(member* mbr)
{
  (void) pthread_mutex_lock(&memlock);
  mb_free += 1;
  mbr->mbr_next = mbr_freelist;
  mbr_freelist = mbr;
  (void) pthread_mutex_unlock(&memlock);
}

void mbr_add(bridge* br, object* obj, u_char tag)
{
  member* mb;

  for (mb = br->br_members; mb != NULL; mb = mb->mbr_next) {
    if (mb->mbr_obj == obj) {
      mb->mbr_tag = tag;
      return;
    }
  }

  mb = mbr_alloc();
  mb->mbr_next = br->br_members;
  br->br_members = mb;

  mb->mbr_bridge = br;
  mb->mbr_obj = obj;
  mb->mbr_tag = tag;
}

/*
 ************************************************************************
 *
 *  Routines to manipulate objects:
 *
 ************************************************************************
 */

/*
 *  Allocate an object.
 */

object* obj_alloc(void)
{
  object* obj;

  (void) pthread_mutex_lock(&memlock);
  ob_alloc += 1;
  if (obj_freelist != NULL) {
    obj = obj_freelist;
    obj_freelist = obj->obj_next;
    ob_free -= 1;
  } else {
    obj = malloc(sizeof(struct object));
    ob_count += 1;

    bzero(obj, sizeof(struct object));
    (void) pthread_mutex_init(&obj->obj_lock, NULL);
  }
  (void) pthread_mutex_unlock(&memlock);

  return obj;
}

void obj_free(object* obj)
{
  /*
   *  At this time, the object should have been unlinked from
   *  whereever it was, and there should be no references to
   *  it from anywhere.  Therefore we can safely scrub it clean
   *  before putting it on the free list.
   *
   *  Things to deallocate are:
   *
   *  ddcmp, ipcon, route, tags and bridge structures.  Possibly more.
   */

  (void) free(obj->obj_name);

  /* Clear out all stale data. */

  // bzero(obj, sizeof(struct object));

  /* Finally, put object on free list. */

  (void) pthread_mutex_lock(&memlock);
  ob_free += 1;
  obj->obj_next = obj_freelist;
  obj_freelist = obj;
  (void) pthread_mutex_unlock(&memlock);
}

void obj_linkin(object* obj, object* parent)
{
  obj->obj_parent = parent;

  if (parent != NULL) {
    if (parent->obj_chtail != NULL) {
      parent->obj_chtail->obj_next = obj;
      parent->obj_chtail = obj;
    } else {
      parent->obj_chlist = obj;
      parent->obj_chtail = obj;
    }
  } else {
    if (objtail != NULL) {
      objtail->obj_next = obj;
      objtail = obj;
    } else {
      objlist = obj;
      objtail = obj;
    }
  }
}

object* obj_lookup(char* name, int create)
{
  object* obj;

  for (obj = objlist; obj != NULL; obj = obj->obj_next) {
    if (strcmp(name, obj->obj_name) == 0)
      return obj;
  }

  if (create) {
    obj = obj_alloc();
    obj->obj_name = strdup(name); /* Copy ? */
    obj->obj_type = OBT_NONE;	/* Newborn. */
  }

  return obj;
}

/*
 *  Make sure the object has a bridge block:
 */

void obj_mk_bridge(object* obj)
{
  if (obj->obj_bridge != NULL)
    return;

  obj->obj_bridge = calloc(1, sizeof(struct bridge));
  (void) pthread_mutex_init(&obj->obj_bridge->br_lock, NULL);
}

/*
 *  Make sure the object has an ip conn block:
 */

void obj_mk_ipcon(object* obj)
{
  if (obj->obj_ipcon != NULL)
    return;

  obj->obj_ipcon = calloc(1, sizeof(struct ipcon));
  obj->obj_ipcon->ip_object = obj;
  obj->obj_ipcon->ip_socket = -1;
}

/*
 *  Make sure the object has a ddcmp block and an ip conn block:
 */

void obj_mk_ddcmp(object* obj)
{
  if (obj->obj_ddcmp != NULL)
    return;

  obj->obj_ddcmp = calloc(1, sizeof(struct ddcmp));
  obj->obj_ddcmp->dd_object = obj;

  obj_mk_ipcon(obj);
  
  obj->obj_ddcmp->dd_ipcon = obj->obj_ipcon;
  obj->obj_ipcon->ip_ddcmp = obj->obj_ddcmp;
}

/*
 *  Check proposed object name for allowed syntax.
 *  Essentially disallow names that will be used for sub-objects.
 *
 *  At the moment sub-objects are named "%nnnnn" in some kind of
 *  numerical order.
 */

int obj_chkname(char* name)
{
  if (name == NULL)
    return 0;
  if (name[0] == '%')
    return 0;

  return 1;
}

/*
 *  Create an object with the specified name and type.  If an object
 *  already exists with that name, return it.
 */

object* obj_create(int type, char* name)
{
  object* obj;

  obj = obj_lookup(name, 1);

  if (obj->obj_type == OBT_NONE) {
    obj->obj_type = type;
    obj_linkin(obj, NULL);

    switch (type) {
    case OBT_BRIDGE:
      obj_mk_bridge(obj);
      break;
    case OBT_ETHER:
      if (obj->obj_route == NULL)
	obj->obj_route = calloc(128, sizeof(struct nodedata));
      obj_mk_bridge(obj);
      obj->obj_port = 0x6016;	/* Default ethernet protocol. */
      break;
    case OBT_TUNNEL:
      if (obj->obj_tags == NULL)
	obj->obj_tags = calloc(256, sizeof(struct tagblock));
      obj_mk_ipcon(obj);
      break;
    case OBT_SYNC:
    case OBT_UDP:
      obj_mk_ddcmp(obj);
      break;
    case OBT_MLT:
      obj_mk_ipcon(obj);
      break;
    case OBT_CMD:
      obj_mk_ipcon(obj);
      obj->obj_port = 6016;	/* As good a default as any. */
      break;
    default:
      /*
       *  This is an error.
       */
      break;
    }
    obj->obj_oqsize = 10;	/* Default queue size. */

    /* set up more? */

    return obj;
  }

  /* Existing object.  Complain if wrong type. */

  if (obj->obj_type != type) {
    printx("object %s already exists, with type %s.\n",
	   obj->obj_name, i2s(obj->obj_type, obj_type_names));
  }

  return obj;
}

/*
 *  Make a clone of this object.
 */

object* obj_clone(object* obj)
{
  /*
   *  Allocate a new object block, copy us into it.  Make copies of all
   *  sub-data blocks, like ip connection blocks and such.  Set up our
   *  name to something like "%001" or whatever that is not allowed for
   *  top level objects.  Link us in as a child of the original object.
   *  Start a thread, and fix up IP connections.
   */

  return NULL;
}

/*
 *  Make this object disappear totally.
 */

void obj_destroy(object* obj)
{
  /* needs writing. */
}

/*
 *  Release any global locks we might have.  Since the pthreads API
 *  does not have any way of checking if we own a specific mutex, we
 *  just try to unlock all of them, and ignore failures.
 */

void obj_unlock(object* obj)
{
  (void) pthread_mutex_unlock(&ctylock);
  (void) pthread_mutex_unlock(&memlock);
  (void) pthread_mutex_unlock(&cmdlock);
  (void) pthread_mutex_unlock(&pcaplock);
}

/*
 *  Update an ethernet objects node block from an incoming nodeid
 *  packet.  We have checked the usual things.
 */

void nodeid_update(object* obj, packet* pkt, object* src,
		   u_short flags, u_char peer)
{
  nodedata* node;

  if (pkt->anf_nnum <= 127) {
    (void) pthread_mutex_lock(&obj->obj_lock);
    node = &obj->obj_route[pkt->anf_nnum];
    node->nd_flags |= NDF_VALID;
    node->nd_flags |= flags;	/* Include user flag(s). */
    node->nd_ttl = 300;		/* Reset to a reasonable value. */
    node->nd_target = src;
    node->nd_peer = peer;
    node->nd_tag = pkt->pkt_tag;

    node->nd_nvr = pkt->anf_nvr;
    node->nd_nis = pkt->anf_nis;
    node->nd_nit = pkt->anf_nit;
    memcpy(node->nd_nam, pkt->anf_snm, SSIZ);
    memcpy(node->nd_sid, pkt->anf_sid, SSIZ);
    memcpy(node->nd_dat, pkt->anf_dat, SSIZ);
    memcpy(node->nd_mac, &pkt->pkt_data[6], 6);
    (void) pthread_mutex_unlock(&obj->obj_lock);
  }
}

/*
 ************************************************************************
 *
 *  Routines to parse (ANF-10) packets.
 *
 ************************************************************************
 */

/*
 *  Return next byte from a stream:
 */

u_char ap_getbyte(anfs* a)
{
  if (a->ctr-- < 0)
    return 0;
  return *a->ptr++;
}

/*
 *  Return a number in extensible binary format:
 */

u_int ap_getebi(anfs* a)
{
  u_int num, shift;
  u_char c;

  num = 0;
  shift = 0;

  for (;;) {
    c = ap_getbyte(a);
    num += (c & 0x7f) << shift;
    if (!(c & 0x80))
      return num;
    shift += 7;
  }
}

/*
 *  Return an extensible ASCII string:
 */

u_int ap_geteascii(anfs* a, u_char* store, int max)
{
  u_char c;
  int i;

  for  (i = 1;; i += 1) {
    c = ap_getbyte(a);
    if (i < max)
      *store++ = c & 0x7f;
    if (!(c & 0x80)) {
      *store = 0;
      return i;
    }
  }
}

/*
 *  Try to parse a packet as an ANF-10 message.  Store various
 *  items as metadata in the packet structure.  Returns true if
 *  this worked, and remember the fact.
 */

int anf_parse(packet* pkt)
{
  struct anfstream as;
  struct anfstream* a = &as;
  
  if (pkt->pkt_flags & PKF_APARSE) {
    if (pkt->pkt_flags & PKF_ANF)
      return 1;
    return 0;
  }

  pkt->pkt_flags |= PKF_APARSE;

  switch (pkt->pkt_type) {
  case PKT_RAW:
    as.ptr = pkt->pkt_data;
    as.ctr = pkt->pkt_len;
    break;
  case PKT_DDCMP:
    as.ptr = &pkt->pkt_data[8];
    as.ctr = pkt->pkt_len - 10;
    break;
  case PKT_ETHER:
    as.ptr = &pkt->pkt_data[16];
    as.ctr = pkt->pkt_len - 16;
    break;
  default:
    return 0;
  }

  pkt->anf_nct = ap_getbyte(a);
  pkt->anf_dna = 0;
  pkt->anf_sna = 0;
  if (pkt->anf_nct & NCT_RH) {
    pkt->anf_dna = ap_getebi(a);
    pkt->anf_sna = ap_getebi(a);
  }
  pkt->anf_nca = ap_getbyte(a);
  pkt->anf_ncn = ap_getbyte(a);

  pkt->anf_data = as.ptr;

  pkt->anf_type = pkt->anf_nct & NCT_TYPE;

  switch (pkt->anf_type) {
  case NCTT_DATA:
    pkt->anf_dla = ap_getebi(a);
    if (pkt->anf_dla == 0) {
      pkt->anf_type = NCTT_CONTROL; /* Set up pseudo-type. */
      /*
       *  Here we should identify sub-types, such as neighbours msgs.
       */
    }
    break;
  case NCTT_NODEID:
    pkt->anf_nnum = ap_getebi(a);
    (void) ap_geteascii(a, pkt->anf_snm, SSIZ); /* System name. */
    (void) ap_geteascii(a, pkt->anf_sid, SSIZ); /* System ID. */
    (void) ap_geteascii(a, pkt->anf_dat, SSIZ); /* System date. */
    pkt->anf_nitptr = as.ptr;	/* Save for rewriting. */
    pkt->anf_nit = ap_getbyte(a);
    if (pkt->anf_nit == NIT_BC)
      pkt->anf_nis = ap_getebi(a);
    pkt->anf_nvr = ap_getebi(a);
    break;
  }

  pkt->pkt_flags |= PKF_ANF;
  return 1;
}

/*
 ************************************************************************
 *
 *  Helper routines for doing ETH <-> SYNC conversions:
 *
 ************************************************************************
 */

/*
 *  Generate a nodeid packet from the objects template.  Set the timer
 *  for next time.
 */

packet* ether_nodeid(object* obj)
{
  packet* pkt;
  u_char* eh;
  u_short len;

  obj->obj_nidpkt->anf_nis += 1;
  obj->obj_timer = 60;

  pkt = pkt_copy(obj->obj_nidpkt);

  pkt->pkt_srcnode = pkt->anf_nnum;

  pkt_store(pkt, pkt->anf_nit);
  pkt_putebi(pkt, pkt->anf_nis);
  pkt_putebi(pkt, pkt->anf_nvr);

  len = pkt->pkt_len - 16;	/* Get length of actual payload. */

  eh = pkt->pkt_data;
  eth_anfmac(&eh[6], obj->obj_srcnode);
  eh[14] =  len       & 0xff;
  eh[15] = (len >> 8) & 0xff;

  if (obj->obj_flags & OBF_NEIGHB) {
    eh[0] = obj->obj_peermac[0];
    eh[1] = obj->obj_peermac[1];
    eh[2] = obj->obj_peermac[2];
    eh[3] = obj->obj_peermac[3];
    eh[4] = obj->obj_peermac[4];
    eh[5] = obj->obj_peermac[5];

    eh[12] = obj->obj_peerpty >> 8;
    eh[13] = obj->obj_peerpty & 0xff;
  }

  return pkt;
}

/*
 *  Do all the magic involved in transforming a serial line packet to
 *  an ethernet one.  Return packet (possibly a new one) if successful.
 */

packet* ether_from_sync(object* obj, packet* pkt)
{
  ddcmp* dd = obj->obj_ddcmp;
  u_short len;
  u_char* eh;

  if (dd->dd_flags & DDF_ANF) {
    if (anf_parse(pkt)) {
      len = pkt->pkt_len;
      pkt_prepend(pkt, 16, 0);
      pkt->pkt_type = PKT_ETHER;
      pkt->pkt_node = obj->obj_node;
      pkt->pkt_srcnode = obj->obj_srcnode;
      pkt->pkt_proto = PROTO_ANF10;

      eh = pkt->pkt_data;
      eth_anfmac(&eh[6], obj->obj_srcnode);
      eh[14] =  len       & 0xff;
      eh[15] = (len >> 8) & 0xff;

      if (pkt->anf_type == NCTT_NODEID) {
	obj->obj_srcnode = pkt->anf_nnum; /* Remember for later. */
	if (obj->obj_nidpkt != NULL) {
	  pkt_free(obj->obj_nidpkt);
	}
	pkt->anf_nis = 0;
	pkt->anf_nit = NIT_BC;
	pkt_trim(pkt, 0, 2);  /* Forget last 2 bytes (nit and nvr). */
	pkt->pkt_sptr = &pkt->pkt_data[pkt->pkt_len];

	obj->obj_nidpkt = pkt;

	pkt = ether_nodeid(obj);
      }
      if (obj->obj_flags & OBF_NEIGHB) {
	eh[0] = obj->obj_peermac[0];
	eh[1] = obj->obj_peermac[1];
	eh[2] = obj->obj_peermac[2];
	eh[3] = obj->obj_peermac[3];
	eh[4] = obj->obj_peermac[4];
	eh[5] = obj->obj_peermac[5];

	eh[12] = obj->obj_peerpty >> 8;
	eh[13] = obj->obj_peerpty & 0xff;
      }
      return pkt;
    }
  }

  pkt_free(pkt);
  return NULL;
}

/*
 *  An ethernet packet got sent to a sync line.  Do all the magic...
 */

packet* ether_to_sync(object* obj, packet* pkt)
{
  u_char* eh = pkt->pkt_data;

  pkt_trim(pkt, 16, 0);
  pkt->pkt_type = PKT_RAW;
  pkt->pkt_len = eh[14] + (eh[15] << 8);

  if (anf_parse(pkt)) {
    if (pkt->anf_type == NCTT_NODEID) {
      if (obj->obj_flags & OBF_NEIGHB) {
	obj->obj_serial = pkt->anf_nis;

	/*
	 *  Set the TTL for nodeids to something like 300 s.
	 */

	pkt_free(pkt);
	return NULL;
      }

      obj->obj_flags |= OBF_NEIGHB;
      obj->obj_serial = pkt->anf_nis;
      memcpy(obj->obj_peermac, &eh[6], 6);
      obj->obj_peerpty = (eh[12] << 8) + eh[13];

      pkt->pkt_len = (pkt->anf_nitptr - pkt->pkt_data);
      pkt->pkt_sptr = pkt->anf_nitptr;

      pkt_store(pkt, NIT_PP);
      pkt_putebi(pkt, pkt->anf_nvr);

      /*
       *  Set the TTL for nodeids to something like 300 s.
       */

      return pkt;

    }

    if (obj->obj_flags & OBF_NEIGHB) {
      return pkt;
    }
  }

  pkt_free(pkt);
  return NULL;
}

/*
 ************************************************************************
 *
 *  General network I/O routines:
 *
 ************************************************************************
 */

/*
 *  Open a network connection, UDP or TCP depending on object type.
 */

void net_open(object* obj)
{
  struct ipcon* ipc = obj->obj_ipcon;
  struct sockaddr_in loc_addr;    /* Local address of this connection. */
  struct sockaddr_in rem_addr;    /* Remote address of this connection. */
  socklen_t rem_len;
  int flag;
  int sock;

  ipc->ip_socket = -1;		/* Leave zero in case of errors. */
  
  if (obj->obj_type == OBT_UDP) { /* UDP open. */
    sock = socket(AF_INET, SOCK_DGRAM, 0);
    if (sock < 0) {
      ctyprintf("socket() failed, object %s, errno = %d (%s)",
		obj->obj_name, errno, strerror(errno));
      return;
    }
    bzero(&loc_addr, sizeof(struct sockaddr_in));
    loc_addr.sin_family = AF_INET;
    loc_addr.sin_addr.s_addr = inet_addr("127.0.0.1");
    loc_addr.sin_port = htons(obj->obj_lport);
    if (bind(sock, (struct sockaddr*) &loc_addr,
	     sizeof(struct sockaddr)) < 0) {
      ctyprintf("bind() failed, object %s, errno = %d (%s)",
		obj->obj_name, errno, strerror(errno));
      return;
    }

    bzero(&rem_addr, sizeof(struct sockaddr_in));
    rem_addr.sin_family = AF_INET;
    if (obj->obj_remote != NULL) {
      rem_addr.sin_addr.s_addr = inet_addr(obj->obj_remote);
    } else {
      rem_addr.sin_addr.s_addr = inet_addr("127.0.0.1");
    }
    rem_addr.sin_port = htons(obj->obj_port);
    if (connect(sock, (struct sockaddr*) &rem_addr,
		sizeof(struct sockaddr)) < 0) {
      ctyprintf("Connect failed, object %s, errno = %d (%s)",
		obj->obj_name, errno, strerror(errno));
      return;
    }
    ipc->ip_socket = sock;
    ipc->ip_state = IPS_UP;
    ddcmp_dcd_on(obj);
  } else if (obj->obj_remote != NULL) { /* TCP, active open: */
    for (;;) {
      sock = socket(AF_INET, SOCK_STREAM, 0);
      if (sock < 0) {
	ctyprintf("socket() failed, object %s, errno = %d (%s)",
		  obj->obj_name, errno, strerror(errno));
	return;
      }
      if (verbose)
	ctyprintf("net_open: got socket %d", sock);
      bzero(&rem_addr, sizeof(struct sockaddr_in));
      rem_addr.sin_family = AF_INET;
      if (obj->obj_remote != NULL) {
	rem_addr.sin_addr.s_addr = inet_addr(obj->obj_remote);
      } else {
	rem_addr.sin_addr.s_addr = inet_addr("127.0.0.1");
      }
      rem_addr.sin_port = htons(obj->obj_port);
      if (connect(sock, (struct sockaddr*) &rem_addr,
		  sizeof(struct sockaddr)) < 0) {
	switch (errno) {
	case ETIMEDOUT:
	case ECONNREFUSED:
	case ENETUNREACH:
	default:
	  if (verbose) {
	    ctyprintf("Connect failed, object %s, errno = %d (%s)",
		      obj->obj_name, errno, strerror(errno));
	  }
	  sleep(15);
	  break;
	}
	close(sock);
      } else {
	ipc->ip_socket = sock;
	ipc->ip_state = IPS_UP;
	ddcmp_dcd_on(obj);
	return;
      }
    }
  } else {			/* TCP, passive open: */
    if (!(ipc->ip_flags & IPF_MASTER)) {
      if (verbose) {
	ctyprintf("Object %s: opening master socket on port %d",
		  obj->obj_name, obj->obj_port);
      }
      sock = socket(AF_INET, SOCK_STREAM, 0);
      if (sock < 0) {
	ctyprintf("socket() failed, object %s, errno = %d (%s)",
		  obj->obj_name, errno, strerror(errno));
	return;
      }
      flag = 1;
      (void) setsockopt(sock, SOL_SOCKET, SO_REUSEADDR, &flag, sizeof(flag));
      bzero(&loc_addr, sizeof(struct sockaddr_in));
      loc_addr.sin_family = AF_INET;
      loc_addr.sin_addr.s_addr = htonl(INADDR_ANY);
      loc_addr.sin_port = htons(obj->obj_port);
      if (bind(sock, (struct sockaddr*) &loc_addr,
	       sizeof(struct sockaddr)) < 0) {
	ctyprintf("Bind failed, object %s, errno = %d (%s)",
		  obj->obj_name, errno, strerror(errno));
	close(sock);
	sleep(1);
	return;
      }
      if (listen(sock, 1) < 0) {
	ctyprintf("Listen failed, object %s, errno = %d (%s)",
		  obj->obj_name, errno, strerror(errno));
	close(sock);
	return;
      }
      ipc->ip_master = sock;
      ipc->ip_flags |= IPF_MASTER;
    }
    ipc->ip_state = IPS_WAIT;

    sock = accept(ipc->ip_master, (struct sockaddr*) &rem_addr, &rem_len);
    if (sock < 0) {
      ctyprintf("Accept failed, object %s, errno = %d (%s)",
		obj->obj_name, errno, strerror(errno));
      ipc->ip_state = IPS_WAIT;
      return;
    }
    ipc->ip_state = IPS_UP;
    ipc->ip_socket = sock;
    ddcmp_dcd_on(obj);
  }
}

/*
 *  Close a network connection.
 */

void net_close(struct ipcon* ipc)
{
  if (verbose)
    ctyprintf("net_close: socket = %d", ipc->ip_socket);
  if (ipc->ip_socket < 0)
    return;

  close(ipc->ip_socket);
  ipc->ip_socket = -1;
  ipc->ip_state = IPS_DOWN;
  ddcmp_dcd_off(ipc->ip_object);
  prng_free(ipc->ip_rxcrypt);
  prng_free(ipc->ip_txcrypt);
  ipc->ip_rxcrypt = NULL;
  ipc->ip_txcrypt = NULL;
  ipc->ip_flags &= ~IPF_CRYPTO;
}

/*
 *  Set a connection non-blocking (or not).
 */

void net_nb_set(struct ipcon* ipc, int flag)
{
  (void) ioctl(ipc->ip_socket, FIONBIO, &flag);
  if (flag) {
    ipc->ip_flags |= IPF_NBLOCK;
  } else {
    ipc->ip_flags &= ~IPF_NBLOCK;
  }
}

/*
 *  Read data from a non-blocking connection, return empty if the object
 *  timer has run out.
 */

int net_nb_read(struct ipcon* ipc, u_char* buf, u_int size)
{
  struct object* obj = ipc->ip_object;
  struct timeval tv;
  fd_set fds;
  int count;
  int sock = ipc->ip_socket;

  for (;;) {
    FD_ZERO(&fds);
    FD_SET(sock, &fds);

    tv.tv_sec = 1;
    tv.tv_usec = 0;

    count = select(sock + 1, &fds, NULL, NULL, &tv);

    if (obj->obj_timer <= 0)	/* Global timeout.  Fail. */
      return 0;

    if (count < 0)		/* Error.  Fail. */
      return 0;

    if (count == 0)		/* Read timeout.  Try again. */
      continue;

    count = recv(ipc->ip_socket, buf, size, 0);
    return 1;
  }
}

/*
 *  Write data to a non-blocking connection, return if the object
 *  timer has run out.
 */

int net_nb_write(struct ipcon* ipc, u_char* buf, u_int size)
{
  if (verbose) {
    ctyprintf("net_nb_write: %d bytes", size);
  }

  (void) send(ipc->ip_socket, buf, size, 0);
  return 1;
}

/*
 *  Get next byte from a TCP connection.  Returns EOF if so happens.
 */

int net_getbyte(struct ipcon* ipc)
{
  int ret;

  for (;;) {
    if (ipc->ip_ipos < ipc->ip_isiz)
      return ipc->ip_ibuf[ipc->ip_ipos++];

    if (ipc->ip_state != IPS_UP)
      return EOF;

    ret = recv(ipc->ip_socket, ipc->ip_ibuf, sizeof(ipc->ip_ibuf), 0);
    if (verbose) {
      ctyprintf("net_getbyte: recv %d, errno = %d\n", ret, errno);
    }
    if (ret <= 0) {
      switch (errno) {
      case EAGAIN:
      case EINTR:
	break;
      default:
	net_close(ipc);
	return EOF;
      }
    } else {
      ipc->ip_ipos = 0;
      ipc->ip_isiz = ret;
    }
  }
}

/*
 *  Perform authentication on a (tunnel) connection.
 *  If it fails, close the connection and set state to down.
 */

void do_auth(object* obj)
{
  struct ipcon* ipc = obj->obj_ipcon;
  u_char rxsalt[SALTSIZE];
  u_char txsalt[SALTSIZE];
  u_char buffer[SALTSIZE];
  int i;

  if (obj->obj_key == NULL)	/* No key, always succeed. */
    return;

  ipc->ip_state = IPS_AUTH;	/* While we are here. */

  obj->obj_timer = 5;		/* Timeout for this operation. */

  net_nb_set(ipc, 1);

  prng_random(rxsalt, SALTSIZE);

  if (!net_nb_write(ipc, rxsalt, SALTSIZE)) goto fail;
  if (!net_nb_read(ipc, txsalt, SALTSIZE)) goto fail;

  if (memcmp(rxsalt, txsalt, SALTSIZE) == 0) {
    if (verbose)
      ctyprintf("Auth: fail, rxsalt == txsalt");
    goto fail;
  }

  ipc->ip_rxcrypt = prng_init(rxsalt, obj->obj_key);
  ipc->ip_txcrypt = prng_init(txsalt, obj->obj_key);

  for (i = 0; i < SALTSIZE; i += 1) {
    buffer[i] = prng_getbyte(ipc->ip_txcrypt);
  }
  if (!net_nb_write(ipc, buffer, SALTSIZE)) goto fail;
  if (!net_nb_read(ipc, buffer, SALTSIZE)) goto fail;

  for (i = 0; i < SALTSIZE; i += 1) {
    if (buffer[i] != prng_getbyte(ipc->ip_rxcrypt)) {
      if (verbose)
	ctyprintf("Auth: fail, bad handshake");
      goto fail;
    }
  }

  ipc->ip_state = IPS_UP;
  ipc->ip_flags |= IPF_CRYPTO;
  goto done;

 fail:
  if (verbose) {
    ctyprintf("Auth: closing connection");
  }
  sleep(1);			/* Prevent hammering. */
  net_close(ipc);

 done:
  obj->obj_timer = 0;
  net_nb_set(ipc, 0);
}


/*
 ************************************************************************
 *
 *  Routines to write packets to objects.
 *
 ************************************************************************
 */

/*
 *  Queue up a packet to be transmitted by an objects output thread.
 *  Called with object locked.
 */

void queue_packet(object* obj, packet* pkt)
{
  if (obj->obj_oqhead != NULL) {
    if (obj->obj_oqlen >= obj->obj_oqsize) {
      obj->obj_oqdrop += 1;
      pkt_free(pkt);
    } else {
      obj->obj_oqtail->pkt_next = pkt;
      obj->obj_oqtail = pkt;
    }
    obj->obj_oqlen += 1;
  } else {
    obj->obj_oqhead = pkt;
    obj->obj_oqtail = pkt;
    obj->obj_oqlen = 1;
    (void) pthread_cond_signal(&obj->obj_wcond);
  }
  if (obj->obj_oqlen > obj->obj_oqmax) {
    obj->obj_oqmax = obj->obj_oqlen;
  }
}

/* Forward declaration: */

void write_packet(object* obj, packet* pkt);

/*
 *  Write a packet to a bridge object.
 */

void write_bridge(object* obj, packet* pkt)
{
  bridge* br = obj->obj_bridge;
  u_char* dstmac = &pkt->pkt_data[0];
  u_char* srcmac = &pkt->pkt_data[6];
  object* origin = pkt->pkt_src;

  ethost* eh;
  member* mb;

  if (pkt->pkt_type != PKT_ETHER) {
    pkt_free(pkt);
    return;
  }

  eth_update(br, srcmac, origin, pkt->pkt_tag);

  eh = eth_lookup(br, dstmac, 0);

  pkt->pkt_src = obj;

  if (eh != NULL) {
    pkt->pkt_tag = eh->eth_tag;
    write_packet(eh->eth_obj, pkt);
    return;
  }

  /* Unknown, or multicast.  Flood packet. */

  for (mb = br->br_members; mb != NULL; mb = mb->mbr_next) {
    if (mb->mbr_obj != origin) {
      pkt->pkt_tag = mb->mbr_tag;
      write_packet(mb->mbr_obj, pkt_copy(pkt));
    }
  }
  pkt_free(pkt);
}

/*
 *  Write a packet to an ethernet object.
 */

void write_ethernet(object* obj, packet* pkt)
{
  u_char* eh;
  u_short ep;
  u_short pty;
  u_char peer;
  nodedata* nd;

  if (pkt->pkt_type != PKT_ETHER)
    goto done;

  eh = pkt->pkt_data;
  eth_update(obj->obj_bridge, &eh[6], pkt->pkt_src, pkt->pkt_tag);

  switch (pkt->pkt_proto) {
  case PROTO_ANF10:
    ep = OBP_ANF10;
    break;
  case PROTO_CHAOS:
    ep = OBP_CHAOS;
    break;
  case PROTO_DECNET:
    ep = OBP_DECNET;
    break;
  case PROTO_LAT:
    ep = OBP_LAT;
    break;
  case PROTO_IPV4:
    ep = OBP_IPV4;
    break;
  case PROTO_IPV6:
    ep = OBP_IPV6;
    break;
  default:
    ep = 0;
    break;
  }

  if (!(ep & obj->obj_eproto))
    goto done;

  pty = (eh[12] << 8) + eh[13];

  if (pkt->pkt_proto == PROTO_ANF10) {

    /*
     *  if pty == 0, this is a fake packet from a serial line.  Set up 
     *  our protocol type and find the node to send to, insert its mac
     *  address as destination (this field should also be zero).
     */

    if (pty == 0) {
      peer = pkt->pkt_node;
      if (peer == 0)
	peer = obj->obj_node;
      if (peer == 0)
	goto done;
      if (peer > 127)
	goto done;
      
      if (!anf_parse(pkt))
	goto done;
      if (pkt->anf_type == NCTT_NODEID) {
	nodeid_update(obj, pkt, pkt->pkt_src, NDF_SYNC, peer);
      }

      nd = &obj->obj_route[peer];
      if (!(nd->nd_flags & NDF_VALID))
	goto done;
      memcpy(&eh[0], nd->nd_mac, 6);
    }
    eh[12] = obj->obj_port >> 8;
    eh[13] = obj->obj_port & 0xff;
  }

  (void) pcap_inject(obj->obj_pcap, pkt->pkt_data, pkt->pkt_len);

 done:

  pkt_free(pkt);
}

/*
 *  Write a packet to a tunnel object.
 */

void write_tunnel(object* obj, packet* pkt)
{
  struct ipcon* ipc = obj->obj_ipcon;
  u_char* hdr;
  int len;
  u_char c;

  if (ipc->ip_state == IPS_UP) {

    if (ipc->ip_flags & IPF_CRYPTO) {
      c = prng_getbyte(ipc->ip_txcrypt);
      prng_skip(ipc->ip_txcrypt, (c & 0xf0) >> 4);
      pkt_prepend(pkt, c & 0x0f, 0);
      pkt_append(pkt, 16 - (c & 0x0f));
      prng_encrypt(ipc->ip_txcrypt, pkt->pkt_data, pkt->pkt_len);
    }

    len = pkt->pkt_len;
    pkt_prepend(pkt, 8, 0);
    hdr = pkt->pkt_data;
    hdr[0] = (len >> 8) & 0xff;
    hdr[1] =  len       & 0xff;
    hdr[2] = pkt->pkt_tag;
    hdr[3] = pkt->pkt_type;
    hdr[4] = pkt->pkt_node;
    hdr[5] = pkt->pkt_proto;
    hdr[6] = 0;
    hdr[7] = 0;

    /*
     *  Queue the packet for the writer thread instead.
     */

    send(ipc->ip_socket, pkt->pkt_data, pkt->pkt_len, 0);
  }

  pkt_free(pkt);
}

/*
 *  Write a packet to a sync (any) object.  Common code.
 */

void write_sync(object* obj, packet* pkt)
{
  switch (pkt->pkt_type) {
  case PKT_RAW:
    ddcmp_xmit(obj, pkt);
    break;
  case PKT_DDCMP:
    queue_packet(obj, pkt);
    break;
  case PKT_ETHER:
    pkt = ether_to_sync(obj, pkt);
    if (pkt != NULL)
      ddcmp_xmit(obj, pkt);
    break;
  default:
    /* No idea what to do. */
    pkt_free(pkt);
    break;
  }
}

/*
 *  Write a packet to a sync (UDP) object.
 */

void write_udp(object* obj, packet* pkt)
{
  struct ddcmp* dd = obj->obj_ddcmp;

  if (pkt->pkt_type == PKT_DDCMP) {
    if (dd->dd_flags & DDF_NOCRC) {
      if (pkt->pkt_len > 8) {
	bcopy(&pkt->pkt_data[0], &pkt->pkt_data[2], 6);
	pkt->pkt_data += 2;
	pkt->pkt_len -= 4;
      } else {
	pkt->pkt_len -= 2;
      }
    }
  }

  write_sync(obj, pkt);
}

/*
 *  Write a packet to a multinet object.
 */

void write_mlt(object* obj, packet* pkt)
{
  int len = pkt->pkt_len;
  u_char* hdr;

  /* We should only allow raw packets. */

  pkt_prepend(pkt, 4, 0);
  hdr = pkt->pkt_data;

  hdr[0] =  len       & 0xff;
  hdr[1] = (len << 8) & 0xff;
  hdr[2] = 0;
  hdr[3] = 0;

  queue_packet(obj, pkt);
}

/*
 *  Write a packet to a log object.
 */

void write_log(object* obj, packet* pkt)
{
  u_char* data = &pkt->pkt_data[0];
  int len = pkt->pkt_len;
  int i;

  (void) pthread_mutex_lock(&ctylock);
  timestamp();
  printx("write_log: got packet, src = %s, type = %s\n", 
	 pkt->pkt_src->obj_name, i2s(pkt->pkt_type, pkt_type_names));
  printx("  tag = %u, flags = %x", pkt->pkt_tag, pkt->pkt_flags);
  printbits(pkt->pkt_flags, pkt_flag_names);
  printx(", node = %o, src = %o", pkt->pkt_node, pkt->pkt_srcnode);
  printx(", proto = %d (%s)", pkt->pkt_proto,
	 i2s(pkt->pkt_proto, proto_names));
  printx("\n");

  if (obj->obj_vflag) {
    if (len > 0) {
      printx(" ");
      for (i = 0; i < len; i += 1) {
	printx(" %02x", data[i]);
	if ((i & 0x0f) == 15) {
	  printx("\n ");
	}
      }
      printx("\n");
    }
  }

  (void) pthread_mutex_unlock(&ctylock);

  pkt_free(pkt);
}

/*
 *  Write a packet to an object.  This code essentially takes over
 *  the packet and is resposible for deallocating it.  If the target
 *  is NULL the packet is just deallocated.
 */

void write_packet(object* obj, packet* pkt)
{
  if (frozen) {
    pkt_free(pkt);
    return;
  }

  if ((obj != NULL) &&
      (obj->obj_flags & OBF_READY)) {
    (void) pthread_mutex_lock(&obj->obj_lock);
    switch (obj->obj_type) {
    case OBT_BRIDGE:
      write_bridge(obj, pkt);
      break;
    case OBT_ETHER:
      write_ethernet(obj, pkt);
      break;
    case OBT_TUNNEL:
      write_tunnel(obj, pkt);
      break;
    case OBT_SYNC:
      write_sync(obj, pkt);
      break;
    case OBT_UDP:
      write_udp(obj, pkt);
      break;
    case OBT_LOG:
      write_log(obj, pkt);
      break;
    case OBT_MLT:
      write_mlt(obj, pkt);
      break;
    default:
      pkt_free(pkt);
      break;
    }
    (void) pthread_mutex_unlock(&obj->obj_lock);
  } else {
    pkt_free(pkt);
  }
}

/*
 ************************************************************************
 *
 *  DDCMP handling.
 *
 ************************************************************************
 */

/*
 *  Print out a (ddcmp) packet.  Debug routine.
 */

void ddcmp_cty_print(char* msg, packet* pkt)
{
  u_char* hdr = &pkt->pkt_data[0];
  u_char* data = &pkt->pkt_data[8];
  int len = pkt->pkt_len;
  int i;

  (void) pthread_mutex_lock(&ctylock);
  timestamp();
  printx("%s (%d):  %02x %02x %02x %02x %02x %02x %02x %02x\n", msg, len,
	 hdr[0], hdr[1], hdr[2], hdr[3], hdr[4], hdr[5], hdr[6], hdr[7]);
  len -= 8;
  if (len > 0) {
    printx(" ");
    for (i = 0; i < len; i += 1) {
      printx(" %02x", data[i]);
      if ((i & 0x0f) == 15) {
	printx("\n ");
      }
    }
    printx("\n");
  }
  (void) pthread_mutex_unlock(&ctylock);
}

/*
 *  Compute the DDCMP CRC over a data block.  Routine "borrowed" from simh,
 *  file pdp11_ddcmp.h, with permission from Mark Pizzolato:
 */

u_short ddcmp_crc(u_char* data, int len)
{
  static u_short nibble[16] = {
    0x0000, 0xcc01, 0xd801, 0x1400, 0xf001, 0x3c00, 0x2800, 0xe401,
    0xa001, 0x6c00, 0x7800, 0xb401, 0x5000, 0x9c01, 0x8801, 0x4400,
  };
  
  u_short crc = 0;
  u_char c;
  int i;

  for (i = 0; i < len; i += 1) {
    c = data[i];
    crc = (crc >> 4) ^ nibble[(c ^ crc) & 0x0f];
    crc = (crc >> 4) ^ nibble[((c >> 4) ^ crc) & 0x0f];
  }

  return crc;
}

/*
 *  Fix the DDCMP CRC field(s) on a packet.
 */

void ddcmp_fixup_crc(packet* pkt)
{
  u_char* data = pkt->pkt_data;
  int len = pkt->pkt_len;
  u_short crc;

  crc = ddcmp_crc(data, 6);
  data[6] = crc & 0xff;
  data[7] = (crc >> 8) & 0xff;
  if (len > 8) {
    crc = ddcmp_crc(&data[8], len - 10);
    data[len - 2] = crc & 0xff;
    data[len - 1] = (crc >> 8) & 0xff;
  }
}

/*
 *  Stop the DDCMP timer.  (maybe)
 */

void ddcmp_stop_timer(ddcmp* dd)
{
  dd->dd_timer = 0;
  if (!(dd->dd_flags & DDF_ANF))
    dd->dd_flags &= ~DDF_TIMER;
}

/*
 *  Set up and send a data message.  (XMTDAT:)
 */

void ddcmp_xmit_data(ddcmp* dd, u_char dummy)
{
  packet* pkt;
  u_char* hdr;
  u_short len;
  u_char seq;

  /* header = 0201 CC1 CC2+S RESP NUM 1 */

  /* Data msgs should only have SELECT set, unless maint mode. */

  if (dd->dd_ackqlen > DDCMP_MAXOUT)
    return;

  pkt = dd->dd_outqhead;
  if (pkt == NULL)
    return;			/* Why are we here? */

  if (pkt->pkt_next != NULL) {
    dd->dd_outqhead = pkt->pkt_next;
    dd->dd_outqlen -= 1;
    dd->dd_req |= DDRQ_DATA;	/* More data in need. */
  } else {
    dd->dd_outqhead = NULL;
    dd->dd_outqtail = NULL;
    dd->dd_outqlen = 0;
  }    

  pkt->pkt_next = NULL;

  if (dd->dd_ackqhead == NULL) {
    dd->dd_ackqhead = pkt;
    dd->dd_ackqtail = pkt;
    dd->dd_ackqlen = 1;
  } else {
    dd->dd_ackqtail->pkt_next = pkt;
    dd->dd_ackqtail = pkt;
    dd->dd_ackqlen += 1;
  }

  if (!(pkt->pkt_flags & PKF_SEQUENCE)) {
    seq = (dd->dd_lmx + 1) & 0xff;
    pkt->pkt_seq = seq;
    pkt->pkt_flags |= PKF_SEQUENCE;
    dd->dd_lmx = seq;
  }

  switch (pkt->pkt_type) {
  case PKT_RAW:
    len = pkt->pkt_len;		/* Get data length. */
    pkt_prepend(pkt, 8, 0);	/* Make space for DDCMP header, */
    pkt_append(pkt, 2);		/* ... and data CRC. */
    hdr = pkt->pkt_data;	/* Our header is here. */
    hdr[0] = 0201;
    hdr[1] = len & 0xff;
    hdr[2] = len >> 8;
    hdr[2] |= DDB_SELECT;
    //    hdr[3] = dd->dd_lma;
    hdr[3] = dd->dd_rmn;
    hdr[4] = pkt->pkt_seq;
    hdr[5] = 1;
    hdr[6] = 0;
    hdr[7] = 0;
    pkt->pkt_type = PKT_DDCMP;	/* Now we are DDCMP. */
    ddcmp_fixup_crc(pkt);
    break;
  case PKT_DDCMP:
    /* Retransmission, all set up.. */
    break;
  default:			/* Should not happen. */
    pkt_free(pkt);
    return;
  }

  if (verbose) {
    ddcmp_cty_print("ddcmp_xmit_data", pkt);
  }

  dd->dd_req &= ~DDRQ_ACK;

  (void) pthread_mutex_unlock(&dd->dd_object->obj_lock);
  write_packet(dd->dd_object, pkt_copy(pkt));
  (void) pthread_mutex_lock(&dd->dd_object->obj_lock);
}

/*
 *  Set up and send a control message.  (XMTSET:)
 */

void ddcmp_xmit_control(ddcmp* dd, u_char type)
{
  packet* pkt = pkt_alloc(PKT_DDCMP);
  u_char* hdr = pkt->pkt_data;

  hdr[0] = 0005;
  hdr[1] = type;
  hdr[2] = DDB_QSYNC | DDB_SELECT;
  hdr[3] = 0;
  hdr[4] = 0;
  hdr[5] = 1;
  pkt->pkt_len = 8;

  switch (type) {
  case DDC_ACK:
    hdr[3] = dd->dd_rmn;
    break;
  case DDC_NAK:
    hdr[2] = dd->dd_xnk;
    hdr[2] |= (DDB_QSYNC | DDB_SELECT);
    hdr[3] = dd->dd_rmn;
    break;
  case DDC_REP:
    dd->dd_flags |= DDF_TIMER;
    dd->dd_timer = 0;
    hdr[4] = dd->dd_lmx;
    break;
  case DDC_START:
    dd->dd_flags |= DDF_TIMER;
    dd->dd_timer = 0;
    break;
  case DDC_STACK:
    dd->dd_flags |= DDF_TIMER;
    dd->dd_timer = 0;
    break;
  default:
    /* internal error */
    pkt_free(pkt);
    return;
  }

  ddcmp_fixup_crc(pkt);
 
  if (verbose) {
    ddcmp_cty_print("ddcmp_xmit_ctrl", pkt);
  }

  (void) pthread_mutex_unlock(&dd->dd_object->obj_lock);
  write_packet(dd->dd_object, pkt);
  (void) pthread_mutex_lock(&dd->dd_object->obj_lock);
}

/*
 *  Try to service this line.  (XMTBUF:)
 */

void ddcmp_try_xmit(ddcmp* dd)
{
  static struct {
    u_char bit;
    u_char cmd;
    void (*func)(ddcmp* dd, u_char type);
  } check[] = {
    { DDRQ_START, DDC_START, ddcmp_xmit_control },
    { DDRQ_STACK, DDC_STACK, ddcmp_xmit_control },
    { DDRQ_NAK,   DDC_NAK,   ddcmp_xmit_control },
    { DDRQ_REP,   DDC_REP,   ddcmp_xmit_control },
    { DDRQ_DATA,  0,         ddcmp_xmit_data    },
    { DDRQ_ACK,   DDC_ACK,   ddcmp_xmit_control },
    { 0,          0,         NULL },
  };
  int i;

  for (i = 0; check[i].bit != 0; i += 1) {
    if (dd->dd_req & check[i].bit) {
      dd->dd_req &= ~check[i].bit;
      check[i].func(dd, check[i].cmd);
      return;
    }
  }
}

/*
 *  Set up and send a NAK.
 */

void ddcmp_send_nak(ddcmp* dd, u_char code)
{
  if (dd->dd_state == DDS_RUN) {
    dd->dd_xnk = code;
    dd->dd_req |= DDRQ_NAK;
    dd->dd_req &= ~DDRQ_ACK;
  }
  ddcmp_try_xmit(dd);
}

/*
 *  Check the ACK field.  Msg format:
 *
 *  0005 0001 fill msg# fill 1
 */

void ddcmp_check_ack(ddcmp* dd, packet* pkt)
{
  u_char* hdr = pkt->pkt_data;
  u_char msgnum;
  int count;

  switch (dd->dd_state) {
  case DDS_STACK:
    dd->dd_state = DDS_RUN;	/* SETSTATE */
    dd->dd_req &= ~(DDRQ_START | DDRQ_STACK);
    break;
  case DDS_RUN:
    break;
  default:
    return;
  }

  /* here we are in running state. */

  msgnum = hdr[3];

  if (msgnum == dd->dd_lma) {	/* Seen this ACK before? */
    if (dd->dd_lma == dd->dd_lmx) {
      dd->dd_rpc = 0;		/* Clear rep counter, we got the ACK. */
      ddcmp_stop_timer(dd);
    }
    return;
  }

  count = msgnum - dd->dd_lma;
  if (count < 0)
    count += 256;
  if (count > DDCMP_MAXOUT)
    return;			/* Give some kind of error? */

  while (count-- > 0) {

    /* Try to remove msg from ack queue: */

    pkt = dd->dd_ackqhead;
    if (pkt != NULL) {
      dd->dd_ackqhead = pkt->pkt_next;
      if (dd->dd_ackqhead == NULL) {
	dd->dd_ackqlen = 0;
	dd->dd_ackqtail = NULL;
      } else {
	dd->dd_ackqlen -= 1;
      }
      pkt_free(pkt);
      continue;
    }

    /* Try output queue: */

    pkt = dd->dd_outqhead;
    if (pkt != NULL) {
      dd->dd_outqhead = pkt->pkt_next;
      if (dd->dd_outqhead == NULL) {
	dd->dd_outqlen = 0;
	dd->dd_outqtail = NULL;
      } else {
	dd->dd_outqlen -= 1;
      }
      pkt_free(pkt);
    }
  }

  dd->dd_lma = msgnum;

  if (dd->dd_lma == dd->dd_lmx) {
    dd->dd_rpc = 0;		/* Clear rep counter, we got the ACK. */
    ddcmp_stop_timer(dd);
  }
}

/*
 *  Process incoming NAK.  Msg format:
 *
 * 0005 0002 rnak msg# fill 1
 */

void ddcmp_recv_nak(ddcmp* dd, packet* pkt)
{

  /* Count the type, for statistics. */

  if (dd->dd_state != DDS_RUN)
    return;

  ddcmp_check_ack(dd, pkt);

  ddcmp_stop_timer(dd);

  /* check retransmit queue. */

  /* See if we need to transmit anything. */
}

/*
 *  Process incoming REP.  Msg format:
 *
 * 0005 0003 fill fill nlst 1
 */

void ddcmp_recv_rep(ddcmp* dd, packet* pkt)
{
  if (dd->dd_state == DDS_RUN) {
    if (dd->dd_rmn == pkt->pkt_data[4]) {
      dd->dd_req |=  DDRQ_ACK;
      dd->dd_req &= ~DDRQ_NAK;
      ddcmp_try_xmit(dd);
    } else {
      ddcmp_send_nak(dd, NAK_REP);
    }
  }
}

/*
 *  Process incoming START.  Msg format:
 *
 *  0005 0006 fill fill nbeg 1
 */

void ddcmp_recv_start(ddcmp* dd, packet* pkt)
{
  switch (dd->dd_state) {
  case DDS_START:
  case DDS_STACK:
    dd->dd_state = DDS_STACK;	/* SETSTATE */
    dd->dd_req = DDRQ_STACK;
    break;
  case DDS_RUN:
    dd->dd_state = DDS_START;	/* SETSTATE */
    dd->dd_req = DDRQ_START;
    /*
     *  Clear out packet queue.
     *  Set seq. number vars to zero.
     *  If we have a nid template, remove it.
     */
    break;
  default:
    return;
  }
  ddcmp_try_xmit(dd);
}

/*
 *  Process incoming STACK.  Msg format:
 *
 *  0005 0007 fill nrec nxmt 1
 */

void ddcmp_recv_stack(ddcmp* dd, packet* pkt)
{
  switch (dd->dd_state) {
  case DDS_START:
  case DDS_STACK:
    /*
     *  Stop timer.
     *  set state to run.
     *  send ACK.
     */
    dd->dd_state = DDS_RUN;	/* SETSTATE */
    dd->dd_req = DDRQ_ACK;
    break;
  case DDS_RUN:
    dd->dd_req |= DDRQ_ACK;
    dd->dd_req &= ~DDRQ_NAK;
    break;
  }
  ddcmp_try_xmit(dd);
}

/*
 *  Handle an incoming control message:
 */

void ddcmp_ctrlin(ddcmp* dd, packet* pkt)
{
  switch (pkt->pkt_data[1]) {
  case DDC_ACK:
    ddcmp_check_ack(dd, pkt);
    break;
  case DDC_NAK:
    ddcmp_recv_nak(dd, pkt);
    break;
  case DDC_REP:
    ddcmp_recv_rep(dd, pkt);
    break;
  case DDC_START:
    ddcmp_recv_start(dd, pkt);
    break;
  case DDC_STACK:
    ddcmp_recv_stack(dd, pkt);
    break;
  default:
    break;
  }
  pkt_free(pkt);
}

/*
 *  Process incoming data messages.  Msg format:
 *
 *  0201  cc1  cc2 msg# nmsg 1 bcc1 [data] bcc2
 *
 *  High-order two bits of cc2 are flags we ignore.
 *  The header crc has been checked when we come here.
 */

void ddcmp_datain(ddcmp* dd, packet* pkt)
{
  object* obj = dd->dd_object;
  u_char* hdr = pkt->pkt_data;
  u_char* data = &pkt->pkt_data[8];
  int len = pkt->pkt_len - 10;
  u_char nmsg;
  
  if (dd->dd_state != DDS_RUN) {
    pkt_free(pkt);
    return;
  }

  if (ddcmp_crc(data, len + 2) != 0) {
    ddcmp_send_nak(dd, NAK_DCK);
    pkt_free(pkt);
    return;
  }

  ddcmp_check_ack(dd, pkt);

  nmsg = (dd->dd_rmn + 1) & 0xff;
  if (hdr[4] != nmsg) {
    if (verbose) {
      ctyprintf("ddcmp_datain: got msg %u, expected %u",
		hdr[4], nmsg);
    }
    pkt_free(pkt);
    return;
  }

  dd->dd_rmn = nmsg;

  dd->dd_req |= DDRQ_ACK;
  dd->dd_req &= ~DDRQ_NAK;

  pkt_trim(pkt, 8, 2);		/* Peel off DDCMP header and CRC. */
  pkt->pkt_type = PKT_RAW;	/* Set type of data. */

  /*
   *  Check for ethernet target, if so try to convert us to
   *  an ethernet packet.
   */

  if (obj->obj_flags & OBF_ETHER) {
    pkt = ether_from_sync(obj, pkt);
  }

  /*
   *  Now we write the packet to the target object.  Note that
   *  we release the lock on ourselves here during the write,
   *  the reason is that:
   *
   *  If the target object tries to send us a packet at the same
   *  time, a deadlock might occur.
   *
   *    OR
   *
   *  If we are pointing to ourselves, i.e. looped back, a
   *  deadlock WILL occur.
   */

  if (pkt != NULL) {
    (void) pthread_mutex_unlock(&obj->obj_lock);
    write_packet(dd->dd_object->obj_xcon, pkt);
    (void) pthread_mutex_lock(&obj->obj_lock);
  }

  ddcmp_try_xmit(dd);		/* Try send the ACK. */
}

/*
 *  Here when the "physical" line goes up:
 */

void ddcmp_dcd_on(object* obj)
{
  struct ddcmp* dd = obj->obj_ddcmp;

  //  (void) pthread_mutex_lock(&obj->obj_lock);

  /*
   *  Move DDCMP state to START, init variables, set timer and run on.
   */

  /* Only if running DDCMP... */

  if (dd != NULL && obj->obj_flags & OBF_DDCMP) {
    dd->dd_state = DDS_START;	/* SETSTATE */
    dd->dd_timer = DDCMP_STARTSEC;
    dd->dd_flags |= DDF_TIMER;
  }

  //  (void) pthread_mutex_unlock(&obj->obj_lock);
}

/*
 *  Here when the "physical" line goes down:
 */

void ddcmp_dcd_off(object* obj)
{
  struct ddcmp* dd = obj->obj_ddcmp;

  //  (void) pthread_mutex_lock(&obj->obj_lock);

  /*
   *  Set DDCMP state to HALT, flush queued data, stop timer.
   */

  /* Only if running DDCMP... */

  if (dd != NULL && obj->obj_flags & OBF_DDCMP) {
    dd->dd_state = DDS_HALT;	/* SETSTATE */
    dd->dd_flags &= ~DDF_TIMER;
  }

  //  (void) pthread_mutex_unlock(&obj->obj_lock);
}

/*
 *  Here with a packet that should be transmitted over a DDCMP link.
 *  We are called with the object locked.
 */

void ddcmp_xmit(object* obj, packet* pkt)
{
  struct ddcmp* dd = obj->obj_ddcmp;

  if (dd->dd_state != DDS_RUN) {
    pkt_free(pkt);
    return;
  }

  if (dd->dd_outqhead == NULL) {
    dd->dd_outqhead = pkt;
    dd->dd_outqtail = pkt;
    dd->dd_outqlen = 1;
  } else {
    dd->dd_outqtail->pkt_next = pkt;
    dd->dd_outqtail = pkt;
    dd->dd_outqlen += 1;
  }
  dd->dd_req |= DDRQ_DATA;
  ddcmp_try_xmit(dd);
}

/*
 *  Here when we receive a packet on a DDCMP link.  Called with object
 *  UNLOCKED, we lock it here for the whole of DDCMP processing.
 */

void ddcmp_recv(object* obj, packet* pkt)
{
  struct ddcmp* dd = obj->obj_ddcmp;
  u_char* hdr = pkt->pkt_data;

  if (frozen) {
    pkt_free(pkt);
    return;
  }

  (void) pthread_mutex_lock(&obj->obj_lock);

  if (verbose) {
    ctyprintf("ddcmp_recv: hdr = %02x %02x %02x %02x %02x %02x %02x %02x",
	      hdr[0], hdr[1], hdr[2], hdr[3], hdr[4], hdr[5], hdr[6], hdr[7]);
  }

  if (pkt->pkt_flags & PKF_OVRRUN) {
    ddcmp_send_nak(dd, NAK_OVR);
    pkt_free(pkt);
    goto done;
  }

  if (ddcmp_crc(hdr, 8) != 0) {
    ddcmp_send_nak(dd, NAK_HCK);
    pkt_free(pkt);
    goto done;
  }

  switch (pkt->pkt_data[0]) {
  case 0005:
    ddcmp_ctrlin(dd, pkt);
    break;
  case 0201:
    ddcmp_datain(dd, pkt);
    break;
  case 0220:
  default:
    pkt_free(pkt);
    break;
  }

 done:

  (void) pthread_mutex_unlock(&obj->obj_lock);
}

/*
 *  Here once/second to do DDCMP timing for this link.
 *  Called with object locked.
 */

void ddcmp_tick(object* obj)
{
  struct ddcmp* dd = obj->obj_ddcmp;
  int time;

  if (dd->dd_flags & DDF_TIMER) {
    time = ++dd->dd_timer;
    
    switch (dd->dd_state) {
    case DDS_START:
      if (time >= DDCMP_STARTSEC) {
	dd->dd_req |= DDRQ_START;
	ddcmp_try_xmit(dd);
	dd->dd_timer = 0;
      }
      break;
    case DDS_STACK:
      if (time >= DDCMP_STACKSEC) {
	dd->dd_req |= DDRQ_STACK;
	ddcmp_try_xmit(dd);
	dd->dd_timer = 0;
      }
      break;
    case DDS_RUN:
      if (time >= DDCMP_REPSEC) {
	if (++dd->dd_rpc > DDCMP_REPMAX) {
	  dd->dd_req = DDRQ_START;
	  ddcmp_try_xmit(dd);
	  dd->dd_state = DDS_START; /* SETSTATE */
	  dd->dd_rpc = 0;
	} else {
	  dd->dd_req |= DDRQ_REP;
	  ddcmp_try_xmit(dd);
	}
	dd->dd_timer = 0;
      }
      break;
    default:
      dd->dd_flags &= ~DDF_TIMER;
      dd->dd_timer = 0;
      break;
    }
  }
}

/************************************************************************/

/*
 *  Sub-thread for writing packets.
 */

void run_writer(object* obj)
{
  packet* pkt;
  u_int gap;
  u_int delay;
  u_int bt;

  (void) pthread_mutex_lock(&obj->obj_lock);

  for (;;) {
    pkt = obj->obj_oqhead;
    if (pkt == NULL) {
      (void) pthread_cond_wait(&obj->obj_wcond, &obj->obj_lock);
    } else {
      (void) pthread_mutex_unlock(&obj->obj_lock);

      send(obj->obj_ipcon->ip_socket, pkt->pkt_data, pkt->pkt_len, 0);

      delay = 0;

      if (obj->obj_oqspeed > 0) {
	bt = 1000000000 / obj->obj_oqspeed;
	delay = bt * pkt->pkt_len * 8;
      }
      
      if (obj->obj_oqdly > 0) {
	gap = obj->obj_oqdly * 1000;
	if (gap > delay)
	  delay = gap;
      }
      if (delay > 0)
	nssleep(delay);

      (void) pthread_mutex_lock(&obj->obj_lock);
      if (pkt->pkt_next != NULL) {
	obj->obj_oqhead = pkt->pkt_next;
	if (obj->obj_oqlen <= obj->obj_oqsize) {
	  obj->obj_oqlen -= 1;
	}
      } else {
	obj->obj_oqhead = NULL;
	obj->obj_oqtail = NULL;
	obj->obj_oqlen = 0;
      }
      pkt_free(pkt);
    }
  }
}

/*
 *  This code handles IP remote command objects.
 */

void run_cmd(object* obj)
{
  struct ipcon* ipc = obj->obj_ipcon;
  u_char c;
  char buf[1024];
  int pos, left;

  for (;;) {
    net_open(obj);
    if (ipc->ip_state != IPS_UP)
      continue;

    do_auth(obj);
    if (ipc->ip_state != IPS_UP)
      continue;

    obj->obj_flags |= OBF_READY;

    cm_enter(CMDT_TCPIP, obj);
    printx("Welcome to anftunnel.  For help type 'help'\n");
    if (obj->obj_rflag)
      printx("  (read-only access)\n");
    cm_exit();

    while (!(obj->obj_flags & OBF_QUIT)) {
      cm_enter(CMDT_TCPIP, obj);
      printx("- ");
      cm_exit();

      pos = 0;
      left = 1024;

      do {
	c = net_getbyte(ipc);
	if (ipc->ip_state != IPS_UP)
	  goto abort;
	if (ipc->ip_flags & IPF_CRYPTO)
	  c ^= prng_getbyte(ipc->ip_rxcrypt);
	if (--left > 0)
	  buf[pos++] = c;
      } while (c != '\n');

      buf[pos] = 0;

      cm_enter(CMDT_TCPIP, obj);
      cm_line(buf);
      cm_exit();
    }
    obj->obj_flags &= ~OBF_QUIT;
    cm_enter(CMDT_TCPIP, obj);
    printx("Goodbye.\n");
    cm_exit();
  abort:
    obj->obj_flags &= ~OBF_READY;
    net_close(ipc);
  }
}

/*
 *  This part contains the code to run an ethernet object.
 */

void do_ether_packet(u_char* u, const struct pcap_pkthdr* h, const u_char* p)
{
  object* obj = (object*) u;
  object* dst = NULL;
  ethost* eh;
  packet* pkt;
  int len;
  u_char* srcmac;
  u_char* dstmac;
  u_short ethtyp;
  u_char nodnum;
  nodedata* nd;
  int n;

  if (verbose) {
    int s;
    char* iface = obj->obj_iface;

    if (iface == NULL)
      iface = obj->obj_name;

    s = (h->ts.tv_sec + gmtdiff) % 86400;

    ctyprintf("ether packet on %s, %d bytes, ts = %02d:%02d:%02d.%06u",
	      iface, h->caplen,
	      s/3600, (s%3600)/60, s%60, h->ts.tv_usec);
  }

  pkt = pkt_alloc(PKT_ETHER);

  len = h->caplen;
  if (len > pkt->pkt_post)
    len = pkt->pkt_post;

  memcpy(pkt->pkt_data, p, len);
  pkt->pkt_len = len;
  pkt->pkt_post -= len;
  pkt->pkt_src = obj;

  dstmac = &pkt->pkt_data[0];
  srcmac = &pkt->pkt_data[6];
  ethtyp = (pkt->pkt_data[12] << 8) + pkt->pkt_data[13];

  pkt->pkt_proto = PROTO_NONE;
  if (ethtyp == obj->obj_port)
    pkt->pkt_proto = PROTO_ANF10;
  if (ethtyp == 0x6003)
    pkt->pkt_proto = PROTO_DECNET;
  if (ethtyp == 0x6004)
    pkt->pkt_proto = PROTO_LAT;
  if (ethtyp == 0x0800 || ethtyp == 0x0806)
    pkt->pkt_proto = PROTO_IPV4;
  if (ethtyp == 0x0804)
    pkt->pkt_proto = PROTO_CHAOS;
  if (ethtyp == 0x86dd)
    pkt->pkt_proto = PROTO_IPV6;

  eth_update(obj->obj_bridge, srcmac, obj, 0);

  if (pkt->pkt_data[0] & 0x01) { /* Is this multicast? */
    switch (pkt->pkt_proto) {
    case PROTO_ANF10:
      if (anf_parse(pkt) &&
	  pkt->anf_type == NCTT_NODEID) {
	nodnum = pkt->anf_nnum;
	if (verbose) {
	  ctyprintf("node id, node %o (%s)", pkt->anf_nnum, pkt->anf_snm);
	}
	nodeid_update(obj, pkt, obj, NDF_LOCAL, 0);

	for (n = 1; n < 128; n += 1) {
	  nd = &obj->obj_route[n];
	  if ((nd->nd_flags & NDF_VALID) &&
	      (nd->nd_peer == nodnum)) {
	    /* XXX pick up the tag! */
	    write_packet(nd->nd_target, pkt_copy(pkt));
	  }
	}

	if (obj->obj_node != 0) {	/* Got a specific node set? */
	  if (obj->obj_node == pkt->anf_nnum) { /* Is it me? */
	    dst = obj->obj_xcon;		      /* Yes, forward. */
	  }
	} else {			/* No specific node. */
	  if (obj->obj_xcon != NULL) {
	    switch (obj->obj_xcon->obj_type) {
	    case OBT_BRIDGE:
	    case OBT_ETHER:
	    case OBT_TUNNEL:
	    case OBT_LOG:
	      dst = obj->obj_xcon;
	      if (obj->obj_maxnode != 0) {
		if (pkt->anf_nnum > obj->obj_maxnode)
		  dst = NULL;
	      }
	      break;
	    default:
	      break;
	    }
	  }
	}
      }
      break;
    case PROTO_DECNET:
      dst = obj->obj_xcon;
      break;
    default:
      dst = obj->obj_xcon;
      break;
    }
  } else {			/* Unicast. */
    /*
     *  If this a neighbour message, do max-node filtering on the
     *  contents.
     */
    eh = eth_lookup(obj->obj_bridge, dstmac, 0);
    if (eh != NULL) {		/* Known? */
      if (eh->eth_obj != obj) {	/* Points away from us? */
	dst = eh->eth_obj;	/* Yes, forward it. */
	pkt->pkt_tag = eh->eth_tag;
      }
    }
  }

  write_packet(dst, pkt);
}

void run_ethernet(object* obj)
{
  pcap_t* ph;
  struct bpf_program filter;
  char* iface;
  char errbuf[PCAP_ERRBUF_SIZE];
  char buffer[1024];
  int pos, max;

  iface = obj->obj_iface;
  if (iface == NULL)
    iface = obj->obj_name;

  if (verbose > 0) {
    ctyprintf("Starting ethernet object %s, interface %s",
	      obj->obj_name, iface);
  }

  (void) pthread_mutex_lock(&pcaplock);

  ph = pcap_open_live(iface, 1500, 1, 1, errbuf);
  if (ph == NULL) {
    printx("pcap_open_live: %s\n", errbuf);
    (void) pthread_mutex_unlock(&pcaplock);
    return;
  }
  obj->obj_pcap = ph;

  eth_setproto(obj);

  pos = 0;
  max = sizeof(buffer);

  if (obj->obj_eproto & OBP_ANF10) {
    pos += snprintf(&buffer[pos], max - pos,
		    "ether proto 0x%04x", obj->obj_port);
  }

  if (obj->obj_eproto & OBP_CHAOS) {
    if (pos > 0)
      pos += snprintf(&buffer[pos], max - pos, " or ");
    pos += snprintf(&buffer[pos], max - pos,
		    "ether proto 0x0804");
  }

  if (obj->obj_eproto & OBP_DECNET) {
    if (pos > 0)
      pos += snprintf(&buffer[pos], max - pos, " or ");
    pos += snprintf(&buffer[pos], max - pos,
		    "ether proto 0x6003");
  }

  if (obj->obj_eproto & OBP_LAT) {
    if (pos > 0)
      pos += snprintf(&buffer[pos], max - pos, " or ");
    pos += snprintf(&buffer[pos], max - pos,
		    "ether proto 0x6004");
  }

  if (obj->obj_eproto & OBP_IPV4) {
    if (pos > 0)
      pos += snprintf(&buffer[pos], max - pos, " or ");
    pos += snprintf(&buffer[pos], max - pos,
		    "ether proto 0x0800 or ether proto 0x0806");
  }

  if (obj->obj_eproto & OBP_IPV6) {
    if (pos > 0)
      pos += snprintf(&buffer[pos], max - pos, " or ");
    pos += snprintf(&buffer[pos], max - pos,
		    "ether proto 0x86dd");
  }

  if (verbose)
    ctyprintf("filter expression: '%s'\n", buffer);

  if (pcap_compile(ph, &filter, buffer, 0, -1) < 0) {
    printx("pcap_compile: %s\n", pcap_geterr(ph));
    goto abort;
  }
  if (pcap_setfilter(ph, &filter) < 0) {
    printx("pcap_setfilter: %s\n", pcap_geterr(ph));
    goto abort;
  }

  if (pcap_setdirection(ph, PCAP_D_IN) < 0) {
    printx("pcap_setdirection: %s\n", pcap_geterr(ph));
    goto abort;
  }

  obj->obj_flags |= OBF_READY;

  (void) pthread_mutex_unlock(&pcaplock);

  (void) pcap_loop(ph, -1, do_ether_packet, (u_char*) obj);

  /* The preceding call should never return, but if it does: */

  (void) pcap_close(ph);
  return;

 abort:
  (void) pcap_close(ph);
  (void) pthread_mutex_unlock(&pcaplock);
}

/*
 *  This part contains the code to run a tunnel object.
 */

void run_tunnel(object* obj)
{
  struct ipcon* ipc = obj->obj_ipcon;
  packet* pkt;
  u_char* data;
  u_short len;
  u_char  tag;
  u_char  type;
  u_char  node;
  u_char  proto;
  u_char  c;

  for (;;) {
    net_open(obj);
    if (ipc->ip_state != IPS_UP)
      continue;

    do_auth(obj);
    if (ipc->ip_state != IPS_UP)
      continue;

    obj->obj_flags |= OBF_READY;

    while (ipc->ip_state == IPS_UP) {
      len = net_getbyte(ipc) << 8;
      len += net_getbyte(ipc);
      tag = net_getbyte(ipc);
      type = net_getbyte(ipc);
      node = net_getbyte(ipc);
      proto = net_getbyte(ipc);
      (void) net_getbyte(ipc);
      (void) net_getbyte(ipc);

      if (ipc->ip_state != IPS_UP)
	goto abort;		/* Lost connection. */

      pkt = pkt_alloc(type);
      pkt->pkt_tag = tag;
      pkt->pkt_src = obj;
      pkt->pkt_node = node;
      pkt->pkt_proto = proto;

      data = pkt->pkt_data;

      if (verbose)
	ctyprintf("tunnel: got packet, len %d, tag %u, type %s, "
		  "node %u, proto %u (%s)",
		  len, pkt->pkt_tag, i2s(type, pkt_type_names),
		  node, proto, i2s(proto, proto_names));

      if (len > pkt->pkt_post) {
	/* No room.  Should not happen. */
	ctyprintf("tunnel: packet too long, skipping...");
	while (len-- > 0)
	  (void) net_getbyte(ipc);
	pkt_free(pkt);
      } else {
	pkt->pkt_len = len;
	while (len-- > 0)
	  *data++ = net_getbyte(ipc);
	if (ipc->ip_state != IPS_UP) {
	  pkt_free(pkt);
	  goto abort;
	}
	if (ipc->ip_flags & IPF_CRYPTO) {
	  c = prng_getbyte(ipc->ip_rxcrypt);
	  prng_skip(ipc->ip_rxcrypt, (c & 0xf0) >> 4);
	  prng_encrypt(ipc->ip_rxcrypt, pkt->pkt_data, pkt->pkt_len);
	  pkt_trim(pkt, c & 0x0f, 16 - (c & 0x0f));
	}
	write_packet(obj->obj_tags[tag].tag_target, pkt);
      }
    }
  abort:
    obj->obj_flags &= ~OBF_READY;
    net_close(ipc);
  }
}

/*
 *  This part contains the code to run a multinet object.
 */

void run_mltnet(object* obj)
{
  struct ipcon* ipc = obj->obj_ipcon;
  packet* pkt;
  int len;

  for (;;) {
    net_open(obj);
    obj->obj_flags |= OBF_READY;

    while (ipc->ip_state == IPS_UP) {
      len = net_getbyte(ipc);
      len += net_getbyte(ipc) << 8;
      (void) net_getbyte(ipc);
      (void) net_getbyte(ipc);

      if (len == 0)
	continue;

      if (ipc->ip_state != IPS_UP)
	goto abort;		/* Lost connection. */

      pkt = pkt_alloc(PKT_RAW);
      pkt->pkt_src = obj;
      pkt->pkt_proto = PROTO_DECNET;
      pkt->pkt_tag = obj->obj_tag;

      while (len-- > 0)
	pkt_store(pkt, net_getbyte(ipc));

      if (ipc->ip_state != IPS_UP) {
	pkt_free(pkt);
	goto abort;
      }
      write_packet(obj->obj_xcon, pkt);
    }
  abort:
    obj->obj_flags &= ~OBF_READY;
    net_close(ipc);
  }
}

/*
 *  This part contains the code to run a sync object, via TCP.
 */

void run_sync(object* obj)
{
  struct ipcon* ipc = obj->obj_ipcon;
  packet* pkt;
  u_char* hdr;
  int len;
  int c;

  /* propagate flag bits: */

  obj->obj_flags &= ~(OBF_DDCMP | OBF_ETHER);
  obj->obj_ddcmp->dd_flags &= ~DDF_ANF;

  if (obj->obj_aflag)
    obj->obj_ddcmp->dd_flags |= DDF_ANF;
  if (obj->obj_dflag)
    obj->obj_flags |= OBF_DDCMP;
  if (obj->obj_eflag) {
    obj->obj_flags |= (OBF_DDCMP | OBF_ETHER);
    obj->obj_ddcmp->dd_flags |= DDF_ANF;
  }

  for (;;) {
    net_open(obj);
    obj->obj_flags |= OBF_READY;

    while (ipc->ip_state == IPS_UP) {
      c = net_getbyte(ipc);
      switch (c) {
      case EOF:			/* Lost connection. */
	goto abort;
      case 0005:		/* Control. */
      case 0201:		/* Data. */
      case 0220:		/* Maint. */
	break;
      default:			/* Unknown. */
	continue;		/* Continue scanning for start of frame. */
      }

      pkt = pkt_alloc(PKT_DDCMP);
      pkt->pkt_src = obj;

      hdr = pkt->pkt_sptr;
      pkt_store(pkt, c);
      len = 7;
      while (len-- > 0)
	pkt_store(pkt, net_getbyte(ipc));

      if (c == 0201 || c == 0220) {
	len = (hdr[1] + (hdr[2] << 8)) & 0x3fff;
	len += 2;		/* ... plus the crc. */
	if (ipc->ip_state == IPS_UP) {
	  while (len-- > 0)
	    pkt_store(pkt, net_getbyte(ipc));
	}
      }

      if (ipc->ip_state != IPS_UP) {
	pkt_free(pkt);
	goto abort;		/* Lost connection. */
      }

      pkt->pkt_node = obj->obj_node;
      pkt->pkt_tag = obj->obj_tag;

      if (verbose) {
	ddcmp_cty_print("sync recv", pkt);
      }
      
      if (obj->obj_flags & OBF_DDCMP) {
	ddcmp_recv(obj, pkt);
      } else {
	write_packet(obj->obj_xcon, pkt);
      }
    }
  abort:
    obj->obj_flags &= ~OBF_READY;
    net_close(ipc);
  }
}

/*
 *  This part contains the code to run a sync object, via UDP.
 */

void run_udp(object* obj)
{
  struct ipcon* ipc = obj->obj_ipcon;
  struct ddcmp* dd = obj->obj_ddcmp;
  struct packet* pkt;
  int len;

  /* propagate flag bits: */

  obj->obj_flags &= ~(OBF_DDCMP | OBF_ETHER);
  obj->obj_ddcmp->dd_flags &= ~DDF_ANF;

  if (obj->obj_aflag)
    obj->obj_ddcmp->dd_flags |= DDF_ANF;
  if (obj->obj_dflag)
    obj->obj_flags |= OBF_DDCMP;
  if (obj->obj_eflag) {
    obj->obj_flags |= (OBF_DDCMP | OBF_ETHER);
    obj->obj_ddcmp->dd_flags |= DDF_ANF;
  }

  net_open(obj);
  if (ipc->ip_state != IPS_UP)	/* For the time being. */
    return;

  obj->obj_flags |= OBF_READY;

  for (;;) {
    pkt = pkt_alloc(PKT_DDCMP);
    pkt->pkt_src = obj;
    len = recv(ipc->ip_socket, pkt->pkt_data, pkt->pkt_post, 0);

    if (len > 0) {
      pkt->pkt_len = len;
      pkt->pkt_post -= len;

      if (len == 6)		/* Control message, no crc? */
	dd->dd_flags |= DDF_NOCRC;

      if (dd->dd_flags & DDF_NOCRC) {
	switch (pkt->pkt_data[0]) {
	case 0201:
	case 0220:
	  pkt_prepend(pkt, 2, 6);
	  pkt_append(pkt, 2);
	  ddcmp_fixup_crc(pkt);
	  break;
	case 0005:
	  pkt_append(pkt, 2);
	  ddcmp_fixup_crc(pkt);
	  break;
	default:
	  break;
	}
      }

      pkt->pkt_node = obj->obj_node;
      pkt->pkt_tag = obj->obj_tag;

      if (obj->obj_flags & OBF_DDCMP) {
	ddcmp_recv(obj, pkt);
      } else {
	write_packet(obj->obj_xcon, pkt);
      }
    } else {
      pkt_free(pkt);
    }
  }
}

void do_cmd(object* obj)
{
  struct ipcon* ipc = obj->obj_ipcon;
  u_char c;
  char buf[1024];
  int pos, left;

  obj->obj_flags |= OBF_READY;

  cm_enter(CMDT_TCPIP, obj);
  printx("Welcome to anftunnel.  For help type 'help'\n");
  if (obj->obj_rflag)
    printx("  (read-only access)\n");
  cm_exit();

  while (!(obj->obj_flags & OBF_QUIT)) {
    cm_enter(CMDT_TCPIP, obj);
    printx("- ");
    cm_exit();

    pos = 0;
    left = 1024;

    do {
      c = net_getbyte(ipc);
      if (ipc->ip_state != IPS_UP)
	return;
      if (ipc->ip_flags & IPF_CRYPTO)
	c ^= prng_getbyte(ipc->ip_rxcrypt);
      if (--left > 0)
	buf[pos++] = c;
    } while (c != '\n');

    buf[pos] = 0;

    cm_enter(CMDT_TCPIP, obj);
    cm_line(buf);
    cm_exit();
  }
  obj->obj_flags &= ~OBF_QUIT;
  cm_enter(CMDT_TCPIP, obj);
  printx("Goodbye.\n");
  cm_exit();
}

/*
 *  Common code to run objects over TCP/IP.
 */

void run_tcpip(object* obj)
{
  struct ipcon* ipc = obj->obj_ipcon;

  for (;;) {
    net_open(obj);
    if (ipc->ip_state != IPS_UP)
      continue;

    switch (obj->obj_type) {
    case OBT_CMD:
    case OBT_TUNNEL:
      do_auth(obj);
      if (ipc->ip_state != IPS_UP)
	continue;
      break;
    }

    switch (obj->obj_type) {
    case OBT_CMD:
      do_cmd(obj);
      break;
    case OBT_MLT:
      // do_mlt(obj);
      break;
    case OBT_SYNC:
      // do_sync(obj);
      break;
    case OBT_TUNNEL: 
      // do_tunnel(obj);
      break;
    case OBT_UDP:
      // do_udp(obj);
      break;
    default:
      /* this is an error. */
      break;
    }

    obj->obj_flags &= ~OBF_READY;
    net_close(ipc);
  }
}

/*
 *  Here to start a writer sub-thread.
 */

void* start_writer(void* arg)
{
  object* obj = arg;

  run_writer(obj);

  return NULL;
}

/*
 *  Here to stop an object, called as a cleanup routine.
 */

void thread_cleanup(void* arg)
{
  object* obj = arg;
  ipcon* ipc = obj->obj_ipcon;

  printx("thread_cleanup: %s\n", obj->obj_name);

  switch (obj->obj_type) {
  case OBT_BRIDGE:
  case OBT_LOG:
    return;
  default:
    break;
  }

  if (obj->obj_flags & OBF_WSUB) {
    obj->obj_flags &= ~OBF_WSUB;

    printf("WSUB cancel call\n");

    (void) pthread_cancel(obj->obj_writer);

    printf("WSUB cancel return\n");
    /*
     *  XXX Should we call pthread_join here?
     */
  }

  switch (obj->obj_type) {
  case OBT_ETHER:
    pcap_close(obj->obj_pcap);
    break;
  case OBT_TUNNEL:
  case OBT_SYNC:
  case OBT_UDP:
  case OBT_MLT:
  case OBT_CMD:
    printf("close IP\n");
    if (ipc->ip_flags & IPF_MASTER) {
      if (close(ipc->ip_master) != 0) {
	/* XXX */
	printf("close failed, errno = %d (%s)\n", errno, strerror(errno));
      }
      ipc->ip_flags &= ~IPF_MASTER;
    }
    net_close(ipc);
    break;
  default:
    break;
  }
}

/*
 *  Here to start an object thread.  Dispatch on object type.
 */

void* thread_start(void* arg)
{
  struct object* obj = arg;
  int ret;

  switch (obj->obj_type) {
  case OBT_TUNNEL:
  case OBT_SYNC:
  case OBT_UDP:
  case OBT_MLT:
    obj->obj_flags |= OBF_WSUB;
    (void) pthread_cond_init(&obj->obj_wcond, NULL);
    ret = pthread_create(&obj->obj_writer, NULL, start_writer, obj);
    /* should check return value here. */
    break;

  default:
    break;
  }

  pthread_cleanup_push(thread_cleanup, obj);

  obj->obj_flags |= OBF_THR;

  switch (obj->obj_type) {
  case OBT_ETHER:
    run_ethernet(obj);
    break;
  case OBT_TUNNEL:
    run_tunnel(obj);
    break;
  case OBT_SYNC:
    run_sync(obj);
    break;
  case OBT_UDP:
    run_udp(obj);
    break;
  case OBT_MLT:
    run_mltnet(obj);
    break;
  case OBT_CMD:
    run_tcpip(obj);
    //    run_cmd(obj);
    break;
  default:
    /* this is an internal error. Do something? */
    break;
  }

  obj->obj_flags &= ~OBF_THR;

  pthread_cleanup_pop(0);

  return NULL;			/* Should not get here, but... */
}

/*
 *  Here to start an object.  If it is already started, do nothing.
 */

void start_obj(object* obj)
{
  int ret;

  printf("start_obj: %s\n", obj->obj_name);

  if (obj->obj_flags & OBF_UP)
    return;

  switch (obj->obj_type) {
  case OBT_NONE:
    printx("start_obj: skipping NULL object\n");
    return;

  case OBT_BRIDGE:
  case OBT_LOG:
    obj->obj_flags |= OBF_UP;
    obj->obj_flags |= OBF_READY;
    return;
  }

  ret = pthread_create(&obj->obj_thread, NULL, thread_start, obj);
  if (ret != 0) {
    printx("Could not create thread for object %s\n",
	   obj->obj_name);
    return;
  }
  obj->obj_flags |= OBF_UP;
}

/*
 *  Here to stop an object.  Clean up, and cancel any thread(s).
 */

void stop_obj(object* obj)
{
  int ret;

  if (!(obj->obj_flags & OBF_UP))
    return;

  (void) pthread_mutex_lock(&obj->obj_lock);

  obj->obj_flags &= ~OBF_READY;
  obj->obj_flags &= ~OBF_UP;

  if (obj->obj_flags & OBF_THR) {
    printf("main cancel call\n");
    (void) pthread_cancel(obj->obj_thread);

    printf("calling join\n");
    ret = pthread_join(obj->obj_thread, NULL);
    printx("pthread_join returns %d\n", ret);
    obj->obj_flags &= ~OBF_THR;
  }

  /* XXX Should we kill off the writer thread here also? */

  printf("unlocking object\n");
  (void) pthread_mutex_unlock(&obj->obj_lock);
  printf("unlocking object -- done\n");
}

/*
 ************************************************************************
 *
 *  Timing routines:
 *
 ************************************************************************
 */

/*
 *  Do general countdown of an objects timer:
 */

void time_obj(object* obj)
{
  if (obj->obj_timer > 0) {
    obj->obj_timer -= 1;
  }
}

/*
 *  Do timing for a bridge.
 */

void time_bridge(object* obj)
{
  eth_tick(obj->obj_bridge);
}

/*
 *  Do ethernet timing, i.e. count down ttl for all known nodes.
 */

void time_ethernet(object* obj)
{
  struct nodedata* nd;
  u_short node;

  for (node = 1; node < 128; node += 1) {
    nd = &obj->obj_route[node];
    if (nd->nd_ttl > 0) {
      nd->nd_ttl -= 1;		/* Decrement, and check: */
      if (nd->nd_ttl == 0) {
	nd->nd_flags &= ~NDF_VALID;
	/* reset more stuff? */
      }
    }
  }

  eth_tick(obj->obj_bridge);
}

/*
 *  Do timing for a sync object.  Right now this only means check
 *  for faking up the periodic nodeid for fake ethernet hosts.
 */

void time_sync(object* obj)
{
  if (obj->obj_timer > 0) {
    obj->obj_timer -= 1;
    if (obj->obj_timer == 0) {
      write_packet(obj->obj_xcon, ether_nodeid(obj));
    }
  }
}

/*
 *  Do once/second timing on all objects.  For example, do DDCMP timing
 *  for sync objects.  This is the job of the main thread after we have
 *  been started.
 */

void do_timing(void)
{
  object* obj;

  for (;;) {
    sleep(1);

    if (frozen)			/* In frozen state, time stands still. */
      continue;

    for (obj = objlist; obj != NULL; obj = obj->obj_next) {
      (void) pthread_mutex_lock(&obj->obj_lock);

      switch (obj->obj_type) {
      case OBT_BRIDGE:
	time_bridge(obj);
	break;
      case OBT_ETHER:
	time_ethernet(obj);
	break;
      case OBT_TUNNEL:
	time_obj(obj);
	break;
      case OBT_SYNC:
      case OBT_UDP:
	time_sync(obj);
        ddcmp_tick(obj);
	break;
      case OBT_CMD:
	time_obj(obj);
	break;
      default:
	break;
      }
      (void) pthread_mutex_unlock(&obj->obj_lock);
    }
  }
}

/************************************************************************/

/*
 *  Debug routines, print out everything in our database:
 */

void show_ip_conn(object* obj)
{
  struct ipcon* ipc = obj->obj_ipcon;

  if (obj->obj_type == OBT_UDP) {
    printx("  Local port %d, remote port %d", obj->obj_lport, obj->obj_port);
  } else {
    printx("  Port %d", obj->obj_port);
  }
  if (obj->obj_remote != NULL) {
    printx(", remote %s", obj->obj_remote);
  }
  printx("\n");

  printx("  State %d (%s)", ipc->ip_state, i2s(ipc->ip_state, ip_state_names));
  printx(", flags = %x", ipc->ip_flags);
  printbits(ipc->ip_flags, ip_flag_names);
  if (ipc->ip_flags & IPF_MASTER)
    printx(", master = %d", ipc->ip_master);
  printx(", socket = %d\n", ipc->ip_socket);
}

void show_pkt_queue(char* msg, packet* pkt)
{
  u_char* hdr;
  u_char* data;
  int len;
  int i;
  int pnum;

  if (pkt == NULL)
    return;

  hdr = &pkt->pkt_data[0];
  data = &pkt->pkt_data[8];
  len = pkt->pkt_len;

  printx("  %s:\n", msg);
  pnum = 1;
  for (; pkt != NULL; pkt = pkt->pkt_next) {
    printx("    packet %d, len %d, type %d (%s)\n", pnum++,
	   pkt->pkt_len, pkt->pkt_type, i2s(pkt->pkt_type, pkt_type_names));
    printx("      %02x %02x %02x %02x %02x %02x %02x %02x\n",
	   hdr[0], hdr[1], hdr[2], hdr[3], hdr[4], hdr[5], hdr[6], hdr[7]);
    len -= 8;
    if (len > 0) {
      printx("     ");
      for (i = 0; i < len; i += 1) {
	printx(" %02x", data[i]);
	if ((i & 0x0f) == 15) {
	  printx("\n ");
	}
      }
      printx("\n");
    }
  }
}

void show_ddcmp_state(object* obj, int showq)
{
  struct ddcmp* dd = obj->obj_ddcmp;
  
  if (dd != NULL && obj->obj_flags & OBF_DDCMP) {
    printx("    DDCMP state %u (%s), flags = %x", 
	   dd->dd_state, i2s(dd->dd_state, ddcmp_state_names), dd->dd_flags);
    printbits(dd->dd_flags, ddc_flag_names);
    if (dd->dd_flags & DDF_TIMER)
      printx(", timer = %d", dd->dd_timer);
    printx(", rpc = %u\n", dd->dd_rpc);
    printx("    rmn = %u, lmx = %u, lma = %u, aql = %u, oql = %u\n",
	   dd->dd_rmn, dd->dd_lmx, dd->dd_lma,
	   dd->dd_ackqlen, dd->dd_outqlen);
    if (showq) {
      show_pkt_queue("ack queue", dd->dd_ackqhead);
      show_pkt_queue("out queue", dd->dd_outqhead);
    }
  }
}

void show_tag_table(object* obj)
{
  object* target;
  int tag;

  for (tag = 0; tag < 256; tag += 1) {
    target = obj->obj_tags[tag].tag_target;
    if (target != NULL) {
      printx("  tag %3d: => %s\n", tag, target->obj_name);
    }
  }
}

void show_node_table(object* obj)
{
  nodedata* nd;
  object* target;
  int node;

  for (node = 1; node < 128; node += 1) {
    nd = &obj->obj_route[node];
    target = nd->nd_target;
    if (target != NULL) {
      printx("  node %o (%s), '%s' '%s' version %d\n", 
	     node, nd->nd_nam, nd->nd_sid, nd->nd_dat, nd->nd_nvr);
      printx("    => %s, flags = %x", target->obj_name, nd->nd_flags);
      printbits(nd->nd_flags, nd_flag_names);
      if (nd->nd_peer != 0) {
	printx(", peer = %o", nd->nd_peer);
      }
      if (nd->nd_tag != 0) {
	printx(", tag = %d", nd->nd_tag);
      }
      printx(", ttl = %d\n", nd->nd_ttl);
      printx("    mac = ");
      printmac(nd->nd_mac);
      printx(", # = %u", nd->nd_nis);
      printx("\n");
    }
  }
}

void show_bridge(object* obj)
{
  bridge* br = obj->obj_bridge;
  ethost* eh;
  int i;

  if (br->br_count == 0)
    return;

  printx("  bridge table (");
  if (br->br_count == 1)
    printx("one entry");
  else
    printx("%d entries", br->br_count);
  printx(")\n");
  for (i = 0; i < EHASHSIZE; i += 1) {
    for (eh = br->br_host[i]; eh != NULL; eh = eh->eth_next) {
      printx("    ");
      printmac(eh->eth_mac);
      printdna(eh->eth_mac);
      printx(" => %s, tag = %d, ttl = %d\n",
	     eh->eth_obj->obj_name, eh->eth_tag, eh->eth_ttl);
    }    
  }
}

void show_members(object* obj)
{
  bridge* br = obj->obj_bridge;
  member* mb;

  if (br->br_members == NULL)
    return;

  printx("  bridge members\n");

  for (mb = br->br_members; mb != NULL; mb = mb->mbr_next) {
    printx("    %s, tag %u\n", mb->mbr_obj->obj_name, mb->mbr_tag);
  }
}

void show_memory(void)
{
  printx("pkt stats: total = %d, free = %d, allocs = %d\n",
	 pk_count, pk_free, pk_alloc);
  printx("eth stats: total = %d, free = %d, allocs = %d\n",
	 et_count, et_free, et_alloc);
  printx("mbr stats: total = %d, free = %d, allocs = %d\n",
	 mb_count, mb_free, mb_alloc);
  printx("obj stats: total = %d, free = %d, allocs = %d\n",
	 ob_count, ob_free, ob_alloc);
}

/*
 *  Show a single object.
 */

void show_object(object* obj)
{
  printx("Object %s, type %s",
	 obj->obj_name, i2s(obj->obj_type, obj_type_names));
  if (obj->obj_iface != NULL)
    printx(", -i=%s", obj->obj_iface);
  if (obj->obj_maxnode != 0)
    printx(", -m=%o", obj->obj_maxnode);
  if (obj->obj_node != 0)
    printx(", -n=%o", obj->obj_node);
  if (obj->obj_tag != 0)
    printx(", -t=%d", obj->obj_tag);
  if (obj->obj_4flag)
    printx(", -4");
  if (obj->obj_6flag)
    printx(", -6");
  if (obj->obj_aflag)
    printx(", -a");
  if (obj->obj_cflag)
    printx(", -c");
  if (obj->obj_dflag)
    printx(", -d");
  if (obj->obj_eflag)
    printx(", -e");
  if (obj->obj_lflag)
    printx(", -l");
  if (obj->obj_rflag)
    printx(", -r");

  switch (obj->obj_type) {
  case OBT_SYNC:
  case OBT_UDP:
  case OBT_TUNNEL:
  case OBT_MLT:
    if (obj->obj_oqspeed != 0)
      printx(", -s=%d", obj->obj_oqspeed);      
    break;
  }
  printx("\n");

  if (obj->obj_type == OBT_ETHER) {
    eth_setproto(obj);
    if (obj->obj_eproto != 0) {
      printx("  Protocol mask = %x", obj->obj_eproto);
      printbits(obj->obj_eproto, obj_proto_names);
      if (obj->obj_eproto & OBP_ANF10) {
	printx(", ANF protocol %04x", obj->obj_port);
      }
      printx("\n");
    }
  }

  printx("  flags = %x", obj->obj_flags);
  printbits(obj->obj_flags, obj_flag_names);
  printx("\n");

  if (obj->obj_xcon != NULL) {
    printx("  points ");
    if (obj == obj->obj_xcon)
      printx("back to %s (looped)\n", obj->obj_name);
    else
      printx("to %s\n", obj->obj_xcon->obj_name);
  }
  if (obj->obj_flags & OBF_NEIGHB) {
    printx("  eth. neighb. ");
    printmac(obj->obj_peermac);
    printx(", proto %04x, last serial %d\n",
	   obj->obj_peerpty, obj->obj_serial);
  }
  switch (obj->obj_type) {
  case OBT_SYNC:
  case OBT_UDP:
    show_ip_conn(obj);
    show_ddcmp_state(obj, 0);
    break;
  case OBT_MLT:
    show_ip_conn(obj);
    break;
  case OBT_TUNNEL:
    show_ip_conn(obj);
    show_tag_table(obj);
    break;
  case OBT_ETHER:
    show_node_table(obj);
    show_bridge(obj);
    break;
  case OBT_BRIDGE:
    show_bridge(obj);
    show_members(obj);
    break;
  case OBT_CMD:
    show_ip_conn(obj);
    break;
  }
  if (obj->obj_flags & OBF_WSUB) {
    printx("  wsub queue size = %d, length = %d, max = %d, drops = %d\n",
	   obj->obj_oqsize, obj->obj_oqlen, obj->obj_oqmax, obj->obj_oqdrop);
  }
}

void show_all_objects(void)
{
  object* obj;

  for (obj = objlist; obj != NULL; obj = obj->obj_next) {
    show_object(obj);
  }
}

/*
 *  Show the DDCMP queues for all sync devices, in great detail.
 */

void show_ddcmp_queues(void)
{
  object* obj;
  struct ddcmp* dd;

  for (obj = objlist; obj != NULL; obj = obj->obj_next) {
    dd = obj->obj_ddcmp;
    if (dd == NULL)
      continue;

    printx("Object %s, type %s\n",
	   obj->obj_name, i2s(obj->obj_type, obj_type_names));

    show_ddcmp_state(obj, 1);
  }
}

/************************************************************************/

/*
 *  Start an interactive command decoder.
 */

void* do_terminal(void* arg)
{
  char buf[1024];
  char* ret;

  for (;;) {
    cm_enter(CMDT_CTY, NULL);
    printx("- ");
    cm_exit();
    ret = fgets(buf, sizeof(buf), stdin);
    if (ret != NULL) {
      cm_enter(CMDT_CTY, NULL);
      cm_line(buf);
      cm_exit();
    }
  }

  /* Dummy return statement. */

  return NULL;
}

/************************************************************************/

/*
 *  Cross-connect two objects.  Exactly how depends on the types of them.
 */

void xcon_bridge(u_char tag, object* src, object* dst)
{
  switch (dst->obj_type) {
  case OBT_LOG:
    mbr_add(src->obj_bridge, dst, tag);
    break;
  default:
    /* This is an error.  Handle how? */
    break;
  }
}

void xcon_ether(u_char tag, object* src, object* dst)
{
  switch (dst->obj_type) {
  case OBT_BRIDGE:
    src->obj_xcon = dst;
    mbr_add(dst->obj_bridge, src, tag);
    break;
  case OBT_ETHER:
    src->obj_xcon = dst;
    dst->obj_xcon = src;
    break;
  case OBT_SYNC:
  case OBT_UDP:
    /* handle E -> S.  Think about this. */
    break;
  case OBT_TUNNEL:
    src->obj_xcon = dst;
    dst->obj_tags[tag].tag_target = src;
    break;
  case OBT_LOG:
    src->obj_xcon = dst;
    break;
  default:
    /* This is an error.  Handle how? */
    break;
  }
}

void xcon_tunnel(u_char tag, object* src, object* dst)
{
  switch (dst->obj_type) {
  case OBT_BRIDGE:
    src->obj_tags[tag].tag_target = dst;
    mbr_add(dst->obj_bridge, src, tag);
    break;
  case OBT_ETHER:
    src->obj_tags[tag].tag_target = dst;
    break;
  case OBT_SYNC:
  case OBT_UDP:
    src->obj_tags[tag].tag_target = dst;
    dst->obj_xcon = src;
    dst->obj_tag = tag;
    break;
  case OBT_TUNNEL:
    src->obj_tags[tag].tag_target = dst;
    dst->obj_tags[tag].tag_target = src;
    break;
  case OBT_LOG:
    src->obj_tags[tag].tag_target = dst;
    break;
  default:
    /* This is an error.  Handle how? */
    break;
  }
}

void xcon_sync(u_char tag, object* src, object* dst)
{
  switch (dst->obj_type) {
  case OBT_BRIDGE:
    src->obj_xcon = dst;
    src->obj_flags |= OBF_ETHER;
    mbr_add(dst->obj_bridge, src, tag);
    break;
  case OBT_ETHER:
    src->obj_xcon = dst;
    src->obj_flags |= OBF_ETHER;
    if (src->obj_node != 0) {
      dst->obj_route[src->obj_node].nd_target = src;
    }
    break;
  case OBT_SYNC:
  case OBT_UDP:
    src->obj_xcon = dst;
    dst->obj_xcon = src;
    break;
  case OBT_TUNNEL:
    src->obj_xcon = dst;
    dst->obj_tags[tag].tag_target = src;
    break;
  case OBT_LOG:
    src->obj_xcon = dst;
    break;
  default:
    /* This is an error.  Handle how? */
    break;
  }
}

void xcon_mlt(u_char tag, object* src, object* dst)
{
  switch (dst->obj_type) {
  case OBT_BRIDGE:
    /* think about this */
    break;
  case OBT_ETHER:
    /* How to do this? */
    break;
  case OBT_SYNC:
  case OBT_UDP:
  case OBT_MLT:
    src->obj_xcon = dst;
    dst->obj_xcon = src;
    break;
  case OBT_TUNNEL:
    src->obj_xcon = dst;
    dst->obj_tags[tag].tag_target = src;
    break;
  case OBT_LOG:
    src->obj_xcon = dst;
    break;
  default:
    /* This is an error.  Handle how? */
    break;
  }
}

void xcon_log(u_char tag, object* src, object* dst)
{
  switch (dst->obj_type) {
  case OBT_BRIDGE:
    mbr_add(dst->obj_bridge, src, tag);
    break;
  default:
    /* error. */
    break;
  }
}

int xcon(object* src, char* tgname)
{
  u_char tag = src->obj_tag;
  object* dst = obj_lookup(tgname, 0);
  
  if (dst == NULL) {
    printx("Target object %s does not exist.\n", tgname);
    return 0;
  }

  switch (src->obj_type) {
  case OBT_NONE:
    /* This should not be possible. */
    break;
  case OBT_BRIDGE:
    xcon_bridge(tag, src, dst);
    break;
  case OBT_ETHER:
    xcon_ether(tag, src, dst);
    break;
  case OBT_TUNNEL:
    xcon_tunnel(tag, src, dst);
    break;
  case OBT_SYNC:
  case OBT_UDP:
    xcon_sync(tag, src, dst);
    break;
  case OBT_LOG:
    xcon_log(tag, src, dst);
    break;
  case OBT_MLT:
    xcon_mlt(tag, src, dst);
    break;
  default:
    /* This is an error.  Handle how? */
    break;
  }

  return 1;
}

/************************************************************************/

unsigned int numarg(char* arg, int radix, u_int min, u_int max, char* why)
{
  unsigned long ret;
  char* endptr;

  if (max == 0)
    max = UINT_MAX;

  ret = strtoul(arg, &endptr, radix);

  if (*endptr != 0) {
    printx("invalid argument (%s) to %s\n", arg, why);
  } else if (ret < min || ret > max) {
    printx("argument (%s) out of range for %s\n", arg, why);
  }

  return ret;
}

void setstring(char** str, char* value)
{
  if (*str != NULL)
    free(*str);

  *str = strdup(value);
}

/*
 ************************************************************************
 *
 *  Run-time command decoding, local terminal and other methods.
 *
 *  First part, helper routines:
 *
 ************************************************************************
 */
 
/*
 *  Complain about a command or somesuch being ambigous:
 */

int cm_ambig(char* token)
{
  printx("Ambigous command (%s)\n", token);
  return 0;
}

/*
 *  Complain if we are read-only.
 */

int cm_writeaccess(void)
{
  if (cmobj != NULL && cmobj->obj_rflag) {
    printx("Sorry, you are read-only.\n");
    return 0;
  }
  return 1;
}

/*
 *  Dispatch on the next token (reading it if needed).
 */

int cm_dispatch(object* obj, cmdb* cmds, char* token)
{
  cmdb* cmd;

  if (token == NULL)
    token = cm_token();

  if (token == NULL) {
    printx("Command missing.\n");
    return 0;
  }

  cmd = cm_lookup(cmds, token);
  if (cmd == NULL) {
    switch (cmlres) {
    case CML_NOMATCH:
      printx("No such command (%s)\n", token);
      break;
    case CML_AMBIG:
      return cm_ambig(token);
    }
    return 0;
  }

  return (*cmd->handler)(obj, cmd);
}

/*
 *  Enter a command context:
 */

void cm_enter(int type, object* obj)
{
  (void) pthread_mutex_lock(&cmdlock);

  cmtype = type;
  cmobj = obj;
}

/*
 *  Exit the current command context:
 */

void cm_exit(void)
{
  /*
   *  If we have printed anything w/o a final newline, print one.
   */
  
  (void) pthread_mutex_unlock(&cmdlock);

  cmtype = CMDT_NONE;
  cmobj = NULL;
}

/*
 *  Get the next token (if any) from the current command line.
 */

char* cm_token(void)
{
  if (cmtext != NULL) {		/* First time, i.e. beginning of line? */
    while (isspace(cmtext[0])) {
      cmtext += 1;
    }
    switch (cmtext[0]) {
    case '#':
      return "#";
    case ';':
      return ";";
    default:
      break;
    }
  }

  cmtoken = strtok(cmtext, " \t\r\n");
  cmtext = NULL;
  return cmtoken;
}

/*
 *  Parse a string from the current line.  If the next character is
 *  a ", return everything up to the next ", else just return the
 *  next token.
 */

char* cm_string(void)
{
  char* line;

  line = strtok(cmtext, "\r\n");
  if (line == NULL)
    return "";

  if (line[0] == '"') {
    /*
     *  This is a quoted string.  Scan for the matching double quote,
     *  and replace it with a NULL character.  Set cmtext to point to
     *  the next character, and return &line[1].
     */
    return strtok(&line[1], "\"");
  }

  cmtext = line;
  return cm_token();
}

/*
 *  Convert a token to an object.
 */

object* cm_tk2obj(char* token)
{
  object* obj;

  obj = obj_lookup(token, 0);
  if (obj == NULL) {
    printx("Object '%s' does not exist\n", token);
    return NULL;
  }

  return obj;
}

/*
 *  Parse the name of an object.  Return object pointer.
 */

object* cm_object(void)
{
  char* token;

  token = cm_token();

  if (token == NULL) {
    printx("Object name missing.\n");
    return NULL;
  }

  return cm_tk2obj(token);
}

/*
 *  Lookup a token in a command table, returning pointer to command
 *  entry.  Return NULL if we fail, with cmlres telling us why.
 */

cmdb* cm_lookup(cmdb* table, char* token)
{
  int i;
  int len;
  cmdb* match;

  len = strlen(token);
  cmlres = CML_NOMATCH;
  match = NULL;
  
  for (i = 0; table[i].cmd != NULL; i += 1) {
    if (strncmp(table[i].cmd, token, len) == 0) {
      switch (cmlres) {
      case CML_NOMATCH:
	cmlres = CML_MATCH;
	match = &table[i];
	break;
      case CML_MATCH:
	cmlres = CML_AMBIG;
	return NULL;
      }
    }
  }

  return match;
}

/*
 ************************************************************************
 *
 *  Run-time command decoding, local terminal and other methods.
 *
 *  Second part, object parameter subroutines:
 *
 ************************************************************************
 */

/*
 *  Subroutines to clear stuff.
 */

int clr_obj_flag(object* obj, cmdb* cmd)
{
  *((u_char*) (((char*) obj) + cmd->offset)) = 0;

  return 1;
}

int clr_obj_str(object* obj, cmdb* cmd)
{
  char** str;

  str = ((char**) (((char*) obj) + cmd->offset));
  if (*str != NULL)
    free(*str);
  *str = NULL;

  return 1;
}

int clr_obj_xcon(object* obj, cmdb* cmd)
{
  printx("can't clear cross-connects yet.\n");

  return 0;
}

int clear_obj_params(object* obj)
{
  cmdb* cmds;
  char* token;

  static cmdb cmd_bridge[] = {
    { "verbose", clr_obj_flag, offsetof(object, obj_vflag) },
    { "xcon", clr_obj_xcon },
    { NULL },
  };

  static cmdb cmd_ether[] = {
    { "anf", clr_obj_flag, offsetof(object, obj_aflag) },
    { "chaos", clr_obj_flag, offsetof(object, obj_cflag) },
    { "decnet", clr_obj_flag, offsetof(object, obj_dflag) },
    { "interface", clr_obj_str, offsetof(object, obj_iface) },
    { "ipv4", clr_obj_flag, offsetof(object, obj_4flag) },
    { "ipv6", clr_obj_flag, offsetof(object, obj_6flag) },
    { "lat", clr_obj_flag, offsetof(object, obj_lflag) },
    { "verbose", clr_obj_flag, offsetof(object, obj_vflag) },
    { "xcon", clr_obj_xcon },
    { NULL },
  };

  static cmdb cmd_cmd[] = {
    { "key", clr_obj_str, offsetof(object, obj_key) },
    { "read-only", clr_obj_flag, offsetof(object, obj_rflag) },
    { "verbose", clr_obj_flag, offsetof(object, obj_vflag) },
    { NULL },
  };

  static cmdb cmd_log[] = {
    { "verbose", clr_obj_flag, offsetof(object, obj_vflag) },
    { "xcon", clr_obj_xcon },
    { NULL },
  };

  static cmdb cmd_mlt[] = {
    { "remote", clr_obj_str, offsetof(object, obj_remote) },
    { "verbose", clr_obj_flag, offsetof(object, obj_vflag) },
    { "xcon", clr_obj_xcon },
    { NULL },
  };

  static cmdb cmd_sync[] = {
    { "anf", clr_obj_flag, offsetof(object, obj_aflag) },
    { "ddcmp", clr_obj_flag, offsetof(object, obj_dflag) },
    { "ether", clr_obj_flag, offsetof(object, obj_eflag) },
    { "remote", clr_obj_str, offsetof(object, obj_remote) },
    { "verbose", clr_obj_flag, offsetof(object, obj_vflag) },
    { "xcon", clr_obj_xcon },
    { NULL },
  };

  static cmdb cmd_tunnel[] = {
    { "key", clr_obj_str, offsetof(object, obj_key) },
    { "remote", clr_obj_str, offsetof(object, obj_remote) },
    { "verbose", clr_obj_flag, offsetof(object, obj_vflag) },
    { "xcon", clr_obj_xcon },
    { NULL },
  };

  static cmdb cmd_udp[] = {
    { "anf", clr_obj_flag, offsetof(object, obj_aflag) },
    { "ddcmp", clr_obj_flag, offsetof(object, obj_dflag) },
    { "ether", clr_obj_flag, offsetof(object, obj_eflag) },
    { "remote", clr_obj_str, offsetof(object, obj_remote) },
    { "verbose", clr_obj_flag, offsetof(object, obj_vflag) },
    { "xcon", clr_obj_xcon },
    { NULL },
  };

  switch (obj->obj_type) {
  case OBT_BRIDGE:
    cmds = cmd_bridge;
    break;
  case OBT_ETHER:
    cmds = cmd_ether;
    break;
  case OBT_TUNNEL:
    cmds = cmd_tunnel;
    break;
  case OBT_SYNC:
    cmds = cmd_sync;
    break;
  case OBT_UDP:
    cmds = cmd_udp;
    break;
  case OBT_LOG:
    cmds = cmd_log;
    break;
  case OBT_MLT:
    cmds = cmd_mlt;
    break;
  case OBT_CMD:
    cmds = cmd_cmd;
    break;
  default:
    /* This is an internal error */
    return 0;
  }

  token = cm_token();

  while (token != NULL) {
    if (cm_dispatch(obj, cmds, token) == 0)
      return 0;
    token = cm_token();
  }

  return 1;
}

/*
 *  Subroutines to set stuff.
 */

int set_obj_flag(object* obj, cmdb* cmd)
{
  *((u_char*) (((char*) obj) + cmd->offset)) = 1;

  return 1;
}

int set_obj_u_char(object* obj, cmdb* cmd)
{
  u_char val;
  char* arg;

  arg = cm_token();
  if (arg == NULL) {
    printx("Argument missing for %s\n", cmd->cmd);
    return 0;
  }

  val = numarg(arg, cmd->radix, cmd->lower, cmd->upper, cmd->cmd);

  *((u_char*) (((char*) obj) + cmd->offset)) = val;

  return 1;
}

int set_obj_u_short(object* obj, cmdb* cmd)
{
  u_short val;
  char* arg;

  arg = cm_token();
  if (arg == NULL) {
    printx("Argument missing for %s\n", cmd->cmd);
    return 0;
  }

  val = numarg(arg, cmd->radix, cmd->lower, cmd->upper, cmd->cmd);

  *((u_short*) (((char*) obj) + cmd->offset)) = val;

  return 1;
}

int set_obj_u_int(object* obj, cmdb* cmd)
{
  u_int val;
  char* arg;

  arg = cm_token();
  if (arg == NULL) {
    printx("Argument missing for %s\n", cmd->cmd);
    return 0;
  }

  val = numarg(arg, cmd->radix, cmd->lower, cmd->upper, cmd->cmd);

  *((u_int*) (((char*) obj) + cmd->offset)) = val;

  return 1;

}

int set_obj_str(object* obj, cmdb* cmd)
{
  char** str;
  char* val;

  str = ((char**) (((char*) obj) + cmd->offset));
  val = cm_string();
  setstring(str, val);

  return 1;
}

int set_obj_xcon(object* obj, cmdb* cmd)
{
  char* token;

  token = cm_token();

  if (token == NULL) {
    printx("No argument for xcon\n");
    return 0;
  }

  return xcon(obj, token);
}

int set_obj_params(object* obj, int needargs)
{
  cmdb* cmds;
  char* token;

  static cmdb cmd_bridge[] = {
    { "verbose", set_obj_flag, offsetof(object, obj_vflag) },
    { "xcon", set_obj_xcon },
    { NULL },
  };

  static cmdb cmd_cmd[] = {
    { "key", set_obj_str, offsetof(object, obj_key) },
    { "port", set_obj_u_short, offsetof(object, obj_port), 10, 1,  65535 },
    { "read-only", set_obj_flag, offsetof(object, obj_rflag) },
    { "verbose", set_obj_flag, offsetof(object, obj_vflag) },
    { NULL },
  };

  static cmdb cmd_ether[] = {
    { "anf", set_obj_flag, offsetof(object, obj_aflag) },
    { "chaos", set_obj_flag, offsetof(object, obj_cflag) },
    { "decnet", set_obj_flag, offsetof(object, obj_dflag) },
    { "interface", set_obj_str, offsetof(object, obj_iface) },
    { "ipv4", set_obj_flag, offsetof(object, obj_4flag) },
    { "ipv6", set_obj_flag, offsetof(object, obj_6flag) },
    { "lat", set_obj_flag, offsetof(object, obj_lflag) },
    { "maxnode", set_obj_u_char, offsetof(object, obj_maxnode), 8, 0, 127 },
    { "node", set_obj_u_char, offsetof(object, obj_node), 8, 0, 127 },
    { "proto", set_obj_u_short, offsetof(object, obj_port), 16, 1, 0xffff },
    { "tag", set_obj_u_char, offsetof(object, obj_tag), 10, 0, 255 },
    { "verbose", set_obj_flag, offsetof(object, obj_vflag) },
    { "xcon", set_obj_xcon },
    { NULL },
  };

  static cmdb cmd_log[] = {
    { "verbose", set_obj_flag, offsetof(object, obj_vflag) },
    { "xcon", set_obj_xcon },
    { NULL },
  };

  static cmdb cmd_mlt[] = {
    { "gap", set_obj_u_int, offsetof(object, obj_oqdly), 10, 0, 0 },
    { "port", set_obj_u_short, offsetof(object, obj_port), 10, 1,  65535 },
    { "queue", set_obj_u_int, offsetof(object, obj_oqsize), 10, 1, 100 },
    { "remote", set_obj_str, offsetof(object, obj_remote) },
    { "speed", set_obj_u_int, offsetof(object, obj_oqspeed), 10, 0, 0 },
    { "tag", set_obj_u_char, offsetof(object, obj_tag), 10, 0, 255 },
    { "verbose", set_obj_flag, offsetof(object, obj_vflag) },
    { "xcon", set_obj_xcon },
    { NULL },
  };

  static cmdb cmd_sync[] = {
    { "anf", set_obj_flag, offsetof(object, obj_aflag) },
    { "ddcmp", set_obj_flag, offsetof(object, obj_dflag) },
    { "ether", set_obj_flag, offsetof(object, obj_eflag) },
    { "gap", set_obj_u_int, offsetof(object, obj_oqdly), 10, 0, 0 },
    { "maxnode", set_obj_u_char, offsetof(object, obj_maxnode), 8, 0, 127 },
    { "node", set_obj_u_char, offsetof(object, obj_node), 8, 0, 127 },
    { "port", set_obj_u_short, offsetof(object, obj_port), 10, 1,  65535 },
    { "queue", set_obj_u_int, offsetof(object, obj_oqsize), 10, 1, 100 },
    { "remote", set_obj_str, offsetof(object, obj_remote) },
    { "speed", set_obj_u_int, offsetof(object, obj_oqspeed), 10, 0, 0 },
    { "tag", set_obj_u_char, offsetof(object, obj_tag), 10, 0, 255 },
    { "verbose", set_obj_flag, offsetof(object, obj_vflag) },
    { "xcon", set_obj_xcon },
    { NULL },
  };

  static cmdb cmd_tunnel[] = {
    { "gap", set_obj_u_int, offsetof(object, obj_oqdly), 10, 0, 0 },
    { "key", set_obj_str, offsetof(object, obj_key) },
    { "port", set_obj_u_short, offsetof(object, obj_port), 10, 1,  65535 },
    { "queue", set_obj_u_int, offsetof(object, obj_oqsize), 10, 1, 100 },
    { "remote", set_obj_str, offsetof(object, obj_remote) },
    { "speed", set_obj_u_int, offsetof(object, obj_oqspeed), 10, 0, 0 },
    { "tag", set_obj_u_char, offsetof(object, obj_tag), 10, 0, 255 },
    { "verbose", set_obj_flag, offsetof(object, obj_vflag) },
    { "xcon", set_obj_xcon },
    { NULL },
  };

  static cmdb cmd_udp[] = {
    { "anf", set_obj_flag, offsetof(object, obj_aflag) },
    { "ddcmp", set_obj_flag, offsetof(object, obj_dflag) },
    { "ether", set_obj_flag, offsetof(object, obj_eflag) },
    { "gap", set_obj_u_int, offsetof(object, obj_oqdly), 10, 0, 0 },
    { "lport", set_obj_u_short, offsetof(object, obj_lport), 10, 1, 65535 },
    { "maxnode", set_obj_u_char, offsetof(object, obj_maxnode), 8, 0, 127 },
    { "node", set_obj_u_char, offsetof(object, obj_node), 8, 0, 127 },
    { "port",  set_obj_u_short, offsetof(object, obj_port), 10, 1,  65535 },
    { "queue", set_obj_u_int, offsetof(object, obj_oqsize), 10, 1, 100 },
    { "remote", set_obj_str, offsetof(object, obj_remote) },
    { "speed", set_obj_u_int, offsetof(object, obj_oqspeed), 10, 0, 0 },
    { "tag", set_obj_u_char, offsetof(object, obj_tag), 10, 0, 255 },
    { "verbose", set_obj_flag, offsetof(object, obj_vflag) },
    { "xcon", set_obj_xcon },
    { NULL },
  };

  switch (obj->obj_type) {
  case OBT_BRIDGE:
    cmds = cmd_bridge;
    break;
  case OBT_ETHER:
    cmds = cmd_ether;
    break;
  case OBT_TUNNEL:
    cmds = cmd_tunnel;
    break;
  case OBT_SYNC:
    cmds = cmd_sync;
    break;
  case OBT_UDP:
    cmds = cmd_udp;
    break;
  case OBT_LOG:
    cmds = cmd_log;
    break;
  case OBT_MLT:
    cmds = cmd_mlt;
    break;
  case OBT_CMD:
    cmds = cmd_cmd;
    break;
  default:
    /* This is an internal error */
    return 0;
  }

  token = cm_token();
  if (token == NULL) {
    if (needargs) {
      printx("set object - args missing\n");
      return 0;
    }
    return 1;
  }

  while (token != NULL) {
    if (cm_dispatch(obj, cmds, token) == 0)
      return 0;
    token = cm_token();
  }

  return 1;
}


/*
 ************************************************************************
 *
 *  Run-time command decoding, local terminal and other methods.
 *
 *  Actual command handlers:
 *
 ************************************************************************
 */

/*
 *  "clear object" <object> <parameter> [value] ...
 */

int cmd_clear_object(object* obj, cmdb* cmd)
{
  obj = cm_object();

  if (obj == NULL) {
    return 0;
  }

  return clear_obj_params(obj);
}

/*
 *  "clear verbose"  -- set the global verbose flag.
 */

int cmd_clear_verbose(object* obj, cmdb* cmd)
{
  verbose = 0;

  return 1;
}

/*
 *  "clear" <keyword> [args...]
 *  "clear" <object> <parameter> [value] ...
 */

int cmd_clear(object* obj, cmdb* cmd)
{
  char* token;
  
  static cmdb cmds[] = {
    { "object",   cmd_clear_object },
    { "verbose",  cmd_clear_verbose },
    { NULL },
  };
  
  if (!cm_writeaccess())
    return 0;

  token = cm_token();
  if (token == NULL) {
    printx("clear what?\n");
    return 0;
  }

  cmd = cm_lookup(cmds, token);
  if (cmd != NULL)
    return (*cmd->handler)(obj, cmd);

  if (cmlres == CML_AMBIG)
    return cm_ambig(token);

  obj = obj_lookup(token, 0);
  if (obj != NULL)
    return clear_obj_params(obj);

  printx("does not match keyword or object\n");
  return 0;
}

/*
 *  Handle a comment, i.e. ignore the rest of the line.
 */

int cmd_comment(object* obj, cmdb* cmd)
{
  return 1;			/* We are done, all is OK. */
}

/*
 *  "define" <object type> <name> [...]
 */

int cmd_define(object* obj, cmdb* cmd)
{
  char* token;
  int type;

  static cmdb cmds[] = {
    { "bridge",   NULL, OBT_BRIDGE },
    { "command",  NULL, OBT_CMD },
    { "ethernet", NULL, OBT_ETHER },
    { "log",      NULL, OBT_LOG },
    { "multinet", NULL, OBT_MLT },
    { "sync",     NULL, OBT_SYNC },
    { "tunnel",   NULL, OBT_TUNNEL },
    { "udp",      NULL, OBT_UDP },
    { NULL },
  };

  if (!cm_writeaccess())
    return 0;

  token = cm_token();
  if (token == NULL) {
    printx("Argument missing.\n");
    return 0;
  }

  cmd = cm_lookup(cmds, token);
  if (cmd == NULL) {
    printx("Unknown object type (%s).\n", token);
    return 0;
  }

  /* Since all object types have unique names ... */

  type = cmd->offset;

  token = cm_token();		/* Get name. */
  if (token == NULL) {
    printx("Object name missing.\n");
    return 0;
  }

  if (!obj_chkname(token)) {
    printx("Illegal object name.\n");
    return 0;
  }

  obj = obj_create(type, token);

  return set_obj_params(obj, 0);
}

/*
 *  "freeze"  -- debug command.
 */

int cmd_freeze(object* obj, cmdb* cmd)
{
  if (!cm_writeaccess())
    return 0;

  frozen = 1;
  printx("*** we are now frozen ***\n");

  return 1;
}

/*
 *  help for the "clear" command:
 */

int cmd_help_clear(object* obj, cmdb* cmd)
{
  printx(
"Format:\n"
"  clear object <obj> <parameter>   -- clear object parameter.\n"
"  clear <obj> <parameter>          -- short form of above.\n"
"  clear verbose                    -- clear global verbose flag.\n"
"\n"
"  see the 'define' command for information on what parameters\n"
"  exist.\n"
	 );
  return 1;
}

/*
 *  help for the "define" command, with subcommands and other information.
 */

void hlp_ip_common(int type)
{
  printx(
"\n"
"  IP connection parameters:\n"
"\n"
"    gap <n>         -- set inter-packet gap for transmission\n"
"    queue <n>       -- set output queue size (no packets)\n"
"    speed <bps>     -- set output speed limit (bit/second)\n"
"\n"
"    port <num>      -- set port number to connect/listen to\n"
"    remote <addr>   -- set remote address to connect to\n"
	 );
  if (type == OBT_UDP) {
    printx(
"    lport <num>     -- set local port to use\n"
	   );
  }
}

int cmd_hlp_def_bridge(object* obj, cmdb* cmd)
{
  printx(
"Object type: command\n"
"\n"
"  This object is a packet bridge.  Parameters:\n"
"\n"
"    verbose  -- local verbose flag\n"
	 );
  return 1;
}

int cmd_hlp_def_command(object* obj, cmdb* cmd)
{
  printx(
"Object type: command\n"
"\n"
"  This object is a remote command handler.  Parameters:\n"
"\n"
"    key        -- string used to authenticate and encrypt the session\n"
"    port       -- TCP port to listen to\n"
"    read-only  -- read-only flag\n"
"    verbose    -- local verbose flag\n"
	 );
  return 1;
}

int cmd_hlp_def_ether(object* obj, cmdb* cmd)
{
  printx(
"Object type: ethernet\n"
"\n"
"  This object talks to an ethernet device.  Parameters:\n"
"\n"
"    anf             -- enable ANF-10 packets\n"
"    chaos           -- enable Chaosnet packets\n"
"    decnet          -- enable DECnet packets\n"
"    ipv4            -- enable IPv4 packets (inc. ARP)\n"
"    ipv6            -- enable IPv6 packets\n"
"    lat             -- enable LAT packets\n"
"    proto <num>     -- eth. protocol for ANF-10\n"
"\n"
"    interface <int> -- interface to talk to.  If not set, use obj. name\n"
"    node <number>   -- limit ANF-10 to this node on ethernet\n"
"    tag <tag>       -- set tag for packets\n"
"    verbose         -- local verbose flag\n"
"    xcon <obj>      -- cross-connect to <obj>\n"
	 );
  return 1;
}

int cmd_hlp_def_log(object* obj, cmdb* cmd)
{
  printx(
"Object type: log\n"
"\n"
"  This object is a debugging aid.\n"
	 );
  return 1;
}

int cmd_hlp_def_mlt(object* obj, cmdb* cmd)
{
  printx(
"Object type: multinet\n"
"\n"
"  This object talks serial DECnet over a TCP/IP connection.  Parameters:\n"
"\n"
"    tag <tag>       -- set tag for packets\n"
"    verbose         -- local verbose flag\n"
"    xcon <obj>      -- cross-connect to <obj>\n"
	 );

  hlp_ip_common(OBT_MLT);

  return 1;
}

int cmd_hlp_def_sync(object* obj, cmdb* cmd)
{
  printx(
"Object type: sync\n"
"\n"
"  This object talks DDCMP over TCP.  Parameters:\n"
"\n"
"    anf             -- do ANF-10 style DDCMP\n"
"    ddcmp           -- terminate DDCMP here\n"
"    ethernet        -- ethernet emulate flag\n"
"    node <number>   -- talk to ANF-10 node <number>\n"
"    tag <tag>       -- set tag for packets\n"
"    verbose         -- local verbose flag\n"
"    xcon <obj>      -- cross-connect to <obj>\n"
);

  hlp_ip_common(OBT_SYNC);

  return 1;
}

int cmd_hlp_def_tunnel(object* obj, cmdb* cmd)
{
  printx(
"Object type: tunnel\n"
"\n"
"  This object tunnels packets to elsewhere.  Parameters:\n"
"\n"
"    key             -- string used to authenticate and encrypt the session\n"
"    tag <tag>       -- set tag for packets\n"
"    verbose         -- local verbose flag\n"
"    xcon <obj>      -- cross-connect to <obj>\n"
	 );

  hlp_ip_common(OBT_TUNNEL);

  return 1;
}

int cmd_hlp_def_udp(object* obj, cmdb* cmd)
{
  printx(
"Object type: udp\n"
"\n"
"  This object talks DDCMP over UDP.  Parameters:\n"
"\n"
"    anf             -- do ANF-10 style DDCMP\n"
"    ddcmp           -- terminate DDCMP here\n"
"    ethernet        -- ethernet emulate flag\n"
"    node <number>   -- talk to ANF-10 node <number>\n"
"    tag <tag>       -- set tag for packets\n"
"    verbose         -- local verbose flag\n"
"    xcon <obj>      -- cross-connect to <obj>\n"
	 );

  hlp_ip_common(OBT_UDP);

  return 1;
}

int cmd_help_define(object* obj, cmdb* cmd)
{
  static cmdb cmds[] = {
    { "bridge",   cmd_hlp_def_bridge },
    { "command",  cmd_hlp_def_command },
    { "ethernet", cmd_hlp_def_ether },
    { "log",      cmd_hlp_def_log },
    { "multinet", cmd_hlp_def_mlt },
    { "sync",     cmd_hlp_def_sync },
    { "tunnel",   cmd_hlp_def_tunnel },
    { "udp",      cmd_hlp_def_udp },
    { NULL },
  };

  char* token;
  int i;

  token = cm_token();
  if (token != NULL) {
    cmd = cm_lookup(cmds, token);
    if (cmd != NULL)
      return (*cmd->handler)(obj, cmd);

    printx("Unknown or ambigous object type (%s)\n", token);
    return 0;
  }

  printx(
"Format:\n"
"  define <type> <name> [optional parameters]\n"
"\n"
"  this creates an object of <type> with a name of <name>.  Types are:\n"
"  "
	 );

  for (i = 0; cmds[i].cmd != NULL; i += 1) {
    printx("  %s", cmds[i].cmd);
  }

  printx("\n"
"  <name> is a unique name for this object.\n"
"\n"
"  type 'help define <type>' for more information.\n"
	 );
  return 1;
}

int cmd_help_help(object* obj, cmdb* cmd)
{
  printx("Wise guy...\n");

  return 1;
}

int cmd_help_list(object* obj, cmdb* cmd)
{
  printx(
"Format:\n"
"  list objects    -- list all objects, one per line.\n"
"\n"
"  with no argument, also list all objects.\n"
	 );
  return 1;
}

int cmd_help_quit(object* obj, cmdb* cmd)
{
  printx(
"Format:\n"
"  quit\n"
"\n"
"  this command simply quits a remote connection.  It has no effect\n"
"  on the local console.\n"
	 );
  return 1;
}

int cmd_help_set(object* obj, cmdb* cmd)
{
  printx(
"Format:\n"
"  set object <obj> parameter   -- set object parameter.\n"
"  set <obj> parameter          -- short form of above.\n"
"  set verbose                  -- set global verbose flag.\n"
"\n"
"  see the 'define' command for information on what parameters\n"
"  exist.\n"
	 );
  return 1;
}

int cmd_help_show(object* obj, cmdb* cmd)
{
  printx(
"Format:\n"
"  show ddcmp           -- show ddcmp data, in detail.\n"
"  show memory          -- show memory usage etc.\n"
"  show object <obj>    -- show this object.\n"
"  show version         -- show current version info.\n"
"  show <obj>           -- show this object.\n"
"\n"
"  with no argument, shows all objects.\n"
	 );
  return 1;
}

int cmd_help_start(object* obj, cmdb* cmd)
{
  printx(
"Format:\n"
"  start <obj>    -- start this object if not already started.\n"
"\n"
"  with no argument, starts all stopped objects.\n"
	 );
  return 1;
}

int cmd_help_stop(object* obj, cmdb* cmd)
{
  printx(
"Format:\n"
"  stop <obj>    -- stop this object if it is running.\n"
	 );
  return 1;
}

int cmd_help(object* obj, cmdb* cmd)
{
  static cmdb cmds[] = {
    { "clear",    cmd_help_clear },
    { "define",   cmd_help_define },
    { "help",     cmd_help_help },
    { "list",     cmd_help_list },
    { "quit",     cmd_help_quit },
    { "set",      cmd_help_set },
    { "show",     cmd_help_show },
    { "start",    cmd_help_start },
    { "stop",     cmd_help_stop },
    { NULL },
  };

  char* token;
  int i;

  token = cm_token();
  if (token != NULL) {
    cmd = cm_lookup(cmds, token);
    if (cmd != NULL)
      return (*cmd->handler)(obj, cmd);

    printx("Unknown or ambigous command (%s)\n", token);
    return 0;
  }

  printx("help is available for the following commands:\n");
  for (i = 0; cmds[i].cmd != NULL; i += 1) {
    printx("  %s", cmds[i].cmd);
  }
  printx("\n");
  return 1;
}

/*
 *  "list" args ...
 */

int cmd_list_objects(object* obj, cmdb* cmd)
{
  for (obj = objlist; obj != NULL; obj = obj->obj_next) {
    printx("Object %s, type %s",
	   obj->obj_name, i2s(obj->obj_type, obj_type_names));
    printx(", %s", obj->obj_flags & OBF_UP? "running" : "stopped");
    printx("\n");
  }

  return 1;
}

int cmd_list(object* obj, cmdb* cmd)
{
  char* token;

  static cmdb cmds[] = {
    { "objects",  cmd_list_objects },
    { NULL },
  };

  token = cm_token();
  if (token == NULL)
    return cmd_list_objects(obj, cmd);

  cmd = cm_lookup(cmds, token);
  if (cmd != NULL)
    return (*cmd->handler)(obj, cmd);

  printx("does not match keyword.\n");
  return 0;
}

/*
 *  "quit" -- for remote connections.
 */

int cmd_quit(object* obj, cmdb* cmd)
{
  switch (cmtype) {
  case CMDT_TCPIP:
      cmobj->obj_flags |= OBF_QUIT;
    break;
  default:
    printx("Can't quit from here.\n");
    break;
  }
  return 1;
}

/*
 *  "set object" <object> <arg> [value] ...
 */

int cmd_set_object(object* obj, cmdb* cmd)
{
  obj = cm_object();

  if (obj == NULL) {
    return 0;
  }

  return set_obj_params(obj, 1);
}

/*
 *  "set verbose"  -- set the global verbose flag.
 */

int cmd_set_verbose(object* obj, cmdb* cmd)
{
  verbose = 1;

  return 1;
}

/*
 *  "set <keyword>" args
 *  "set" <object> <parameter> [value] ...
 */

int cmd_set(object* obj, cmdb* cmd)
{
  char* token;
  
  static cmdb cmds[] = {
    { "object",   cmd_set_object },
    { "verbose",  cmd_set_verbose },
    { NULL },
  };
  
  if (!cm_writeaccess())
    return 0;

  token = cm_token();
  if (token == NULL) {
    printx("set what?\n");
    return 0;
  }

  cmd = cm_lookup(cmds, token);
  if (cmd != NULL)
    return (*cmd->handler)(obj, cmd);

  /* should handle CML_AMBIG here. */

  obj = obj_lookup(token, 0);
  if (obj != NULL)
    return set_obj_params(obj, 1);

  printx("does not match keyword or object\n");
  return 0;
}

/*
 *  "show" args
 */

int cmd_show_ddcmp(object* obj, cmdb* cmd)
{
  show_ddcmp_queues();

  return 1;
}

int cmd_show_memory(object* obj, cmdb* cmd)
{
  show_memory();

  return 1;
}

int cmd_show_object(object* obj, cmdb* cmd)
{
  obj = cm_object();
  if (obj == NULL)
    return 0;

  show_object(obj);

  return 1;
}

int cmd_show_version(object* obj, cmdb* cmd)
{
  prvers();

  return 1;
}

int cmd_show(object* obj, cmdb* cmd)
{
  static cmdb cmds[] = {
    { "ddcmp",   cmd_show_ddcmp },
    { "memory",  cmd_show_memory },
    { "object",  cmd_show_object },
    { "version", cmd_show_version },
    { NULL },
  };

  char* token;

  token = cm_token();
  if (token == NULL) {
    // show_memory();
    show_all_objects();
    return 1;
  }

  cmd = cm_lookup(cmds, token);
  if (cmd != NULL)
    return (*cmd->handler)(obj, cmd);

  /* should handle CML_AMBIG here. */

  obj = obj_lookup(token, 0);
  if (obj != NULL) {
    show_object(obj);
    return 1;
  }

  printx("does not match keyword or object\n");
  return 0;
}

/*
 *  "start" <object>
 *
 *  with no argument, starts all dormant objects.
 */

int cmd_start(object* obj, cmdb* cmd)
{
  char* token;

  if (!cm_writeaccess())
    return 0;

  token = cm_token();
  if (token == NULL) {
    for (obj = objlist; obj != NULL; obj = obj->obj_next) {
      if (!(obj->obj_flags & OBF_UP)) {
	start_obj(obj);
      }
    }
    return 1;
  }

  obj = cm_tk2obj(token);
  if (obj == NULL) {
    return 0;
  }

  if (obj->obj_flags & OBF_UP) {
    printx("object %s is already started.\n", obj->obj_name);
    return 1;
  }

  printx("starting object %s\n", obj->obj_name);
  start_obj(obj);

  return 1;
}

/*
 *  "stop" <object>
 */

int cmd_stop(object* obj, cmdb* cmd)
{
  if (!cm_writeaccess())
    return 0;

  obj = cm_object();
  if (obj == NULL)
    return 0;

  if (!(obj->obj_flags & OBF_UP)) {
    printx("object %s is not running.\n", obj->obj_name);
    return 1;
  }

  printx("stopping object %s\n", obj->obj_name);
  stop_obj(obj);

  return 1;
}

/*
 ************************************************************************
 *
 *  Run-time command decoding.
 *
 *  Final part, main entry points.
 *
 ************************************************************************
 */

/*
 *  Handle a line of text as a command:
 */

void cm_line(char* text)
{
  static cmdb cmds[] = {
    { "#",        cmd_comment },
    { ";",        cmd_comment },
    { "?",        cmd_help },
    { "clear",    cmd_clear },
    { "define",   cmd_define },
    { "freeze",   cmd_freeze },
    { "help",     cmd_help },
    { "list",     cmd_list },
    { "quit",     cmd_quit },
    { "set",      cmd_set },
    { "show",     cmd_show },
    { "start",    cmd_start },
    { "stop",     cmd_stop },
    { NULL },
  };
  
  cmdb* cmd;
  char* token;

  cmtext = text;		/* Remember for later. */

  token = cm_token();		/* Get first (next) token. */

  if (token == NULL)		/* If none, - */
    return;			/*   just return. */

  cmd = cm_lookup(cmds, token);
  if (cmd == NULL) {
    switch (cmlres) {
    case CML_NOMATCH:
      printx("No such command (%s)\n", token);
      break;
    case CML_AMBIG:
      printx("Ambigous command (%s)\n", token);
      break;
    }
    return;
  }

  (*cmd->handler)(NULL, cmd);
}

/*
 *  Do all lines in file as commands.  The command interlock should
 *  be held (we don't know where we are called from).
 */

void cm_file(char* filename)
{
  char buf[1024];
  char* ret;
  FILE* f;

  printx("Command file: %s\n", filename);

  f = fopen(filename, "r");

  if (f == NULL) {
    printx("Can't open %s for reading.\n", filename);
    return;
  }

  while (!feof(f)) {
    ret = fgets(buf, sizeof(buf), f);
    if (ret != NULL) {
      cm_line(buf);
    }
  }

  (void) fclose(f);
}

/*
 ************************************************************************
 *
 *  Main program, command line argument handling:
 *
 ************************************************************************
 */

void usage(int shortflag)
{
  if (shortflag) {
    fprintf(stderr, "Type %s -h for help.\n", programname);
    exit(EXIT_FAILURE);
  }

  printf("Usage: %s obj args [obj args] [file]\n", programname);
  printf(
"\n"
"    Help options:\n"
"\n"
"     -h           Print this help text\n"
"     -v           Print version number\n"
"\n"
"    The following options define objects:\n"
"\n"
"     -B <name>    define bridge\n"
"     -C <name>    define remote command\n"
"     -E <name>    define ethernet\n"
"     -L <name>    define logger\n"
"     -M <name>    define multinet\n"
"     -S <name>    define sync/tcp\n"
"     -T <name>    define tunnel\n"
"     -U <name>    define sync/udp\n"
"\n"
"    Global flags:\n"
"\n"
"     -D           Disable command decoder\n"
"     -DD          Detach from terminal\n"
"     -V           Increase verbose level\n"
"     -Z           Show configuration and exit\n"
"\n"
"    Args to configure objects:\n"
"\n"
"     -4           sets IPv4 flag (ethernet)\n"
"     -6           sets IPv6 flag (ethernet)\n"
"     -a           sets ANF flag (sync, ethernet)\n"
"     -c           sets CHAOS flag (ethernet)\n"
"     -d           sets DDCMP flag (sync)\n"
"     -d           sets DECnet flag (ethernet)\n"
"     -e           sets ethernet emulate flag (sync)\n"
"     -g <usecs>   sets inter-packet gap (IP connections)\n"
"     -m <number>  sets max node.  Strip neighbour msgs\n"
"     -i <name>    sets interface (ethernet)\n"
"     -k <key>     sets auth/encrypt key (tunnels, command)\n"
"     -l           sets LAT flag (ethernet)\n"
"     -l <port>    sets local port (sync/udp)\n"
"     -n <number>  sets node number for object\n"
"     -p <port>    sets port number (tunnels, sync, command)\n"
"     -p <proto>   sets protocol number (ethernet)\n"
"     -r           sets read-only mode (command)\n"
"     -r <addr>    do active connect (tunnel, sync/tcp)\n"
"     -r <addr>    sets remote addr (sync/udp)\n"
"     -s <bps>     sets max transmission speed (IP connections)\n"
"     -t <slot>    sets tag\n"
"     -v           sets object's verbose flag\n"
"     -x <name>    cross-connect to other object\n"
"\n"
"    Non-option arguments are names of command files.\n"
"\n"
	 );
  exit(EXIT_SUCCESS);
}

#define OPTS(list) ("B:C:DE:I:L:M:S:T:U:VZ" list)

int main(int argc, char* argv[])
{
  int zflag = 0;
  int hflag = 0;
  int ch;
  int ret;
  struct object* obj = NULL;	/* Init to NULL to make gcc shut TF up. */
  struct tm* tm;
  char* opts = OPTS("hv");	/* Initially allow help flags. */

  programname = argv[0];        /* Keep for later. */
  
  while ((ch = getopt(argc, argv, opts)) != -1) {
    switch (ch) {
    case 'B':			/* Define bridge object. */
      obj = obj_create(OBT_BRIDGE, optarg);
      opts = OPTS("vx:");
      break;
    case 'C':			/* Define remote command handler. */
      obj = obj_create(OBT_CMD, optarg);
      opts = OPTS("k:p:rv");
      break;
    case 'D':			/* Detach, don't run command decoder. */
      if (nocmdhflag)		/* If more than once "-DD", also detach. */
	detachflag = 1;
      nocmdhflag = 1;		/* Say no command handler wanted. */
      opts = OPTS("");
      break;
    case 'E':                   /* Define ethernet object. */
      obj = obj_create(OBT_ETHER, optarg);
      opts = OPTS("46acdi:lm:n:p:t:vx:");
      break;
    case 'L':			/* Define log object. */
      obj = obj_create(OBT_LOG, optarg);
      opts = OPTS("vx:");
      break;
    case 'M':			/* Define multinet object. */
      obj = obj_create(OBT_MLT, optarg);
      opts = OPTS("g:p:q:r:s:t:vx:");
      break;
    case 'S':                   /* Define sync (tcp) object. */
      obj = obj_create(OBT_SYNC, optarg);
      opts = OPTS("adeg:m:n:p:q:r:s:t:vx:");
      break;
    case 'T':                   /* Define tunnel object. */
      obj = obj_create(OBT_TUNNEL, optarg);
      opts = OPTS("g:k:p:q:r:s:t:vx:");
      break;
    case 'U':                   /* Define sync (udp) object. */
      obj = obj_create(OBT_UDP, optarg);
      opts = OPTS("adeg:l:m:n:p:q:r:s:t:vx:");
      break;
    case 'V':                   /* Increase global verbose level. */
      verbose += 1;
      opts = OPTS("");
      break;
    case 'Z':
      zflag = 1;
      opts = OPTS("");
      break;
    /*
     *  End of common options.  Do ev. extra ones:
     */
    case '4':			/* Set ipv4 flag. */
      obj->obj_4flag = 1;
      break;
    case '6':			/* Set ipv6 flag. */
      obj->obj_6flag = 1;
      break;
    case 'a':                   /* Set 'a' flag. */
      obj->obj_aflag = 1;
      break;
    case 'c':			/* Set 'c' flag. */
      obj->obj_cflag = 1;
      break;
    case 'd':                   /* Set 'd' flag. */
      obj->obj_dflag = 1;
      break;
    case 'e':                   /* Set 'e' flag. */
      obj->obj_eflag = 1;
      break;
    case 'g':			/* Set inter-packet gap (IP connections). */
      obj->obj_oqdly = numarg(optarg, 10, 0, 1000000, "-g");
      break;
    case 'h':			/* Ask for help. */
      if (optind == 2) {
	usage(0);
	exit(EXIT_SUCCESS);
      }
      /* in case other uses of -h */
      break;
    case 'i':                   /* Set interface (ethernet). */
      obj->obj_iface = strdup(optarg);
      break;
    case 'k':                   /* Set key (tunnel). */
      obj->obj_key = strdup(optarg);
      break;
    case 'l':
      if (obj->obj_type == OBT_ETHER)
	obj->obj_lflag = 1;
      else
	obj->obj_lport = numarg(optarg, 10, 1, 65535, "-l");
      break;
    case 'm':                   /* Set max-node. */
      obj->obj_maxnode = numarg(optarg, 8, 1, 127, "-m");
      break;
    case 'n':                   /* Set node. */
      obj->obj_node = numarg(optarg, 8, 0, 127, "-n");
      break;
    case 'p':                   /* Set port (sync and tunnel). */
      if (obj->obj_type == OBT_ETHER)
	obj->obj_port = numarg(optarg, 16, 1, 65535, "-p");
      else
	obj->obj_port = numarg(optarg, 10, 1, 65535, "-p");
      break;
    case 'q':			/* Set output queue length (IP conns). */
      obj->obj_oqsize = numarg(optarg, 10, 1, 100, "-q");
      break;
    case 'r':                   /* Set remote (sync and tunnel). */
      if (obj->obj_type == OBT_CMD)
	obj->obj_rflag = 1;	/* ... or read-only if remote command. */
      else
	obj->obj_remote = optarg;
      break;
    case 's':			/* Set output speed limit (IP conns). */
      obj->obj_oqspeed = numarg(optarg, 10, 0, 0, "-s");
      break;
    case 't':                   /* Set tag. */
      obj->obj_tag = numarg(optarg, 10, 0, 255, "-t");
      break;
    case 'v':			/* Set 'v' flag. */
      if (optind == 2) {	/* ... or print version number. */
	prvers();
	exit(EXIT_SUCCESS);
      }
      obj->obj_vflag = 1;
      break;
    case 'x':                   /* Cross-connect objects. */
      if (!xcon(obj, optarg))
	exit(EXIT_FAILURE);
      break;
    default:
      usage(1);
      break;
    }
  }

  argc -= optind;
  argv += optind;

  /*
   *  If we have any non-option arguments, treat them as names
   *  of files with configuration commands.
   */

  while (argc-- > 0) {
    cm_enter(CMDT_CTY, NULL);
    cm_file(*argv++);
    cm_exit();
  }

  if (zflag) {
    show_all_objects();
    exit(EXIT_SUCCESS);
  }

  if (detachflag) {
    pid_t pid;

    if ((pid = fork()) != 0)
      exit(EXIT_SUCCESS);

    setsid();

    signal(SIGHUP, SIG_IGN);

    if ((pid = fork()) != 0)
      exit(EXIT_SUCCESS);

    /* chdir? */

    /* umask? */

    /* close stdin etc? */

    /* fix up logging? */
  }

  /*
   *  Prevent SIGPIPE from killing us.  Seems that this can happen
   *  if we write to a TCP socket, the other end closes it and the
   *  timing is bad.
   */

  (void) signal(SIGPIPE, SIG_IGN);

  /*
   *  Compute the local GMT offset so we can have timestamps in
   *  our local time zone.
   */

  gmtdiff = 86400;
  tm = localtime(&gmtdiff);
  gmtdiff = tm->tm_hour * 3600 + tm->tm_min * 60;
  if (tm->tm_mday == 1) {
    gmtdiff -= 86400;
  }

  /*
   *  Start all defined objects.
   */

  for (obj = objlist; obj != NULL; obj = obj->obj_next) {
    start_obj(obj);
  }

  /*
   *  Start command handler on terminal if not prevented:
   */

  if (!nocmdhflag) {
    ret = pthread_create(&cmdhthread, NULL, do_terminal, NULL);
    if (ret != 0) {
      printx("Could not start the terminal handler thread\n");
    }
  }

  /* Finally, go do main timing for all of this. */

  do_timing();

  /* we should never get here, but keep the compiler happy: */

  return 0;
}
