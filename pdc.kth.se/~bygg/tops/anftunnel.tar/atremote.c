/*
   Copyright (c) 2017-2018, Johnny Eriksson
   All rights reserved.

   Redistribution and use in source and binary forms, with or without
   modification, are permitted provided that the following conditions
   are met:

   1. Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

   2. Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in the
      documentation and/or other materials provided with the distribution.

   THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
   "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
   LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
   FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
   COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
   INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
   BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
   OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
   AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
   OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
   THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH
   DAMAGE.
*/

/*
 *  Remote "telnet" for anftunnel, with crypto.
 */

#include <ctype.h>
#include <stdarg.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <errno.h>
#include <limits.h>
#include <setjmp.h>
#include <signal.h>
#include <time.h>

#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/select.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include <pthread.h>

#include "prng.h"

/*
 *  Our variables:
 */

u_short port = 6016;		/* Remote port. */
char*   remote = "127.0.0.1";	/* Remote IP address.*/
char*   key = NULL;		/* Auth. key. */
char*   programname;		/* What we stared as. */

pthread_t netreader;		/* Thread for reading from network. */

int     netsock;		/* Network socket. */

prng*   rxprng;
prng*   txprng;

jmp_buf stop_auth;

/*
 *  Open network connection, possibly doing auth.  Exit if we fail.
 */

void open_network(void)
{
  struct sockaddr_in rem_addr;

  netsock = socket(AF_INET, SOCK_STREAM, 0);
  if (netsock < 0) {
    fprintf(stderr, "socket() failed, errno = %d (%s)\n",
	    errno, strerror(errno));
    exit(1);
  }

  bzero(&rem_addr, sizeof(struct sockaddr_in));
  rem_addr.sin_family = AF_INET;
  rem_addr.sin_addr.s_addr = inet_addr(remote);
  rem_addr.sin_port = htons(port);

  if (connect(netsock, (struct sockaddr*) &rem_addr,
	      sizeof(struct sockaddr)) < 0) {
    fprintf(stderr, "Connect failed, errno = %d (%s)\n",
	    errno, strerror(errno));
    exit(1);
  }
}

/*
 *  Do authentication on a network connection:
 */

void tmohandler(int unused)
{
  longjmp(stop_auth, 1);
}

void do_auth(void)
{
  u_char rxsalt[SALTSIZE];
  u_char txsalt[SALTSIZE];
  u_char buffer[SALTSIZE];
  int i;

  if (key == NULL)
    return;

  if (setjmp(stop_auth))
    goto fail;			/* Timeout. */

  (void) signal(SIGALRM, tmohandler);
  (void) alarm(5);

  prng_random(rxsalt, SALTSIZE);

  i = send(netsock, rxsalt, SALTSIZE, 0);
  if (i != SALTSIZE)
    goto fail;

  i = recv(netsock, txsalt, SALTSIZE, 0);
  if (i != SALTSIZE)
    goto fail;

  if (memcmp(rxsalt, txsalt, SALTSIZE) == 0)
    goto fail;
  
  rxprng = prng_init(rxsalt, key);
  txprng = prng_init(txsalt, key);

  for (i = 0; i < SALTSIZE; i += 1) {
    buffer[i] = prng_getbyte(txprng);
  }

  if ((i = send(netsock, buffer, SALTSIZE, 0)) != SALTSIZE)
    goto fail;

  if ((i = recv(netsock, buffer, SALTSIZE, 0)) != SALTSIZE)
    goto fail;

  for (i = 0; i < SALTSIZE; i += 1) {
    if (buffer[i] != prng_getbyte(rxprng))
      goto fail;
  }

  (void) alarm(0);
  return;

 fail:
  (void) alarm(0);
  fprintf(stderr, "authentication failed.\n");
  exit(1);
}

/*
 *  Read from network, printing data to terminal.
 */

void* do_network(void* arg)
{
  char buf[1024];
  int ret;
  int i;
  char c;

  for (;;) {
    ret = recv(netsock, buf, sizeof(buf), 0);
    if (ret == 0) {
      printf("Connection reset.\n");
      exit(0);
    }

    if (ret <= 0) {
      switch (errno) {
      case EAGAIN:
      case EINTR:
	break;
      default:
	perror("recv");
	close(netsock);
	return NULL;
      }
    } else {
      if (key != NULL)
	prng_encrypt(rxprng, (u_char*) buf, ret);

      for (i = 0; i < ret; i += 1) {
	c = buf[i];
	if (isprint(c) || c == '\n') {
	  putchar(c);
	} else {
	  putchar('.');
	}
      }
      fflush(stdout);
    }
  }
}

/*
 *  Read line-by-line from terminal, send to network.
 */

void do_terminal(void)
{
  char buf[1024];
  char* ret;

  for (;;) {
    ret = fgets(buf, sizeof(buf), stdin);
    if (ret == NULL) {
      printf("\nQuitting...\n");
      return;
    }
    if (key != NULL)
      prng_encrypt(txprng, (u_char*) buf, strlen(buf));

    if (send(netsock, buf, strlen(buf), 0) < 0) {
      perror("send");
    }
  }
}

/*
 *  Print our version information.
 */

void prvers(void)
{
  #include "hgedit.h"
  #include "hghash.h"

  printf("atremote 1.0, edit %s, commit id %s\n", hgedit, hghash);

  exit(EXIT_SUCCESS);
}

/*
 *  Print usage information.
 */

void usage(int shortflag)
{
  if (shortflag) {
    fprintf(stderr, "Type %s -h for help.\n", programname);
    exit(EXIT_FAILURE);
  }

  printf("usage: %s [options]\n", programname);
  printf(
"\n"
"   -h        Give this help\n"
"   -k <key>  Set encrypt/auth key\n"
"   -p <port> Set port number\n"
"   -r <addr> Set remote address\n"
"   -v        print version number\n"
"\n"
	 );
  exit(EXIT_SUCCESS);
}

/*
 *  Main program, command handling.
 */

int main(int argc, char* argv[])
{
  int ch;

  programname = argv[0];        /* Keep for later. */

  while ((ch = getopt(argc, argv, "hk:p:r:v")) != -1) {
    switch (ch) {
    case 'h':			/* Give help. */
      usage(0);
      break;
    case 'k':			/* Set key. */
      key = optarg;
      break;
    case 'p':			/* Set port. */
      port = atoi(optarg);
      break;
    case 'r':			/* Set remote addr. */
      remote = optarg;
      break;
    case 'v':
      prvers();
      break;
    default:
      usage(1);
      break;
    }
  }

  argc -= optind;
  argv += optind;

  if (argc > 0)
    remote = argv[0];

  /*
   *  Do work here.
   */

  if (key != NULL)
    printf("  key = '%s'\n", key);
  printf("  remote = %s:%d\n", remote, port);

  open_network();

  do_auth();

  if (pthread_create(&netreader, NULL, do_network, NULL) != 0) {
    perror("pthread_create");
    exit(1);
  }

  do_terminal();

  return 0;
}
