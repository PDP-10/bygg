#!/bin/sh

echo static char* hgedit=\"`hg id -n`\"\; > hgedit.h
echo static char* hghash=\"`hg id -i`\"\; > hghash.h
