/*
   Copyright (c) 2015-2017, Johnny Eriksson
   All rights reserved.

   Redistribution and use in source and binary forms, with or without
   modification, are permitted provided that the following conditions
   are met:

   1. Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

   2. Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in the
      documentation and/or other materials provided with the distribution.

   THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
   "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
   LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
   FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
   COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
   INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
   BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
   OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
   AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
   OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
   THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH
   DAMAGE.
*/

/*
   This code implements the prng routines used to do the crypto.

   Currently this uses the alleged RC4, even if it is supposed to be
   more or less broken.  If you want to, change  it to something else,
   all code outside of this module just wants a prng with the given
   semantics.
*/

#include "prng.h"

#include <fcntl.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <pthread.h>

struct prng {
  u_char* s;
  u_char i;
  u_char j;
};

pthread_mutex_t prnglock = PTHREAD_MUTEX_INITIALIZER;

static prng* rnd = NULL;

/*
 *  Return count bytes of randomness into buf.
 */

void prng_random(u_char* buf, int count)
{
  int fd;
  u_char salt[SALTSIZE];

  (void) pthread_mutex_lock(&prnglock);

  if (rnd == NULL) {
    if ((fd = open("/dev/random", O_RDONLY)) >= 0) {
      if (read(fd, salt, SALTSIZE) != SALTSIZE) {
	/* failure.  How do we give up? */
      }
      /* failure.  How do we give up? */
    }
    rnd = prng_init(salt, "");
  }

  while (count-- > 0) {
    *buf++ = prng_getbyte(rnd);
  }
  (void) pthread_mutex_unlock(&prnglock);
}

/*
 *  Allocate and init a prng, return pointer do data block.
 */

prng* prng_init(u_char* salt, char* key)
{
  prng* p;
  int n, i;
  u_char si;
  u_char fullkey[256];
  int keylen = strlen(key);

  p = malloc(sizeof(struct prng));
  p->s = malloc(256);

  i = 0;
  for (;;) {
    for (n = 0; n < SALTSIZE; n += 1) {
      fullkey[i++] = salt[n];
      if (i >= 256)
	goto done;
    }
    for (n = 0; n < keylen; n += 1) {
      fullkey[i++] = key[n];
      if (i >= 256)
	goto done;
    }
  }    

 done:

  for (n = 0; n < 256; n += 1) {
    p->s[n] = n;
  }
  p->i = 0;
  p->j = 0;

  i = 0;

  for (n = 0; n < 256; n += 1) {
    i = (i + p->s[n] + fullkey[n]) & 0xff;
    si = p->s[i];
    p->s[i] = p->s[n];
    p->s[n] = si;
  }

  prng_skip(p, 256);
  prng_skip(p, prng_getbyte(p));
  prng_skip(p, prng_getbyte(p));
  prng_skip(p, prng_getbyte(p));
  prng_skip(p, prng_getbyte(p));

  return p;
}

/*
 *  Release the memory used by a prng instance.
 */

void prng_free(prng* p)
{
  if (p != NULL) {
    free(p->s);
    free(p);
  }
}

/*
 *  Get one byte from a prng.
 */

u_char prng_getbyte(prng* p)
{
  u_char si, sj;

  p->i = (p->i + 1);
  si = p->s[p->i];
  p->j = (p->j + si);
  sj = p->s[p->j];
  p->s[p->i] = sj;
  p->s[p->j] = si;
  return (p->s[(si + sj) & 0xff]);
}

/*
 *  Skip count bytes from a prng.
 */

void prng_skip(prng* p, int count)
{
  while (count-- > 0) {
    (void) prng_getbyte(p);
  }
}

/*
 *  Encrypt (or decrypt) count bytes from the buffer.
 */

void prng_encrypt(prng* p, u_char* buf, int count)
{
  while (count-- > 0) {
    *buf++ ^= prng_getbyte(p);
  }
}
