Code-Red-Analysis.txt - Analysis of the worm by eEye Digital Security.
Code-Red-Disassembly-IDA.idb - IDA (Interactive Disassembler) database file.
Code-Red-Worm-Disassembly.txt - Text dump of IDA database (disassembly of worm+comments)

Signed,
eEye Digital Security
http://eEye.com/Retina - Network Security Scanner
http://eEye.com/Iris - Network Traffic Analyzer
http://eEye.com/SecureIIS - Stop known and unknown IIS vulnerabilities