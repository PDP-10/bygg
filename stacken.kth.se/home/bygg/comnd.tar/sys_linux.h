/*
** System dependent code for comnd, linux version.
*/

/*
** Just use the posix version.
*/

#include "sys_posix.h"
