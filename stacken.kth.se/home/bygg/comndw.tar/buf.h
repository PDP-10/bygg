/* routines in buf.c: */

extern void bufxset(int flag);
extern void bufchar(char c);
extern void bufstring(char* txt);
extern void bufnumber(int number);
extern void bufhex(int number, int n);
extern void bufnewline(void);
