#include "comnd.h"

#include <sys/types.h>
#include <sys/file.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdio.h>
#include <errno.h>
#include <stdlib.h>

static bool done;

static void com_cd(void);
static void com_delete(void);
static void com_help(void);
static void com_list(void);
static void com_pwd(void);
static void com_quit(void);
static void com_rename(void);
static void com_stat(void);
static void com_view(void);

static cmkeyword cmds[] = {
  { "cd",     0, 0, com_cd,     "Change to directory DIR" },
  { "delete", 0, 0, com_delete, "Delete FILE" },
  { "exit",   KEY_INV, 0, com_quit },
  { "help",   0, 0, com_help,   "Display this text" },
  { "list",   0, 0, com_list,   "List files in DIR" },
  { "ls",     0, 0, com_list,   "Synonym for `list'" },
  { "pwd",    0, 0, com_pwd,    "Print the current working directory" },
  { "quit",   0, 0, com_quit,   "Quit using Fileman" },
  { "rename", 0, 0, com_rename, "Rename FILE to NEWNAME" },
  { "stat",   0, 0, com_stat,   "Print out statistics on FILE" },
  { "view",   0, 0, com_view,   "View the contents of FILE" },
  { NULL },
};

int main(int argc, char* argv[])
{
  done = false;

  while (!done) {
    cm_prompt("Fileman: ");
    cm_pcmd("Command, ", 0, cmds, KT_MWL);
  }
  return 0;
}

void notyet(void)
{
  printf("Sorry, not yet implemented.\n");
}

void com_cd(void)
{
  cm_confirm();
  notyet();
}

void com_delete(void)
{
  cm_confirm();
  notyet();
}

void com_help(void)
{
  cm_confirm();
  notyet();
}

void com_list(void)
{
  char* arg;
  char syscom[1024];

  cm_parse(cm_chain(cm_fdb(_CMCFM, "confirm to list all files", 0, NULL),
		    cm_fdb(_CMFIL, "file spec to list", 0, NULL),
		    NULL));
  if (pval.used->function == _CMCFM) {
    arg = "";
  } else {
    arg = atombuffer;
    cm_confirm();
  }

  sprintf(syscom, "ls -FClg %s", arg);
  (void) system(syscom);
}

void com_pwd(void)
{
  char dir[1024];
  char* s;

  s = getcwd(dir, sizeof(dir) - 1);
  if (s == 0) {
    printf("Error getting wd: %s\n", dir);
    return;
  }
  printf("Current directory is %s\n", dir);
}

void com_quit(void)
{
  cm_confirm();
  done = true;
}

void com_rename(void)
{
  cm_confirm();
  notyet();
}

void com_stat(void)
{
  struct stat finfo;
  char* arg;

  cm_pfil("file name to stat", 0);
  arg = atombuffer;

  cm_confirm();

  if (stat(arg, &finfo) == -1) {
    perror(arg);
    return;
  }

  printf ("Statistics for `%s':\n", arg);
  printf ("%s has %d link%s, and is %d byte%s in length.\n",
	  arg,
          finfo.st_nlink,
          (finfo.st_nlink == 1) ? "" : "s",
          (int) finfo.st_size,
          (finfo.st_size == 1) ? "" : "s");
  printf ("Inode Last Change at: %s", ctime (&finfo.st_ctime));
  printf ("      Last access at: %s", ctime (&finfo.st_atime));
  printf ("    Last modified at: %s", ctime (&finfo.st_mtime));
}

void com_view(void)
{
  char* arg;
  char syscom[1024];
  
  cm_pfil("file to view", 0);
  arg = atombuffer;

  cm_confirm();

  sprintf(syscom, "more %s", arg);
  system(syscom);
}
