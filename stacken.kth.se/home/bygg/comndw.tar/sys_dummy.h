/*
** System dependent code for comnd, dummy version.
*/

#error "the system dependent code is missing for this system."
