/*
** System dependent code for comnd, solaris version.
*/

/*
** Just use the posix version.
*/

#include "sys_posix.h"
