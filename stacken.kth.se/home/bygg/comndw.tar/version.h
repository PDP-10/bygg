/* -*- Text -*- mode, please! */

/* Edit history and version number for comnd: */



0.17	- Start version numbering at an arbtrary number (17).
	2004-07-05 22:16
