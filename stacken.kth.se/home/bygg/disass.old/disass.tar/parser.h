/* routines in parser.c: */

extern void toploop(void);
extern void bug(char* routine, char* message);
extern void notyeterror(void);

extern struct entryvector* findproc(char* name);
