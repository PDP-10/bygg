/* routines in rpn.c: */

extern void rpn(void);
extern longword rpn_rstack(int pos);
