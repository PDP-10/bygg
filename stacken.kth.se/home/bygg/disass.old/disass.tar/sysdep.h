/* routines in sysdep.c: */

extern char*  sy_getenv(char* variable);
extern void   sy_setenv(char* variable, char* value);
extern void   sy_environment(void);
