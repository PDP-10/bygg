/*
 *  This is the main starting point for the grand disassembler.
 *  We don't do much here except handle the eventual command line
 *  arguments and dispatching to the main interactive command
 *  handler.
 */

#include "disass.h"
#include <unistd.h>

static void usage(char* progname, bool errflag)
{
  if (errflag) {
    printf("   try %s -h for help.\n", progname);
    return;
  }

  printf("Usage: %s [options]\n\n", progname);

  printf("\
Options:\n\
\n\
   -d          Turn on debug flag.\n\
   -h          Give this help.\n\
   -v          Turn on verbose flag.\n\
\n\
   -E          Exit after doing all options.\n\
   -I          Inhibit exit, go interactive.\n\
   -M module   Load driver module.\n\
   -P cpu      Set cpu type.\n\
   -R file     Read file.\n\
   -S file     Read save file.\n\
   -W file     Write file.\n\
\n\
");
}

/*
 *  The following constants should be defined centrally.
 */

enum {
  fmt_unknown,

  fmt_binary,
  fmt_elf,
  fmt_hex,
  fmt_motorola,
  fmt_tek,
  fmt_save,
};

struct {
  char* name;
  int fmt;
} fmtnames[] = {
  { "bin",   fmt_binary },
  { "elf",   fmt_elf },
  { "hex",   fmt_hex },
  { "mot",   fmt_motorola },
  { "sav",   fmt_save },
  { "tek",   fmt_tek },
  { NULL,    0 },
};

static char* argsplit(int* fmt, char* arg)
{
  char* split;
  int i;

  split = strchr(arg, ':');
  if (split == NULL)
    return arg;

  *split++ = (char) 0;

  for (i = 0; fmtnames[i].name != NULL; i += 1) {
    if (strcmp(arg, fmtnames[i].name) == 0) {
      *fmt = fmtnames[i].fmt;
      goto found;
    }
  }

  printf("File format %s unknown.\n", arg);
  *fmt = fmt_unknown;

 found:
  return split;
}

void cl_read(char* arg)
{
  int fmt;
  char* filename;

  fmt = fmt_binary;
  filename = argsplit(&fmt, arg);

  switch (fmt) {
  case fmt_unknown:
    /* handled by argsplit */
    break;
  case fmt_binary:
    (void) load_binary(filename, a_zero(), 0, 0);
    break;
  case fmt_elf:
    (void) load_elf(filename);
    break;
  case fmt_hex:
    (void) load_intel(filename);
    break;
  case fmt_motorola:
    (void) load_motorola(filename);
    break;
  case fmt_save:
    m_restore(filename);
    break;
  default:
    printf("Can't read files in %s format.\n", arg);
    break;
  }
}

void cl_write(char* arg)
{
  int fmt;
  char* filename;

  fmt = fmt_binary;
  filename = argsplit(&fmt, arg);

  switch (fmt) {
  case fmt_unknown:
    /* handled by argsplit */
    break;
  case fmt_binary:
    (void) write_binary(filename, NULL);
    break;
  case fmt_hex:
    (void) write_intel(filename, NULL);
    break;
  case fmt_motorola:
    (void) write_motorola(filename, NULL);
    break;
  case fmt_save:
    m_save(filename);
    break;
  default:
    printf("Can't write files in %s format.\n", arg);
    break;
  }
}

int main(int argc, char* argv[])
{
  char c;
  char opts[] = "dhvEIM:P:R:S:W:";
  bool exflag = false;

  while ((c = getopt(argc, argv, opts)) != -1) {
    switch (c) {
    case '?':
      usage(argv[0], true);
      exit(EXIT_FAILURE);
    case 'd':
      debugflag = true;
      break;
    case 'h':
      usage(argv[0], false);
      exit(EXIT_SUCCESS);
    case 'v':
      verboseflag = true;
      break;
    case 'E':
    case 'I':
    case 'M':
    case 'P':
    case 'R':
    case 'S':
      /* Ignore these second-pass options here. */
      break;
    case 'W':
      exflag = true;
      break;
    default:
      /* Internal error in program. */
      break;
    }
  }

  sy_environment();		/* Check out the surrounding area. */

  buftop();			/* Init buffer.c */
  m_init();			/* Init memory.c */
  md_init();			/* Init module.c */

  optind = 1;			/* Reset for second pass. */

  while ((c = getopt(argc, argv, opts)) != -1) {
    switch (c) {
    case 'E':
      exflag = true;
      break;
    case 'I':
      exflag = false;
      break;
    case 'M':
      md_load(optarg);
      break;
    case 'P':
      proc_select(optarg);
      break;
    case 'R':
      cl_read(optarg);
      break;
    case 'S':
      m_restore(optarg);
      break;
    case 'W':
      cl_write(optarg);
      break;
    }
  }

  if (exflag)
    exit(EXIT_SUCCESS);

  commandloop();		/* Call the main program. */

  return 0;			/* Dummy, we never get here. */
}

/* end of file */
