/*
 *  Floating point tables.
 */

/*   D8, first:
 *
 *  0000  fadd  real32
 *  0010  fmul  real32
 *  0020  fcom  real32
 *  0030  fcomp real32
 *  0040  fsub  real32
 *  0050  fsubr real32
 *  0060  fdiv  real32
 *  0070  fdivr real32
 *
 *   D8, second:
 *
 *  c0-c7 fadd  st,st(n)
 *  c8-cf fmul  st,st(n)
 *  d0-d7 fcom  st,st(n)
 *  d8-df fcomp st,st(n)
 *  e0-e7 fsub  st,st(n)
 *  e8-ef fsubr st,st(n)
 *  f0-f7 fdiv  st,st(n)
 *  f8-ff fdivr st,st(n)
 */

static dispblock fltD8disp[16] = {
  { 0000, 0, inst,   0,        "fadd %e" }, /* real32 */
  { 0010, 0, inst,   0,        "fmul %e" }, /* real32 */
  { 0020, 0, inst,   0,        "fcom %e" }, /* real32 */
  { 0030, 0, inst,   0,        "fcomp %e" }, /* real32 */
  { 0040, 0, inst,   0,        "fsub %e" }, /* real32 */
  { 0050, 0, inst,   0,        "fsubr %e" }, /* real32 */
  { 0060, 0, inst,   0,        "fdiv %e" }, /* real32 */
  { 0070, 0, inst,   0,        "fdivr %e" }, /* real32 */
  { 0xc0, 0, inst,   0,        "fadd st,st(#)" },
  { 0xc8, 0, inst,   0,        "fmul st,st(#)" },
  { 0xd0, 0, inst,   0,        "fcom st,st(#)" },
  { 0xd8, 0, inst,   0,        "fcomp st,st(#)" },
  { 0xe0, 0, inst,   0,        "fsub st,st(#)" },
  { 0xe8, 0, inst,   0,        "fsubr st,st(#)" },
  { 0xf0, 0, inst,   0,        "fdiv st,st(#)" },
  { 0xf8, 0, inst,   0,        "fdivr st,st(#)" },
};

/*   D9, first:
 *
 *  0000  fld   real32
 *  0010  --illeagal
 *  0020  fst   real32
 *  0030  fstp  real32
 *  0040  fldenv ...
 *  0050  fldcw 2-bytes
 *  0060  fstenv ...
 *  0070  fstcw 2-bytes
 *
 *   D9, second:
 *
 *  c0-c7 fld   st,st(n)
 *  c8-cf fxch  st,st(n)
 *  d0-d7 { fnop, 0, 0, 0, 0, 0, 0, 0 }
 *  d8-df { 0, 0, 0, 0, 0, 0, 0, 0 }
 *  e0-e7 { fchs, fabs, 0, 0, ftst, fxam, 0, 0 }
 *  e8-ef { fld1, fld2t, fld2e, fldpi, fldlg2, fldln2, fldz, 0 }
 *  f0-f7 { f2xm1, fyl2x, fptan, fpatan, fxtract, fprem1, fdescstp, fincstp }
 *  f8-ff { fprem, fyl2xp1, fsqrt, fsincos, frndint, fscale, fsin, fcos }
 */

static dispblock fltD9D0disp[8] = {
  { 0xd0, 0, inst,   0,        "fnop" },
  { 0xd1, 0, unused },
  { 0xd2, 0, unused },
  { 0xd3, 0, unused },
  { 0xd4, 0, unused },
  { 0xd5, 0, unused },
  { 0xd6, 0, unused },
  { 0xd7, 0, unused },
};

static dispblock fltD9E0disp[8] = {
  { 0xe0, 0, inst,   0,        "fchs" },
  { 0xe1, 0, inst,   0,        "fabs" },
  { 0xe2, 0, unused },
  { 0xe3, 0, unused },
  { 0xe4, 0, inst,   0,        "ftst" },
  { 0xe5, 0, inst,   0,        "fxam" },
  { 0xe6, 0, unused },
  { 0xe7, 0, unused },
};

static dispblock fltD9E8disp[8] = {
  { 0xe8, 0, inst,   0,        "fld1" },
  { 0xe9, 0, inst,   0,        "fld2t" },
  { 0xea, 0, inst,   0,        "fld2e" },
  { 0xeb, 0, inst,   0,        "fldpi" },
  { 0xec, 0, inst,   0,        "fldlg2" },
  { 0xed, 0, inst,   0,        "fldln2" },
  { 0xee, 0, inst,   0,        "fldz" },
  { 0xef, 0, unused },
};

static dispblock fltD9F0disp[8] = {
  { 0xf0, 0, inst,   0,        "f2xm1" },
  { 0xf1, 0, inst,   0,        "fyl2x" },
  { 0xf2, 0, inst,   0,        "fptan" },
  { 0xf3, 0, inst,   0,        "fpatan" },
  { 0xf4, 0, inst,   0,        "fxtract" },
  { 0xf5, 0, inst,   0,        "fprem1" },
  { 0xf6, 0, inst,   0,        "fdecstp" },
  { 0xf7, 0, inst,   0,        "fincstp" },
};

static dispblock fltD9F8disp[8] = {
  { 0xf8, 0, inst,   0,        "fprem" },
  { 0xf9, 0, inst,   0,        "fyl2xp1" },
  { 0xfa, 0, inst,   0,        "fsqrt" },
  { 0xfb, 0, inst,   0,        "fsincos" },
  { 0xfc, 0, inst,   0,        "frndint" },
  { 0xfd, 0, inst,   0,        "fscale" },
  { 0xfe, 0, inst,   0,        "fsin" },
  { 0xff, 0, inst,   0,        "fcos" },
};

static dispblock fltD9disp[16] = {
  { 0000, 0, inst,   0,        "fld %e" }, /* real32 */
  { 0010, 0, unused, 0,        0 },
  { 0020, 0, inst,   0,        "fst %e" }, /* real32 */
  { 0030, 0, inst,   0,        "fstp %e" }, /* real32 */
  { 0040, 0, inst,   0,        "fldenv %e" }, /* ... */
  { 0050, 0, inst,   0,        "fldcw %e" }, /* 2-bytes */
  { 0060, 0, inst,   0,        "fstenv %e" }, /* ... */
  { 0070, 0, inst,   0,        "fstcw %e" }, /* 2-bytes */
  { 0xc0, 0, inst,   0,        "fld st,st(#)" },
  { 0xc8, 0, inst,   0,        "fxch st,st(#)" },
  { 0xd0, 0, splitf, 0,        fltD9D0disp },
  { 0xd8, 0, unused, 0         0 },
  { 0xe0, 0, splitf, 0,        fltD9E0disp },
  { 0xe8, 0, splitf, 0,        fltD9E8disp },
  { 0xf0, 0, splitf, 0,        fltD9F0disp },
  { 0xf8, 0, splitf, 0,        fltD9F8disp },
};

/*   DA, first:
 *
 *  0000  fiadd  int32
 *  0010  fimul  int32
 *  0020  ficom  int32
 *  0030  ficomp int32
 *  0040  fisub  int32
 *  0050  fisubr int32
 *  0060  fidiv  int32
 *  0070  fidivr int32
 *
 *   DA, second:
 *
 *  c0-c7 fcmovb  st,st(n)
 *  c8-cf fcmove  st,st(n)
 *  d0-d7 fcmovbe st,st(n)
 *  d8-df fcmovu  st,st(n)
 *  e0-e7 { 0, 0, 0, 0, 0, 0, 0, 0 }
 *  e8-ef { 0, fucompp, 0, 0, 0, 0, 0, 0 }
 *  f0-f7 { 0, 0, 0, 0, 0, 0, 0, 0 }
 *  f8-ff { 0, 0, 0, 0, 0, 0, 0, 0 }
 */

static dispblock fltDAE8disp[8] = {
  { 0xe8, 0, unused },
  { 0xe9, 0, inst,   0,        "fucompp" },
  { 0xea, 0, unused },
  { 0xeb, 0, unused },
  { 0xec, 0, unused },
  { 0xed, 0, unused },
  { 0xee, 0, unused },
  { 0xef, 0, unused },
};

static dispblock fltDAdisp[16] = {
  { 0000, 0, inst,   0,        "fiadd %e" }, /* int32 */
  { 0010, 0, inst,   0,        "fimul %e" }, /* int32 */
  { 0020, 0, inst,   0,        "ficom %e" }, /* int32 */
  { 0030, 0, inst,   0,        "ficomp %e" }, /* int32 */
  { 0040, 0, inst,   0,        "fisub %e" }, /* int32 */
  { 0050, 0, inst,   0,        "fisubr %e" }, /* int32 */
  { 0060, 0, inst,   0,        "fidiv %e" }, /* int32 */
  { 0070, 0, inst,   0,        "fidivr %e" }, /* int32 */
  { 0xc0, 0, inst,   0,        "fcmovb st,st(#)" },
  { 0xc8, 0, inst,   0,        "fcmove st,st(#)" },
  { 0xd0, 0, inst,   0,        "fcmovbe st,st(#)" },
  { 0xd8, 0, inst,   0,        "fcmovu st,st(#)" },
  { 0xe0, 0, unused },
  { 0xe8, 0, splitf, 0,        fltDAE8disp },
  { 0xf0, 0, unused },
  { 0xf8, 0, unused },
};

/*   DB, first:
 *
 *  0000  fild   int32
 *  0010  fisttp int32
 *  0020  fist   int32
 *  0030  fistp  int32
 *  0040
 *  0050  fld    xreal
 *  0060
 *  0070  fstp   xreal
 *
 *   DB, second:
 *
 *  c0-c7 fcmovnb st,st(n)
 *  c8-cf fcmovne st,st(n)
 *  d0-d7 fcmovnbe st,st(n)
 *  d8-df fcmovnu st,st(n)
 *  e0-e7 { 0, 0, fclex, finit, 0, 0, 0, 0 }
 *  e8-ef fucomi  st,st(n)
 *  f0-f7 fcomi   st,st(n)
 *  f8-ff
 */

static dispblock fltDBE0disp[8] = {
  { 0xe0, 0, unused },
  { 0xe1, 0, unused },
  { 0xe2, 0, inst,   0,        "fclex" },
  { 0xe3, 0, inst,   0,        "finit" },
  { 0xe4, 0, unused },
  { 0xe5, 0, unused },
  { 0xe6, 0, unused },
  { 0xe7, 0, unused },
};

static dispblock fltDBdisp[16] = {
  { 0000, 0, inst,   0,        "fild %e" }, /* int32 */
  { 0010, 0, inst,   0,        "fisttp %e" }, /* int32 */
  { 0020, 0, inst,   0,        "fist %e" }, /* int32 */
  { 0030, 0, inst,   0,        "fistp %e" }, /* int32 */
  { 0040, 0, unused },
  { 0050, 0, inst,   0,        "fld %e" }, /* xreal */
  { 0060, 0, unused },
  { 0070, 0, inst,   0,        "fstp %e" }, /* xreal */
  { 0xc0, 0, inst,   0,        "fcmovnb st,st(#)" },
  { 0xc8, 0, inst,   0,        "fcmovne st,st(#)" },
  { 0xd0, 0, inst,   0,        "fcmovnbe st,st(#)" },
  { 0xd8, 0, inst,   0,        "fcmovnu st,st(#)" },
  { 0xe0, 0, splitf, 0,        fltDBE0disp },
  { 0xe8, 0, inst,   0,        "fucomi st,st(#)" },
  { 0xf0, 0, inst,   0,        "fcomi st,st(#)" },
  { 0xf8, 0, unused },
};

/*   DC, first:
 *
 *  0000   fadd   real64
 *  0010   fmul   real64
 *  0020   fcom   real64
 *  0030   fcomp  real64
 *  0040   fsub   real64
 *  0050   fsubr  real64
 *  0060   fdiv   real64
 *  0070   fdivr  real64
 *
 *   DC, second:
 *
 *  c0-c7  fadd   st(n),st
 *  c8-cf  fmul   st(n),st
 *  d0-d7
 *  d8-df
 *  e0-e7  fsubr  st(n),st
 *  e8-ef  fsub   st(n),st
 *  f0-f7  fdivr  st(n),st
 *  f8-ff  fdiv   st(n),st
 */

static dispblock fltDCdisp[16] = {
  { 0000, 0, inst,   0,        "fadd %e" }, /* real64 */
  { 0010, 0, inst,   0,        "fmul %e" }, /* real64 */
  { 0020, 0, inst,   0,        "fcom %e" }, /* real64 */
  { 0030, 0, inst,   0,        "fcomp %e" }, /* real64 */
  { 0040, 0, inst,   0,        "fsub %e" }, /* real64 */
  { 0050, 0, inst,   0,        "fsubr %e" }, /* real64 */
  { 0060, 0, inst,   0,        "fdiv %e" }, /* real64 */
  { 0070, 0, inst,   0,        "fdivr %e" }, /* real64 */

  { 0xc0, 0, inst,   0,        "fadd st(#),st" },
  { 0xc8, 0, inst,   0,        "fmul st(#),st" },
  { 0xd0, 0, unused },
  { 0xd8, 0, unused },
  { 0xe0, 0, inst,   0,        "fsub st(#),st" },
  { 0xe8, 0, inst,   0,        "fsubr st(#),st" },
  { 0xf0, 0, inst,   0,        "fdiv st(#),st" },
  { 0xf8, 0, inst,   0,        "fdivr st(#),st" },
};

/*   DD, first:
 *
 *  0000   fld    real64
 *  0010   fisttp int64
 *  0020   fst    real64
 *  0030   fstp   real64
 *  0040   frstor <block>
 *  0050
 *  0060   fsave  <block>     ;; fsave/fnsave sigh...
 *  0070   fstsw  2-bytes
 *
 *   DD, second:
 *
 *  c0-c7  ffree  st(n)
 *  c8-cf
 *  d0-d7  fst    st(n)
 *  d8-df  fstp   st(n)
 *  e0-e7  fucom  st(n)
 *  e8-ef  fucomp st(n)
 *  f0-f7
 *  f8-ff
 */

static dispblock fltDDdisp[16] = {
  { 0000, 0, inst,   0,        "fld %e" }, /* real64 */
  { 0010, 0, inst,   0,        "fisttp %e" }, /* int64 */
  { 0020, 0, inst,   0,        "fst %e" }, /* real64 */
  { 0030, 0, inst,   0,        "fstp %e" }, /* real64 */
  { 0040, 0, inst,   0,        "frstor %e" }, /* <block> */
  { 0050, 0, unused },
  { 0060, 0, inst,   0,        "fsave %e" }, /* fnsave? */
  { 0070, 0, inst,   0,        "fstsw %e" }, /* 2-bytes */
  { 0xc0, 0, inst,   0,        "ffree st(#)" },
  { 0xc8, 0, unused },
  { 0xd0, 0, inst,   0,        "fst st(#)" },
  { 0xd8, 0, inst,   0,        "fstp st(#)" },
  { 0xe0, 0, inst,   0,        "fucom st(#)" },
  { 0xe8, 0, inst,   0,        "fucomp st(#)" },
  { 0xf0, 0, unused },
  { 0xf8, 0, unused },
};

/*   DE, first:
 *
 *  0000   fiadd  int16
 *  0010   fimul  int16
 *  0020   ficom  int16
 *  0030   ficomp int16
 *  0040   fisub  int16
 *  0050   fisubr int16
 *  0060   fidiv  int16
 *  0070   fidivr int16
 *
 *   DE, second:
 *
 *  c0-c7  faddp  st(n),st
 *  c8-cf  fmulp  st(n),st
 *  d0-d7
 *  d8-df  { 0, fcompp, 0, 0, 0, 0, 0, 0 }
 *  e0-e7  fsubrp st(n),st
 *  e8-ef  fsubp  st(n),st
 *  f0-f7  fdivrp st(n),st
 *  f8-ff  fdivp  st(n),st
 */

static dispblock fltDED8disp[8] = {
  { 0xd8, 0, unused },
  { 0xd9, 0, inst,   0,        "fcompp" },
  { 0xda, 0, unused },
  { 0xdb, 0, unused },
  { 0xdc, 0, unused },
  { 0xdd, 0, unused },
  { 0xde, 0, unused },
  { 0xdf, 0, unused },
};

static dispblock fltDEdisp[16] = {
  { 0000, 0, inst,   0,        "fiadd %e" }, /* int16 */
  { 0010, 0, inst,   0,        "fimul %e" }, /* int16 */
  { 0020, 0, inst,   0,        "ficom %e" }, /* int16 */
  { 0030, 0, inst,   0,        "ficomp %e" }, /* int16 */
  { 0040, 0, inst,   0,        "fisub %e" }, /* int16 */
  { 0050, 0, inst,   0,        "fisubr %e" }, /* int16 */
  { 0060, 0, inst,   0,        "fidiv %e" }, /* int16 */
  { 0070, 0, inst,   0,        "fidivr %e" }, /* int16 */
  { 0xc0, 0, inst,   0,        "faddp st(#),st" },
  { 0xc8, 0, inst,   0,        "fmulp st(#),st" },
  { 0xd0, 0, unused },
  { 0xd8, 0, splitf, 0,        fltDED8disp },
  { 0xe0, 0, inst,   0,        "fsubrp st(#),st" },
  { 0xe8, 0, inst,   0,        "fsubp st(#),st" },
  { 0xf0, 0, inst,   0,        "fdivrp st(#),st" },
  { 0xf8, 0, inst,   0,        "fdivp st(#),st" },
};

/*   DF, first:
 *
 *  0000   fild   int16
 *  0010   fisttp int16
 *  0020   fist   int16
 *  0030   fistp  int16
 *  0040   fbld   BCD
 *  0050   fild   int64
 *  0060   fbstp  BCD
 *  0070   fistp  int64
 *
 *   DF, second:
 *
 *  c0-c7
 *  c8-cf
 *  d0-d7
 *  d8-df
 *  e0-e7  { "fstsw $ax", 0, ... }
 *  e8-ef  fucomip st,st(n)
 *  f0-f7  fcomip  st,st(n)
 *  f8-ff
 */

static dispblock fltDFE0disp[8] = {
  { 0xe0, 0, inst,   0,        "fstsw $ax" },
  { 0xe1, 0, unused },
  { 0xe2, 0, unused },
  { 0xe3, 0, unused },
  { 0xe4, 0, unused },
  { 0xe5, 0, unused },
  { 0xe6, 0, unused },
  { 0xe7, 0, unused },
};

static dispblock fltDFdisp[16] = {
  { 0000, 0, inst,   0,        "fild %e" }, /* int16 */
  { 0010, 0, inst,   0,        "fisttp %e" }, /* int16 */
  { 0020, 0, inst,   0,        "fist %e" }, /* int16 */
  { 0030, 0, inst,   0,        "fistp %e" }, /* int16 */
  { 0040, 0, inst,   0,        "fbld %e" }, /* BCD */
  { 0050, 0, inst,   0,        "fild %e" }, /* int64 */
  { 0060, 0, inst,   0,        "fbstp %e" }, /* BCD */
  { 0070, 0, inst,   0,        "fistp %e" }, /* int64 */
  { 0xc0, 0, unused },
  { 0xc8, 0, unused },
  { 0xd0, 0, unused },
  { 0xd8, 0, unused },
  { 0xe0, 0, splitf, 0,        fltDFE0disp },
  { 0xe8, 0, inst,   0,        "fucomip st,st(#)" },
  { 0xf0, 0, inst,   0,        "fcomip st,st(#)" },
  { 0xf8, 0, unused },
};
