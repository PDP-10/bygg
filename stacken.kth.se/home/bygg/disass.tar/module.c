/*
 *  This module implements loadable CPU drivers for disass.
 */

#include "disass.h"

#include <dlfcn.h>

#include <sys/types.h>
#include <sys/stat.h>

/*
 *  Local data types needed:
 */

struct module {
  struct module* md_next;	/* Linked list.*/
  struct module* md_prev;

  char*          md_name;	/* Name as given to md_load(). */
  char*          md_file;	/* File we loaded from. */
  void*          md_handle;	/* Handle from md_load(). */
  struct driver* md_drvlist;	/* First driver we have. */
  struct driver* md_drvtail;	/* Last in list. */
};

struct driver {
  struct driver* dv_next;
  struct module* dv_module;
  struct entryvector* dv_vector;
};

/**********************************************************************/

/*
 *  Local variables:
 */

struct module* mdhead = NULL;
struct module* mdtail = NULL;
struct module* mdcurr = NULL;

static char* mdprefix[] = {
  "./",
  "/lib/disass/",
  "/usr/lib/disass/",
  "/usr/local/lib/disass/",
  NULL,
};

static int maxpfxlen;		/* Length of longest string above. */

/**********************************************************************/

/*
 *  Local routines:
 */

static struct module* md_lookup(char* name)
{
  struct module* md;

  for (md = mdhead; md != NULL; md = md->md_next) {
    if (strcmp(name, md->md_name) == 0)
      return md;
  }

  return NULL;
}

static struct module* md_create(char* name)
{
  struct module* md;

  md = malloc(sizeof(*md));
  /* XXX check for NULL here. */
  
  (void) memset(md, 0, sizeof(*md));

  md->md_name = copystring(name, NULL);

  md->md_prev = mdtail;
  md->md_next = NULL;
  if (mdtail != NULL) {
    mdtail->md_next = md;
    mdtail = md;
  } else {
    mdhead = md;
    mdtail = md;
  }
  return md;
}

static void md_destroy(struct module* md)
{
  struct driver* drv;

  if (md->md_prev != NULL)
    md->md_prev->md_next = md->md_next;
  else
    mdhead = md->md_next;

  if (md->md_next != NULL)
    md->md_next->md_prev = md->md_prev;
  else
    mdtail = md->md_prev;
  
  while (md->md_drvlist != NULL) {
    drv = md->md_drvlist;
    md->md_drvlist = drv->dv_next;
    proc_remove(drv->dv_vector);
    free(drv);
  }

  if (md->md_handle != NULL)
    dlclose(md->md_handle);

  free(md->md_name);
  free(md->md_file);
  free(md);
}

/**********************************************************************/

/*
 *  md_init() inits this module, and brings in the common
 *  well-known drivers.  There are no arguments.
 */

void md_init(void)
{
  int i, len;

  maxpfxlen = 0;

  for (i = 0; mdprefix[i] != NULL; i += 1) {
    len = strlen(mdprefix[i]);
    if (len > maxpfxlen)
      maxpfxlen = len;
  }

  /*
   *  Modules that should be loaded, in order:
   *
   *  i8051, i8086, m6502, m6800, m6805, m6809, m68k,
   *  mips, pdp11, vax, z8, z80.
   */
}

/*
 *  md_list() lists the currently loaded drivers.
 */

void md_list(void)
{
  struct module* md;
  struct driver* drv;

  if (mdhead == NULL) {
    bufstring("There are no modules loaded\n");
    return;
  }

  for (md = mdhead; md != NULL; md = md->md_next) {
    bufstring("Module ");
    bufstring(md->md_name);
    bufstring(" from file ");
    bufstring(md->md_file);
    bufnewline();
    for (drv = md->md_drvlist; drv != NULL; drv = drv->dv_next) {
      bufstring("   cpu ");
      bufstring(drv->dv_vector->name);
      tabto(16);
      bufstring(" -- ");
      bufstring(drv->dv_vector->descr);
      bufnewline();
    }
  }
}

/*
 *  md_load() loads a new driver.
 */

bool md_load(char* name)
{
  static char* mdsuff = ".drv";

  struct module* md;
  int i;
  void* handle;
  char* pathname;
  struct stat sb;

  if (debugflag) {
    bufstring("Module: md_load(\"");
    bufstring(name);
    bufstring("\")\n");
  }

  md = md_lookup(name);
  if (md != NULL) {
    bufstring("This module is already loaded.\n");
    return false;
  }

  pathname = malloc(maxpfxlen + strlen(name) + strlen(mdsuff) + 1);

  if (pathname == NULL) {
    bufstring("malloc() failure.\n");
    return false;
  }

  md = md_create(name);
  mdcurr = md;
  
  for (i = 0; mdprefix[i] != NULL; i += 1) {
    sprintf(pathname, "%s%s%s", mdprefix[i], name, mdsuff);
    if (stat(pathname, &sb) == 0)
      goto try;
  }

  bufstring("Can't find module ");
  bufstring(name);
  bufnewline();
  goto fail;

 try:

  (void) dlerror();
  handle = dlopen(pathname, RTLD_NOW);
  if (handle == NULL) {
    bufstring(dlerror());
    bufnewline();
    goto fail;
  }

  md->md_handle = handle;
  md->md_file = pathname;
  mdcurr = NULL;
  wc_module();
  return true;

 fail:

  free(pathname);
  md_destroy(md);
  mdcurr = NULL;
  return false;
}

/*
 *  md_reload() re-loads an existing driver.
 */

void md_reload(char* name)
{
  struct module* md = md_lookup(name);

  if (debugflag) {
    bufstring("Module: md_reload(\"");
    bufstring(name);
    bufstring("\")\n");
  }

  if (md == NULL) {
    /* this should not happen */
    bufstring("md_reload: not found\n");
    return;
  }

  md_destroy(md);
  md_load(name);
  wc_module();
}

/*
 *  md_unload() unloads an existing driver.
 */

void md_unload(char* name)
{
  struct module* md = md_lookup(name);

  if (md == NULL) {
    /* this should not happen */
    bufstring("md_unload: not found\n");
    return;
  }

  md_destroy(md);
  wc_module();
}

/*
 *  md_register() gets called from the newly loaded module once
 *  for every entryvector it wants to register.
 */

void md_register(struct entryvector* ev)
{
  struct driver* drv;

  if (mdcurr == NULL)
    return;			/* This is a bug. */

  drv = malloc(sizeof(*drv));
  if (drv == NULL)
    return;			/* Have to give up. */

  if (mdcurr->md_drvtail != NULL)
    mdcurr->md_drvtail->dv_next = drv;
  else
    mdcurr->md_drvlist = drv;

  mdcurr->md_drvtail = drv;
  drv->dv_next = NULL;
  drv->dv_module = mdcurr;
  drv->dv_vector = ev;

  proc_insert(ev);
}
