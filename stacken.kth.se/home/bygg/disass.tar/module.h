/* routines etc. in module.c: */

extern void md_init(void);
extern void md_list(void);
extern bool md_load(char* name);
extern void md_reload(char* name);
extern void md_unload(char* name);
extern void md_register(struct entryvector* ev);
