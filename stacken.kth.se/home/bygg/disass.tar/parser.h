/* routines in parser.c: */

extern void commandloop(void);
extern void bug(char* routine, char* message);
extern void notyeterror(void);

extern void proc_insert(struct entryvector* ev);
extern void proc_remove(struct entryvector* ev);
extern void proc_select(char* name);

extern void ls_processors(void);

/* variables: */

extern char* procname;
