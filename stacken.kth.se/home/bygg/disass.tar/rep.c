

static dispblock repdisp[] = {

  { 0x6c, 0, again,  0, ((dispblock []) {
    { 0x6c, 0, inst, PF3,   "rep insb" },
    { 0x6c, 0, inst, 0,     "insb" },
    { 0x00, 0, arnold, 0,        0 },
  })},

  /* 6c 6d 6e 6f  a4 a5 a6 a7  aa ab ac ad ae af */

  /*

  f3 6d        -- rep insw
  f3 6d        -- rep insl

  f3 6e        -- rep outsb
  f3 rex.w 6e  -- rep outsb [rdi]
  f3 6f        -- rep outsw
  f3 6f        -- rep outsl
  f3 rex.w 6f  -- rep outsq

  f3 a4        -- rep movsb
  f3 rex.w a4  -- rep movsb [rsi]
  f3 a5        -- rep movsw
  f3 a5        -- rep movsl
  f3 rex.w a5  -- rep movsq

  f3 a6        -- repe cmpsb
  f3 rex.w a6  -- repe cmpsb [rdi/rsi]
  f3 a7        -- repe cmpsw
  f3 a7        -- repe cmpsl
  f3 rex.w a7  -- repe cmpsq

  f3 aa        -- rep stosb
  f3 rex.w aa  -- rep stosb [rdi]
  f3 ab        -- rep stosw
  f3 ab        -- rep stosl
  f3 rex.w ab  -- rep stosq

  f3 ac        -- rep lodsb
  f3 rex.w ac  -- rep lodsb [rsi]
  f3 ad        -- rep lodsw
  f3 ad        -- rep lodsl
  f3 rex.w ad  -- rep lodsq

  f3 ae        -- repe scasb
  f3 rex.w ae  -- repe scasb [rdi]
  f3 af        -- repe scasw
  f3 af        -- repe scasl
  f3 rex.w af  -- repe scasq
		 
  f2 a6        -- repne cmpsb
  f2 rex.w a6  -- repne cmpsb [rdi/rsi]
  f2 a7        -- repne cmpsw
  f2 a7        -- repne cmpsl
  f2 rex.w a7  -- repne cmpsq

  f2 ae        -- repne scasb
  f2 rex.w ae  -- repne scasb [rdi]
  f2 af        -- repne scasw
  f2 af        -- repne scasl
  f2 rex.w af  -- repne scasq

  */

  { 0x00, 0, arnold, 0,        0 },
};
