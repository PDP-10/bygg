
#define NF_DEFAULT  0
#define NF_INTEL    1
#define NF_MOTOROLA 2
#define NF_UNIX     3


typedef void (evf_number)(longword, unsigned int);
typedef void (evf_defb)(byte);
typedef void (evf_defc)(byte);




evf_number* pf_number = dflt_number;
evf_defb*   pf_defb   = dflt_defb;
evf_defc*   pf_defc   = dflt_defc;



char* pvs_opdelim = " ";
char* pvs_byte = "defb";
char* pvs_word = "defw";
char* pvs_long = "defl";
char* pvs_char = "defb";
char* pvs_text = "defm";
char  pvc_delim = '"';



void stdnumber(longword n, unsigned int bits)
{
  longword sb;

  if (bits > 0 && argsign == SIGN_SIGNED) {
    if (n & (1 << (bits - 1))) {
      n = (1 << bits) - n;
      bufchar('-');
    }
  }

  /* handle according to radix & syntax */

}

void stddefb(byte b)
{
  pb_length = 1;
  pb_status = st_byte;		/* ??? */
  startline(true);
  casestring(pvs_defb);
  opdelim(pvs_opdelim);
  number(b, 8);
  checkblank();
}

void stddefc(byte c)
{
  /* do printable-char stuff like defb. */
}




void stddobyte(void)
{
  defb(getbyte());
}

void stddochar(void)
{
  defc(getbyte());
}

void stddoword(void)
{
  word w;

  w = getword();
  pb_length = 2;
  startline(true);
  casestring(pvs_defw);
  opdelim(pvs_opdelim);
  number(w, 16);
  checkblank();  
}

void stddolong(void)
{
  longword l;

  l = getlong();
  pb_length = 4;
  startline(true);
  casestring(pvs_defl);
  opdelim(pvs_opdelim);
  number(l, 32);
  checkblank();  
}



void number(longword n, unsigned int bits)
{
  (*pf_number)(n, bits);
}

void defb(byte b)
{
  (*pf_defb)(b);
}

void defc(byte c)
{
  (*pf_defc)(c);
}


dflt_number();
dflt_defb();
dflt_defc();

spf_number();
spf_defb();
spf_defc();

