/************************************************************************/

/* itype values: */

#define unused  0
#define inst    1
#define instb   2
#define instw   3
#define inst2w  4
#define pushj   5
#define popj    6
#define jrst    7
#define jrsti   8		/* Indirect... */

#define prefix 10		/* Prefix into another opcode table. */
#define subgrp 11		/* Subtable coded via R/M byte. */
#define again  12		/* Lookup this byte again, via subtable. */
#define split2 13		/* Sel. entry 0/1 on prefix [-,66] */
#define split4 14		/* Sel. entry 0/1/2/3 on prefix [-,66,F2,F3] */

#define splitf 15		/* Sel. entry 0..7 from flt sub-table. */

#define float  20		/* Floating point special decode. */

#define pfxseg 30		/* segment prefix. */
#define pfx32a 31		/* 32-bit addr prefix. */
#define pfx32d 32		/* 32-bit data prefix. */

#define FIXME unused		/* Things we have started on... */

/* flags: */

/* First, check bits used by the subtable look-up helper function: */

#define REG0  0x80000000	/* Mod == 11, R/M register = 0. */
#define REG1  0x40000000	/* Mod == 11, R/M register = 1. */
#define REG2  0x20000000	/* Mod == 11, R/M register = 2. */
#define REG3  0x10000000	/* Mod == 11, R/M register = 3. */
#define REG4  0x08000000	/* Mod == 11, R/M register = 4. */
#define REG5  0x04000000	/* Mod == 11, R/M register = 5. */
#define REG6  0x02000000	/* Mod == 11, R/M register = 6. */
#define REG7  0x01000000	/* Mod == 11, R/M register = 7. */
#define REG   0xff000000	/* Mod == 11, any R/M register. */
#define MEM   0x00800000	/* Mod != 11, memory ref. */
#define P66   0x00400000	/* With prefix 0x66. */
#define PF2   0x00200000	/* With prefix 0xF2. */
#define PF3   0x00100000	/* With prefix 0xF3. */
#define NPFX  0x00080000	/* Without prefix. */
#define O64   0x00040000	/* Only valid in 64-bit mode. */
#define X64   0x00020000	/* Not valid in 64-bit mode. */
#define REXW  0x00010000	/* Match if REX.W is set. */

#define CHECK 0xffff0000	/* Mask of all check bits above. */

/* "normal" control bits: */

#define SZ    0x00000008	/* We need to tell the size of EA. */
#define SX    0x00000004	/* Sign-extend imm. data. */
#define EA    0x00000002	/* We have a [mod/reg/r-m] byte. */
#define WB    0x00000001	/* Word bit flag. */

/* prefix = 80/81/82/83, group 1: */

static dispblock sub80disp[] = {
  { 0000, 0, inst,   SZ,       "add %e,%i" },
  { 0010, 0, inst,   SZ,       "or %e,%i" },
  { 0020, 0, inst,   SZ,       "adc %e,%i" },
  { 0030, 0, inst,   SZ,       "sbb %e,%i" },
  { 0040, 0, inst,   SZ,       "and %e,%i" },
  { 0050, 0, inst,   SZ,       "sub %e,%i" },
  { 0060, 0, inst,   SZ,       "xor %e,%i" },
  { 0070, 0, inst,   SZ,       "cmp %e,%i" },
  { 0000, 0, arnold },
};

/* prefix = c0/c1, group 2a: */

static dispblock subC0disp[] = {
  { 0000, 0, inst,   SZ,       "rol %e,%1" },
  { 0010, 0, inst,   SZ,       "ror %e,%1" },
  { 0020, 0, inst,   SZ,       "rcl %e,%1" },
  { 0030, 0, inst,   SZ,       "rcr %e,%1" },
  { 0040, 0, inst,   SZ,       "shl %e,%1" },
  { 0050, 0, inst,   SZ,       "shr %e,%1" },
  { 0070, 0, inst,   SZ,       "sar %e,%1" },
  { 0000, 0, arnold },
};

/* prefix = c6, group 11a: */

static dispblock subC6adisp[] = {
  { 0000, 0, instb,  SZ,       "mov %e,%1" },
  { 0070, 5, inst,   REG0,     "xabort %1" },
  { 0000, 0, arnold },
};

/* prefix = c7, group 11b: */

static dispblock subC6bdisp[] = {
  { 0000, 0, instw,  SZ+WB,    "mov %e,%2" },
  { 0070, 5, inst,   WB+REG0,  "xbegin %d" },
  { 0000, 0, arnold },
};

/* prefix = d0/d1, group 2b: */

static dispblock subD0disp[] = {
  { 0000, 0, inst,   SZ,       "rol %e,1" },
  { 0010, 0, inst,   SZ,       "ror %e,1" },
  { 0020, 0, inst,   SZ,       "rcl %e,1" },
  { 0030, 0, inst,   SZ,       "rcr %e,1" },
  { 0040, 0, inst,   SZ,       "shl %e,1" },
  { 0050, 0, inst,   SZ,       "shr %e,1" },
  { 0070, 0, inst,   SZ,       "sar %e,1" },
  { 0000, 0, arnold },
};

/* prefix = d2/d3, group 2c: */

static dispblock subD2disp[] = {
  { 0000, 0, inst,   SZ,       "rol %e,#cl" },
  { 0010, 0, inst,   SZ,       "ror %e,#cl" },
  { 0020, 0, inst,   SZ,       "rcl %e,#cl" },
  { 0030, 0, inst,   SZ,       "rcr %e,#cl" },
  { 0040, 0, inst,   SZ,       "shl %e,#cl" },
  { 0050, 0, inst,   SZ,       "shr %e,#cl" },
  { 0070, 0, inst,   SZ,       "sar %e,#cl" },
  { 0000, 0, arnold },
};

/* prefix = f6/f7, group 3: */

static dispblock subF6disp[] = {
  { 0000, 0, inst,   SZ,       "test %e,%i" },
  { 0020, 0, inst,   SZ,       "not %e" },
  { 0030, 0, inst,   SZ,       "neg %e" },
  { 0040, 0, inst,   SZ,       "mul %e" },
  { 0050, 0, inst,   SZ,       "imul %e" },
  { 0060, 0, inst,   SZ,       "div %e" },
  { 0070, 0, inst,   SZ,       "idiv %e" },
  { 0000, 0, arnold },
};

/* prefix = fe, group 4: */

static dispblock subFEdisp[] = {
  { 0000, 0, instb,  SZ,       "inc %e" },
  { 0010, 0, instb,  SZ,       "dec %e" },
  { 0000, 0, arnold },
};

/* prefix = ff, group 5: */

static dispblock subFFdisp[] = {
  { 0000, 0, instw,  SZ,       "inc %e" },
  { 0010, 0, instw,  SZ,       "dec %e" },
  { 0020, 0, pushj,  0,        "call %e" },
  { 0030, 0, pushj,  0,        "callf %e" },
  { 0040, 0, jrsti,  0,        "jmp %E" },
  { 0050, 0, jrst,   0,        "jmp %:" },
  { 0060, 0, instw,  SZ,       "push %e" },
  { 0000, 0, arnold },
};

/* prefix = 0f 00, group 6: */

static dispblock sub0F00disp[] = {
  { 0000, 2, inst,   WB,         "sldt %e" },
  { 0010, 2, inst,   WB,         "str %e" },
  { 0020, 2, inst,   WB,         "lldt %e" },
  { 0030, 2, inst,   WB,         "ltr %e" },
  { 0040, 2, inst,   WB,         "verr %e" },
  { 0050, 2, inst,   WB,         "verw %e" },
  { 0000, 0, arnold },
};

/* prefix = 0f 01, group 7: */

static dispblock sub0F01disp[] = {
  { 0000, 2, inst,   MEM+WB,     "sgdt %e" },
  { 0000, 2, inst,   REG1,       "vmcall" },
  { 0000, 2, inst,   REG2,       "vmlaunch" },
  { 0000, 2, inst,   REG3,       "vmresume" },
  { 0000, 2, inst,   REG4,       "vmxoff" },
  { 0010, 2, inst,   MEM+WB,     "sidt %e" },
  { 0010, 2, inst,   REG0,       "monitor" },
  { 0010, 2, inst,   REG1,       "mwait" },
  { 0020, 2, inst,   MEM+WB,     "lgdt %e" },
  { 0020, 2, inst,   REG0,       "xgetbv" },
  { 0020, 2, inst,   REG1,       "xsetbv" },
  { 0020, 2, inst,   REG4,       "vmfunc" },
  { 0020, 2, inst,   REG5,       "xend" },
  { 0020, 2, inst,   REG6,       "xtest" },
  { 0030, 2, inst,   MEM+WB,     "lidt %e" },
  { 0040, 2, inst,   WB,         "smsw %e" },
  { 0060, 2, inst,   WB,         "lmsw %e" },
  { 0070, 2, inst,   MEM+WB,     "invlpg %e" },
  { 0070, 2, inst,   REG0,       "swapgs" },
  { 0070, 2, inst,   REG1,       "rdtscp" },
  { 0000, 0, arnold },
};

/* prefix = 0f 18, group 16: */

static dispblock sub0F18disp[] = {
  { 0000, 3, inst,   MEM,      "prefetchnta %e" },
  { 0010, 3, inst,   MEM,      "prefetcht0 %e" },
  { 0020, 3, inst,   MEM,      "prefetcht1 %e" },
  { 0030, 3, inst,   MEM,      "prefetcht2 %e" },
  { 0000, 0, arnold },
};

/* prefix = 0f 38: */

static dispblock pfx0F38disp[] = {
  { 0x00, 5, FIXME, EA,        "pshufb %m,e" }, /* xmm reg with 66. */
  { 0x01, 5, FIXME, EA,        "phaddw %m,e" }, /* xmm reg with 66. */
  { 0x02, 5, FIXME, EA,        "phaddd %m,e" }, /* xmm reg with 66. */
  { 0x03, 5, FIXME, EA,        "phaddsw %m,e" }, /* xmm reg with 66. */
  { 0x04, 5, FIXME, EA,        "pmaddubsw %m,e" }, /* xmm reg with 66. */
  { 0x05, 5, FIXME, EA,        "phsubw %m,e" }, /* xmm reg with 66. */
  { 0x06, 5, FIXME, EA,        "phsubd %m,e" }, /* xmm reg with 66. */
  { 0x07, 5, FIXME, EA,        "phsubsw %m,e" }, /* xmm reg with 66. */
  { 0x08, 5, FIXME, EA,        "psignb %m,e" }, /* xmm reg with 66. */
  { 0x09, 5, FIXME, EA,        "psignw %m,e" }, /* xmm reg with 66. */
  { 0x0a, 5, FIXME, EA,        "psignd %m,e" }, /* xmm reg with 66. */
  { 0x0b, 5, FIXME, EA,        "pmulhrsw %m,e" }, /* xmm reg with 66. */
  { 0x10, 5, FIXME, EA+P66,    "pblendvb %x,e" },
  { 0x14, 5, FIXME, EA+P66,    "blendvps %x,e" },
  { 0x15, 5, FIXME, EA+P66,    "blendvpd %x,e" },
  { 0x17, 5, FIXME, EA+P66,    "ptest %x,e" },
  { 0x1c, 5, FIXME, EA,        "pabsb %m,e" }, /* xmm reg with 66. */
  { 0x1d, 5, FIXME, EA,        "pabsw %m,e" }, /* xmm reg with 66. */
  { 0x1e, 5, FIXME, EA,        "pabsd %m,e" }, /* xmm reg with 66. */
  { 0x20, 5, FIXME, EA+P66,    "pmovsxbw %x,e" },
  { 0x21, 5, FIXME, EA+P66,    "pmovsxbd %x,e" },
  { 0x22, 5, FIXME, EA+P66,    "pmovsxbq %x,e" },
  { 0x23, 5, FIXME, EA+P66,    "pmovsxwd %x,e" },
  { 0x24, 5, FIXME, EA+P66,    "pmovsxwq %x,e" },
  { 0x25, 5, FIXME, EA+P66,    "pmovsxdq %x,e" },
  { 0x28, 5, FIXME, EA+P66,    "pmuldq %x,e" },
  { 0x29, 5, FIXME, EA+P66,    "pcmpeqq %x,e" },
  { 0x2a, 5, FIXME, EA+P66+MEM,"movntdqa %x,e" },
  { 0x2b, 5, FIXME, EA+P66,    "packusdw %x,e" },
  { 0x30, 5, FIXME, EA+P66,    "pmovzxbw %x,e" },
  { 0x31, 5, FIXME, EA+P66,    "pmovzxbd %x,e" },
  { 0x32, 5, FIXME, EA+P66,    "pmovzxbq %x,e" },
  { 0x33, 5, FIXME, EA+P66,    "pmovzxwd %x,e" },
  { 0x34, 5, FIXME, EA+P66,    "pmovzxwq %x,e" },
  { 0x35, 5, FIXME, EA+P66,    "pmovzxdq %x,e" },
  { 0x37, 5, FIXME, EA+P66,    "pcmpgtq %x,e" },
  { 0x38, 5, FIXME, EA+P66,    "pminsb %x,e" },
  { 0x39, 5, FIXME, EA+P66,    "pminsd %x,e" },
  { 0x3a, 5, FIXME, EA+P66,    "pminuw %x,e" },
  { 0x3b, 5, FIXME, EA+P66,    "pminud %x,e" },
  { 0x3c, 5, FIXME, EA+P66,    "pmaxsb %x,e" },
  { 0x3d, 5, FIXME, EA+P66,    "pmaxsd %x,e" },
  { 0x3e, 5, FIXME, EA+P66,    "pmaxuw %x,e" },
  { 0x3f, 5, FIXME, EA+P66,    "pmaxud %x,e" },
  { 0x40, 5, FIXME, EA+P66,    "pmulld %x,e" },
  { 0x41, 5, FIXME, EA+P66,    "phminposuw %x,e" },
  { 0x80, 5, FIXME, EA+P66,    "invept Gy,Mdq" },
  { 0x81, 5, FIXME, EA+P66,    "invvpid Gy,Mdq" },
  { 0x82, 5, FIXME, EA+P66,    "invpcid Gy,Mdq" },
  { 0xdb, 5, FIXME, EA+P66,    "aesimc %x,e" },
  { 0xdc, 5, FIXME, EA+P66,    "aesenc %x,e" },
  { 0xdd, 5, FIXME, EA+P66,    "aesenclast %x,e" },
  { 0xde, 5, FIXME, EA+P66,    "aesdec %x,e" },
  { 0xdf, 5, FIXME, EA+P66,    "aesdeclast %x,e" },

  /*
   *  f0
   *  f1
   */

  { 0,   0, arnold },
};

/* prefix = 0f 3a: */

static dispblock pfx0F3Adisp[] = {
  { 0x08, 5, FIXME,  EA+P66,   "roundps %x,%e,%1" },
  { 0x09, 5, FIXME,  EA+P66,   "roundpd %x,%e,%1" },
  { 0x0a, 5, FIXME,  EA+P66,   "roundss %x,%e,%1" },
  { 0x0b, 5, FIXME,  EA+P66,   "roundsd %x,%e,%1" },
  { 0x0c, 5, FIXME,  EA+P66,   "blendps %x,%e,%1" },
  { 0x0d, 5, FIXME,  EA+P66,   "blendpd %x,%e,%1" },
  { 0x0e, 5, FIXME,  EA+P66,   "pblendw %x,%e,%1" },
  { 0x0f, 5, FIXME,  EA,       "palignr %m,%e,%1" }, /* xmm reg with 66. */
  { 0x14, 5, FIXME,  EA+P66,   "pextrb %e,%x,%1" },
  { 0x15, 5, FIXME,  EA+P66,   "pextrw %e,%x,%1" },
  { 0x16, 5, again,  EA+P66, ((dispblock []) {
    { 0x16, 5, FIXME,  REXW,     "pextrq %e,%x,%1" },
    { 0x16, 5, FIXME,  0,        "pextrd %e,%x,%1" },
    { 0,    0, arnold },
  })},

  { 0x17, 5, FIXME,  EA+P66,   "extractps %e,%x,%1" }, /* XXX %e is normal.*/
  { 0x20, 5, FIXME,  EA+P66,   "pinsrb %x,%e,%1" },
  { 0x21, 5, FIXME,  EA+P66,   "pinsrw %x,%e,%1" },
  { 0x22, 5, again,  EA+P66, ((dispblock []) {
    { 0x22, 5, FIXME,  REXW,     "pinsrq %x,%e,%1" },
    { 0x22, 5, FIXME,  0,        "pinsrd %x,%e,%1" },
    { 0,    0, arnold },
  })},

  { 0x40, 5, FIXME,  EA+P66,   "dpps %x,%e,%1" },
  { 0x41, 5, FIXME,  EA+P66,   "dppd %x,%e,%1" },
  { 0x42, 5, FIXME,  EA+P66,   "mpsadbw %x,%e,%1" },
  { 0x44, 5, prefix, EA, ((dispblock []) {
    { 0x00, 0, FIXME,  P66,      "pclmullqlqdq %x,%e" },
    { 0x01, 0, FIXME,  P66,      "pclmulhqlqdq %x,%e" },
    { 0x02, 0, FIXME,  P66,      "pclmullqhqdq %x,%e" },
    { 0x03, 0, FIXME,  P66,      "pclmulhqhqdq %x,%e" },
    { 0,    0, arnold },
  })},
  { 0x60, 5, FIXME,  EA+P66,   "pcmpestrm %x,%e,%1" },
  { 0x61, 5, FIXME,  EA+P66,   "pcmpestri %x,%e,%1" },
  { 0x62, 5, FIXME,  EA+P66,   "pcmpistrm %x,%e,%1" },
  { 0x63, 5, FIXME,  EA+P66,   "pcmpistri %x,%e,%1" },
  { 0xdf, 5, FIXME,  EA+P66,   "aeskeygenassist %x,%e,%1" },
  { 0,    0, arnold },
};

/* prefix = 0f 71, group 12: */

static dispblock sub0F71disp[] = {
  { 0020, 0, FIXME,  REG+NPFX, "psrlw %m,%1" },
  { 0020, 0, FIXME,  REG+P66,  "psrlw %x,%1" },
  { 0040, 0, FIXME,  REG+NPFX, "psraw %m,%1" },
  { 0040, 0, FIXME,  REG+P66,  "psraw %x,%1" },
  { 0060, 0, FIXME,  REG+NPFX, "psllw %m,%1" },
  { 0060, 0, FIXME,  REG+P66,  "psllw %x,%1" },
  { 0000, 0, arnold },
};

/* prefix = 0f 72, group 13: */

static dispblock sub0F72disp[] = {
  { 0020, 0, FIXME,  REG+NPFX, "psrld %m,%1" },
  { 0020, 0, FIXME,  REG+P66,  "psrld %x,%1" },
  { 0040, 0, FIXME,  REG+NPFX, "psrad %m,%1" },
  { 0040, 0, FIXME,  REG+P66,  "psrad %x,%1" },
  { 0060, 0, FIXME,  REG+NPFX, "pslld %m,%1" },
  { 0060, 0, FIXME,  REG+P66,  "pslld %x,%1" },
  { 0000, 0, arnold },
};

/* prefix = 0f 73, group 14: */

static dispblock sub0F73disp[] = {
  { 0020, 0, FIXME,  REG+NPFX, "psrlq %m,%1" },
  { 0020, 0, FIXME,  REG+P66,  "psrlq %x,%1" },
  { 0030, 0, FIXME,  REG+P66,  "psrldq %x,%1" },
  { 0060, 0, FIXME,  REG+NPFX, "psllw %m,%1" },
  { 0060, 0, FIXME,  REG+P66,  "psllq %x,%1" },
  { 0070, 0, FIXME,  REG+P66,  "pslldq %x,%1" },
  { 0000, 0, arnold },
};

/* prefix = 0f ba, group 8: */

static dispblock sub0FBAdisp[] = {
  { 0040, 3, inst,   WB,       "bt %e,%1" },
  { 0050, 3, inst,   WB,       "bts %e,%1" },
  { 0060, 3, inst,   WB,       "btr %e,%1" },
  { 0070, 3, inst,   WB,       "btc %e,%1" },
  { 0000, 0, arnold },
};

/* prefix = 0f b9, group 10: */

static dispblock sub0FB9disp[] = {
  /* This group is empty. */
  { 0000, 0, arnold },
};

/* prefix = 0f c7, group 9: */

static dispblock sub0FC7disp[] = {
  { 0010, 5, inst,   MEM+NPFX+REXW, "cmpxch16b %e" },
  { 0010, 5, inst,   MEM+NPFX, "cmpxch8b %e" },
  { 0060, 5, inst,   MEM+NPFX, "vmptrld %e" },
  { 0060, 5, inst,   MEM+P66,  "vmclear %e" },
  { 0060, 5, inst,   MEM+PF3,  "vmxon %e" },
  { 0060, 5, inst,   REG,      "rdrand %e" },
  { 0070, 5, inst,   MEM+NPFX, "vmptrst %e" },
  { 0070, 5, inst,   MEM+PF3,  "vmptrst %e" },
  { 0000, 0, arnold },
};

/* prefix = 0f ae, group 15: */

static dispblock sub0FAEdisp[] = {
  { 0000, 5, inst,   MEM+REXW, "fxsave64 %e" },
  { 0000, 5, inst,   MEM,      "fxsave %e" },
  { 0000, 5, inst,   REG+PF3,  "rdfsbase %r" },
  { 0010, 5, inst,   MEM+REXW, "fxrstor64 %e" },
  { 0010, 5, inst,   MEM,      "fxrstor %e" },
  { 0010, 5, inst,   REG+PF3,  "rdgsbase %r" },
  { 0020, 5, inst,   MEM,      "ldmxcsr %e" },
  { 0020, 5, inst,   REG+PF3,  "wrfsbase %r" },
  { 0030, 4, inst,   MEM,      "stmxcsr %e" },
  { 0030, 5, inst,   REG+PF3,  "wrgsbase %r" },
  { 0040, 5, inst,   MEM,      "xsave %e" },
  { 0050, 5, inst,   MEM,      "xrstor %e" },
  { 0050, 4, inst,   REG+NPFX, "lfence" },
  { 0060, 5, inst,   MEM,      "xsaveopt %e" },
  { 0060, 4, inst,   REG+NPFX, "mfence" },
  { 0070, 4, inst,   MEM,      "clflush %e" },
  { 0070, 4, inst,   REG+NPFX, "sfence" },
  { 0000, 0, arnold },
};

/* prefix = 0f: */

static dispblock pfx0Fdisp[256] = {
  { 0x00, 0, subgrp, 0,        sub0F00disp },
  { 0x01, 0, subgrp, 0,        sub0F01disp },
  { 0x02, 2, inst,   EA+WB,    "lar %r,%e" },
  { 0x03, 2, inst,   EA+WB,    "lsl %r,%e" },
  { 0x04, 0, unused, 0,        0 },
  { 0x05, 5, inst,   0,        "syscall" },
  { 0x06, 2, inst,   0,        "clts" },
  { 0x07, 5, inst,   0,        "sysret" },
  { 0x08, 4, inst,   0,        "invd" },
  { 0x09, 4, inst,   0,        "wbinvd" },
  { 0x0a, 0, unused, 0,        0 },
  { 0x0b, 3, inst,   0,        "ud2" },
  { 0x0c, 0, unused, 0,        0 },
  { 0x0d, 4, subgrp, 0, ((dispblock []) { /* AMD instructions. */
    { 0000, 0, inst,   0,        "prefetch %e" },
    { 0010, 0, inst,   0,        "prefetchw %e" },
    { 0000, 0, arnold },
  })},
  { 0x0e, 0, unused, 0,        0 }, /* AMD? */
  { 0x0f, 0, unused, 0,        0 }, /* AMD? */

  { 0x10, 5, split4, EA, ((dispblock []) {
    { 0x10, 5, FIXME,  0,        "movups r,e" },
    { 0x10, 5, FIXME,  0,        "movupd r,e" },
    { 0x10, 5, FIXME,  0,        "movsd r,e" },
    { 0x10, 5, FIXME,  0,        "movss r,e" },
  })},
  { 0x11, 5, split4, EA, ((dispblock []) {
    { 0x11, 5, FIXME,  0,        "movups e,r" },
    { 0x11, 5, FIXME,  0,        "movupd e,r" },
    { 0x11, 5, FIXME,  0,        "movsd e,r" },
    { 0x11, 5, FIXME,  0,        "movss e,r" },
  })},
  { 0x12, 5, again,  EA, ((dispblock []) {
    { 0x12, 5, FIXME,  REG+NPFX, "movhlps r,r", },
    { 0x12, 5, FIXME,  MEM+NPFX, "movlps r,m" },
    { 0x12, 5, FIXME,  MEM+P66,  "movlpd r,m" },
    { 0x12, 5, FIXME,  PF2,      "movddup r,e" },
    { 0x12, 5, FIXME,  PF3,      "movsldup r,e" },
    { 0000, 0, arnold },
  })},
  { 0x13, 5, split2, EA, ((dispblock []) {
    { 0x13, 5, FIXME,  MEM,      "movlps m,r" },
    { 0x13, 5, FIXME,  MEM,      "movlpd m,r" },
  })},
  { 0x14, 5, split2, EA, ((dispblock []) {
    { 0x14, 5, FIXME,  0,        "uppcklps r,e" },
    { 0x14, 5, FIXME,  0,        "unpcklpd r,e" },
  })},
  { 0x15, 5, split2, EA, ((dispblock []) {
    { 0x15, 5, FIXME,  0,        "unpckhps r,e" },
    { 0x15, 5, FIXME,  0,        "unpckhpd r,e" },
  })},
  { 0x16, 5, again,  EA, ((dispblock []) {
    { 0x16, 5, FIXME,  REG+NPFX, "movlhps r,r" },
    { 0x16, 5, FIXME,  MEM+NPFX, "movhps r,m" },
    { 0x16, 5, FIXME,  MEM+P66,  "movhpd r,m" },
    { 0x16, 5, FIXME,  PF3,      "movshdup r,e" },
    { 0000, 0, arnold },
  })},
  { 0x17, 5, split2, EA, ((dispblock []) {
    { 0x17, 5, FIXME,  0,        "movhps m,r" },
    { 0x17, 5, FIXME,  0,        "movhpd m,r" },
  })},
  { 0x18, 3, subgrp, 0,        sub0F18disp },
  { 0x19, 0, unused, 0,        0 }, /* Reserved hints. */
  { 0x1a, 0, unused, 0,        0 }, /* Reserved hints. */
  { 0x1b, 0, unused, 0,        0 }, /* Reserved hints. */
  { 0x1c, 0, unused, 0,        0 }, /* Reserved hints. */
  { 0x1d, 0, unused, 0,        0 }, /* Reserved hints. */
  { 0x1e, 0, unused, 0,        0 }, /* Reserved hints. */
  { 0x1f, 3, subgrp, WB, ((dispblock[]) {
    { 0000, 0, inst,   0,        "nop %e" },
    { 0000, 0, arnold },
  })},

  { 0x20, 3, FIXME,  0,        "mov reg, c-reg" },
  { 0x21, 3, FIXME,  0,        "mov reg, d-reg" },
  { 0x22, 3, FIXME,  0,        "mov c-reg, reg" },
  { 0x23, 3, FIXME,  0,        "mov d-reg, reg" },
  { 0x24, 0, unused, 0,        0 }, /* AMD?  SSE5? */
  { 0x25, 0, unused, 0,        0 }, /* AMD?  SSE5? */
  { 0x26, 0, unused, 0,        0 },
  { 0x27, 0, unused, 0,        0 },
  { 0x28, 5, split2, EA, ((dispblock []) {
    { 0x28, 5, FIXME,  0,        "movaps r,e" },
    { 0x28, 5, FIXME,  0,        "movapd r,e" },
  })},
  { 0x29, 5, split2, EA, ((dispblock []) {
    { 0x29, 5, FIXME,  0,        "movaps e,r" },
    { 0x29, 5, FIXME,  0,        "movapd e,r" },
  })},
  { 0x2a, 5, split4, EA, ((dispblock []) {
    { 0x2a, 5, FIXME,  0,        "cvtpi2ps r,e" },
    { 0x2a, 5, FIXME,  0,        "cvtpi2pd r,e" },
    { 0x2a, 5, FIXME,  0,        "cvtsi2sd r,e" },
    { 0x2a, 5, FIXME,  0,        "cvtsi2ss r,e" },
  })},
  { 0x2b, 5, split2, EA, ((dispblock []) {
    { 0x2b, 5, FIXME,  0,        "movntps m,r" },
    { 0x2b, 5, FIXME,  0,        "movntpd m,r" },
  })},
  { 0x2c, 5, split4, EA, ((dispblock []) {
    { 0x2c, 5, FIXME,  0,        "cvttps2pi r,e" },
    { 0x2c, 5, FIXME,  0,        "cvttpd2pi r,e" },
    { 0x2c, 5, FIXME,  0,        "cvttsd2si r,e" },
    { 0x2c, 5, FIXME,  0,        "cvttss2si r,e" },
  })},
  { 0x2d, 5, split4, EA, ((dispblock []) {
    { 0x2d, 5, FIXME,  0,        "cvtps2pi r,e" },
    { 0x2d, 5, FIXME,  0,        "cvtpd2pi r,e" },
    { 0x2d, 5, FIXME,  0,        "cvtsd2si r,e" },
    { 0x2d, 5, FIXME,  0,        "cvtss2si r,e" },
  })},
  { 0x2e, 5, split2, EA, ((dispblock []) {
    { 0x2e, 5, FIXME,  0,        "ucomiss r,e" },
    { 0x2e, 5, FIXME,  0,        "ucomisd r,e" },
  })},
  { 0x2f, 5, split2, EA, ((dispblock []) {
    { 0x2f, 5, FIXME,  0,        "comiss r,e" },
    { 0x2f, 5, FIXME,  0,        "comisd r,e" },
  })},

  { 0x30, 5, inst,   0,        "wrmsr" },
  { 0x31, 5, inst,   0,        "rdtsc" },
  { 0x32, 5, inst,   0,        "rdmsr" },
  { 0x33, 5, inst,   0,        "rdpmc" },
  { 0x34, 5, inst,   0,        "sysenter" },
  { 0x35, 5, inst,   0,        "sysexit" },
  { 0x36, 0, unused, 0,        0 },
  { 0x37, 5, inst,   0,        "getsec" },
  { 0x38, 5, prefix, 0,        pfx0F38disp },
  { 0x39, 0, unused, 0,        0 }, /* Intel, future. */
  { 0x3a, 5, prefix, 0,        pfx0F3Adisp },
  { 0x3b, 0, unused, 0,        0 }, /* Intel, future. */
  { 0x3c, 0, unused, 0,        0 },
  { 0x3d, 0, unused, 0,        0 },
  { 0x3e, 0, unused, 0,        0 },
  { 0x3f, 0, unused, 0,        0 },

  { 0x40, 5, instw,  EA+WB,    "cmov? %r,%e" },	/* cmovo */
  { 0x41, 5, instw,  EA+WB,    "cmov? %r,%e" },	/* cmovno */
  { 0x42, 5, instw,  EA+WB,    "cmov? %r,%e" }, /* cmovnae */
  { 0x43, 5, instw,  EA+WB,    "cmov? %r,%e" }, /* cmovnb/cmovnc */
  { 0x44, 5, instw,  EA+WB,    "cmov? %r,%e" }, /* cmovz */
  { 0x45, 5, instw,  EA+WB,    "cmov? %r,%e" }, /* cmovnz */
  { 0x46, 5, instw,  EA+WB,    "cmov? %r,%e" }, /* cmovna */
  { 0x47, 5, instw,  EA+WB,    "cmov? %r,%e" }, /* cmovnbe */
  { 0x48, 5, instw,  EA+WB,    "cmov? %r,%e" },	/* cmovs */
  { 0x49, 5, instw,  EA+WB,    "cmov? %r,%e" },	/* cmovns */
  { 0x4a, 5, instw,  EA+WB,    "cmov? %r,%e" }, /* cmovpe */
  { 0x4b, 5, instw,  EA+WB,    "cmov? %r,%e" }, /* cmovpo */
  { 0x4c, 5, instw,  EA+WB,    "cmov? %r,%e" }, /* cmovnge */
  { 0x4d, 5, instw,  EA+WB,    "cmov? %r,%e" }, /* cmovnl */
  { 0x4e, 5, instw,  EA+WB,    "cmov? %r,%e" }, /* cmovng */
  { 0x4f, 5, instw,  EA+WB,    "cmov? %r,%e" }, /* cmovnle */

  { 0x50, 5, split2, EA, ((dispblock []) {
    { 0x50, 5, FIXME,  0,        "movmskps r,xmm" },
    { 0x50, 5, FIXME,  0,        "movmskpd r,xmm" },
  })},
  { 0x51, 5, split4, EA, ((dispblock []) {
    { 0x51, 5, FIXME,  0,        "sqrtps xmm,e" },
    { 0x51, 5, FIXME,  0,        "sqrtpd xmm,e" },
    { 0x51, 5, FIXME,  0,        "sqrtsd xmm,e" },
    { 0x51, 5, FIXME,  0,        "sqrtss xmm,e" },
  })},
  { 0x52, 5, again,  EA, ((dispblock []) {
    { 0x52, 5, FIXME,  NPFX,     "rsqrtps xmm,e" },
    { 0x52, 5, FIXME,  PF3,      "rsqrtss xmm,e" },
    { 0000, 0, arnold },
  })},
  { 0x53, 5, again,  EA, ((dispblock []) {
    { 0x53, 5, FIXME,  NPFX,     "rcpps xmm,e" },
    { 0x53, 5, FIXME,  PF3,      "rcpss xmm,e" },
    { 0000, 0, arnold },
  })},
  { 0x54, 5, split2, EA, ((dispblock []) {
    { 0x54, 5, FIXME,  0,        "andps xmm,e" },
    { 0x54, 5, FIXME,  0,        "andpd xmm,e" },
  })},
  { 0x55, 5, split2, EA, ((dispblock []) {
    { 0x55, 5, FIXME,  0,        "andnps xmm,e" },
    { 0x55, 5, FIXME,  0,        "andnpd xmm,e" },
  })},
  { 0x56, 5, split2, EA, ((dispblock []) {
    { 0x56, 5, FIXME,  0,        "orps xmm,e" },
    { 0x56, 5, FIXME,  0,        "orpd xmm,e" },
  })},
  { 0x57, 5, split2, EA, ((dispblock []) {
    { 0x57, 5, FIXME,  0,        "xorps xmm,e" },
    { 0x57, 5, FIXME,  0,        "xorpd xmm,e" },
  })},
  { 0x58, 5, split4, EA, ((dispblock []) {
    { 0x58, 5, FIXME,  0,          "addps xmm,e" },
    { 0x58, 5, FIXME,  0,          "addpd xmm,e" },
    { 0x58, 5, FIXME,  0,          "addsd xmm,e" },
    { 0x58, 5, FIXME,  0,          "addss xmm,e" },
  })},
  { 0x59, 5, split4, EA, ((dispblock []) {
    { 0x59, 5, FIXME,  0,          "mulps xmm,e" },
    { 0x59, 5, FIXME,  0,          "mulpd xmm,e" },
    { 0x59, 5, FIXME,  0,          "mulsd xmm,e" },
    { 0x59, 5, FIXME,  0,          "mulss xmm,e" },
  })},
  { 0x5a, 5, split4, EA, ((dispblock []) {
    { 0x59, 5, FIXME,  0,          "cvtps2pd xmm,e" },
    { 0x59, 5, FIXME,  0,          "cvtpd2ps xmm,e" },
    { 0x59, 5, FIXME,  0,          "cvtsd2ss xmm,e" },
    { 0x59, 5, FIXME,  0,          "cvtss2sd xmm,e" },
  })},
  { 0x5b, 5, split4, EA, ((dispblock []) {
    { 0x59, 5, FIXME,  0,          "cvtdq2ps xmm,e" },
    { 0x59, 5, FIXME,  0,          "cvtps2dq xmm,e" },
    { 0x59, 5, unused, 0,          0 },
    { 0x59, 5, FIXME,  0,          "cvttps2dq xmm,e" },
  })},
  { 0x5c, 5, split4, EA, ((dispblock []) {
    { 0x59, 5, FIXME,  0,          "subps xmm,e" },
    { 0x59, 5, FIXME,  0,          "subpd xmm,e" },
    { 0x59, 5, FIXME,  0,          "subsd xmm,e" },
    { 0x59, 5, FIXME,  0,          "subss xmm,e" },
  })},
  { 0x5d, 5, split4, EA, ((dispblock []) {
    { 0x59, 5, FIXME,  0,          "minps xmm,e" },
    { 0x59, 5, FIXME,  0,          "minpd xmm,e" },
    { 0x59, 5, FIXME,  0,          "minsd xmm,e" },
    { 0x59, 5, FIXME,  0,          "minss xmm,e" },
  })},
  { 0x5e, 5, split4, EA, ((dispblock []) {
    { 0x59, 5, FIXME,  0,          "divps xmm,e" },
    { 0x59, 5, FIXME,  0,          "divpd xmm,e" },
    { 0x59, 5, FIXME,  0,          "divsd xmm,e" },
    { 0x59, 5, FIXME,  0,          "divss xmm,e" },
  })},
  { 0x5f, 5, split4, EA, ((dispblock []) {
    { 0x59, 5, FIXME,  0,          "maxps xmm,e" },
    { 0x59, 5, FIXME,  0,          "maxpd xmm,e" },
    { 0x59, 5, FIXME,  0,          "maxsd xmm,e" },
    { 0x59, 5, FIXME,  0,          "maxss xmm,e" },
  })},

  { 0x60, 5, split2, EA, ((dispblock []) {
    { 0x60, 5, FIXME,  0,        "punpcklbw mm,e" },
    { 0x60, 5, FIXME,  0,        "punpcklbw xmm,e" },
  })},
  { 0x61, 5, split2, EA, ((dispblock []) {
    { 0x61, 5, FIXME,  0,        "punpcklwd %m,e" },
    { 0x61, 5, FIXME,  0,        "punpcklwd xmm,e" },
  })},
  { 0x62, 5, split2, EA, ((dispblock []) {
    { 0x62, 5, FIXME,  0,        "punpckldq %m,e" },
    { 0x62, 5, FIXME,  0,        "punpckldq xmm,e" },
  })},
  { 0x63, 5, split2, EA, ((dispblock []) {
    { 0x63, 5, FIXME,  0,        "packsswb %m,e" },
    { 0x63, 5, FIXME,  0,        "packsswb xmm,e" },
  })},
  { 0x64, 5, split2, EA, ((dispblock []) {
    { 0x64, 5, FIXME,  0,        "pcmpgtb %m,e" },
    { 0x64, 5, FIXME,  0,        "pcmpgtb xmm,e" },
  })},
  { 0x65, 5, split2, EA, ((dispblock []) {
    { 0x65, 5, FIXME,  0,        "pcmpgtw %m,e" },
    { 0x65, 5, FIXME,  0,        "pcmpgtw xmm,e" },
  })},
  { 0x66, 5, split2, EA, ((dispblock []) {
    { 0x66, 5, FIXME,  0,        "pcmpgtd %m,e" },
    { 0x66, 5, FIXME,  0,        "pcmpgtd xmm,e" },
  })},
  { 0x67, 5, split2, EA, ((dispblock []) {
    { 0x67, 5, FIXME,  0,        "packuswb %m,e" },
    { 0x67, 5, FIXME,  0,        "packuswb xmm,e" },
  })},
  { 0x68, 5, split2, EA, ((dispblock []) {
    { 0x68, 5, FIXME,  0,        "punpckhbw %m,e" },
    { 0x68, 5, FIXME,  0,        "punpckhbw xmm,e" },
  })},
  { 0x69, 5, split2, EA, ((dispblock []) {
    { 0x69, 5, FIXME,  0,        "punpckhwd %m,e" },
    { 0x69, 5, FIXME,  0,        "punpckhwd xmm,e" },
  })},
  { 0x6a, 5, split2, EA, ((dispblock []) {
    { 0x6a, 5, FIXME,  0,        "punpckhdq %m,e" },
    { 0x6a, 5, FIXME,  0,        "punpckhdq xmm,e" },
  })},
  { 0x6b, 5, split2, EA, ((dispblock []) {
    { 0x6b, 5, FIXME,  0,        "packssdw %m,e" },
    { 0x6b, 5, FIXME,  0,        "packssdw xmm,e" },
  })},
  { 0x6c, 5, split2, EA, ((dispblock []) {
    { 0x6c, 5, unused, 0,        0 },
    { 0x6c, 5, FIXME,  0,        "punpcklqdq xmm,e" },
  })},
  { 0x6d, 5, split2, EA, ((dispblock []) {
    { 0x6d, 5, unused, 0,        0 },
    { 0x6d, 5, FIXME,  0,        "punpckhqdq xmm,e" },
  })},
  { 0x6e, 5, again,  EA, ((dispblock []) {
    { 0x6e, 5, FIXME,  NPFX,     "movd %m,e" },
    { 0x6e, 5, FIXME,  P66,      "movd xmm,e" },
    { 0x6e, 5, FIXME,  REXW,     "movq %m,e" },
    { 0x6e, 5, FIXME,  P66+REXW, "movq xmm,e" },
    { 0000, 0, arnold },
  })},
  { 0x6f, 5, split4, EA, ((dispblock []) {
    { 0x6f, 5, FIXME,  0,        "movq r,e" },
    { 0x6f, 5, FIXME,  0,        "movdqa r,e" },
    { 0x6f, 0, unused, 0,        0 },
    { 0x6f, 5, FIXME,  0,        "movdqu r,e" },
  })},

  { 0x70, 5, split4, EA, ((dispblock []) {
    { 0x70, 5, FIXME,  0,        "pshufw r,e,i" },
    { 0x70, 5, FIXME,  0,        "pshufd r,e,i" },
    { 0x70, 5, FIXME,  0,        "pshuflw r,e,i" },
    { 0x70, 5, FIXME,  0,        "pshufhw r,e,i" },
  })},
  { 0x71, 5, subgrp, 0,        sub0F71disp },
  { 0x72, 5, subgrp, 0,        sub0F72disp },
  { 0x73, 5, subgrp, 0,        sub0F73disp },
  { 0x74, 5, split2, EA, ((dispblock []) {
    { 0x74, 5, FIXME,  0,        "pcmpeqb r,e" }, /* mm */
    { 0x74, 5, FIXME,  0,        "pcmpeqb r,e" }, /* xmm */
  })},
  { 0x75, 5, split2, EA, ((dispblock []) {
    { 0x75, 5, FIXME,  0,        "pcmpeqw r,e" }, /* mm */
    { 0x75, 5, FIXME,  0,        "pcmpeqw r,e" }, /* xmm */
  })},
  { 0x76, 5, split2, EA, ((dispblock []) {
    { 0x76, 5, FIXME,  0,        "pcmpeqd r,e" }, /* mm */
    { 0x76, 5, FIXME,  0,        "pcmpeqd r,e" }, /* xmm */
  })},
  { 0x77, 5, FIXME,  0,        "emms" },
  { 0x78, 5, FIXME,  0,        "vmread" },
  { 0x79, 5, FIXME,  0,        "vmwrite" },
  { 0x7a, 0, unused, 0,        0 }, /* AMD?  SSE5? */
  { 0x7b, 0, unused, 0,        0 }, /* AMD?  SSE5? */
  { 0x7c, 5, split4, EA, ((dispblock []) {
    { 0x7c, 5, unused, 0,        0 },
    { 0x7c, 5, FIXME,  0,        "haddpd r,e" },
    { 0x7c, 0, unused, 0,        0 },
    { 0x7c, 5, FIXME,  0,        "haddps r,e" },
  })},
  { 0x7d, 5, split4, EA, ((dispblock []) {
    { 0x7d, 5, unused, 0,        0 },
    { 0x7d, 5, FIXME,  0,        "hsubpd r,e" },
    { 0x7d, 0, unused, 0,        0 },
    { 0x7d, 5, FIXME,  0,        "hsubps r,e" },
  })},
  { 0x7e, 5, again,  EA, ((dispblock []) {
    { 0x7e, 5, FIXME,  NPFX,     "movd e,mm" },
    { 0x7e, 5, FIXME,  P66,      "movd e,xmm" },
    { 0x7e, 0, FIXME,  REXW,     "movq e,mm" },
    { 0x7e, 0, FIXME,  P66+REXW, "movq e,xmm" },
    { 0x7e, 5, FIXME,  PF3,      "movq xmm,xe" },
    { 0000, 0, arnold },
  })},
  { 0x7f, 5, split4, EA, ((dispblock []) {
    { 0x7f, 5, FIXME,  0,        "movq e,r" },
    { 0x7f, 5, FIXME,  0,        "movdqa e,r" },
    { 0x7f, 0, unused, 0,        0 },
    { 0x7f, 5, FIXME,  0,        "movdqu e,r" },
  })},

  /* The following use 16/32-bit displacements. */

  { 0x80, 3, pushj,  WB,       "j? %d" }, /* jo */
  { 0x81, 3, pushj,  WB,       "j? %d" }, /* jno */
  { 0x82, 3, pushj,  WB,       "j? %d" }, /* jb */
  { 0x83, 3, pushj,  WB,       "j? %d" }, /* jnb */
  { 0x84, 3, pushj,  WB,       "j? %d" }, /* je */
  { 0x85, 3, pushj,  WB,       "j? %d" }, /* jne */
  { 0x86, 3, pushj,  WB,       "j? %d" }, /* jbe */
  { 0x87, 3, pushj,  WB,       "j? %d" }, /* jnbe */
  { 0x88, 3, pushj,  WB,       "j? %d" }, /* js */
  { 0x89, 3, pushj,  WB,       "j? %d" }, /* jns */
  { 0x8a, 3, pushj,  WB,       "j? %d" }, /* jp  */
  { 0x8b, 3, pushj,  WB,       "j? %d" }, /* jnp */
  { 0x8c, 3, pushj,  WB,       "j? %d" }, /* jl */
  { 0x8d, 3, pushj,  WB,       "j? %d" }, /* jnl */
  { 0x8e, 3, pushj,  WB,       "j? %d" }, /* jle */
  { 0x8f, 3, pushj,  WB,       "j? %d" }, /* jnle */

  { 0x90, 3, instb,  EA,       "set? %e" }, /* seto */
  { 0x91, 3, instb,  EA,       "set? %e" }, /* setno */
  { 0x92, 3, instb,  EA,       "set? %e" }, /* setb */
  { 0x93, 3, instb,  EA,       "set? %e" }, /* setnb */
  { 0x94, 3, instb,  EA,       "set? %e" }, /* sete */
  { 0x95, 3, instb,  EA,       "set? %e" }, /* setne */
  { 0x96, 3, instb,  EA,       "set? %e" }, /* setbe */
  { 0x97, 3, instb,  EA,       "set? %e" }, /* setnbe */
  { 0x98, 3, instb,  EA,       "set? %e" }, /* sets */
  { 0x99, 3, instb,  EA,       "set? %e" }, /* setns */
  { 0x9a, 3, instb,  EA,       "set? %e" }, /* setp */
  { 0x9b, 3, instb,  EA,       "set? %e" }, /* setnp */
  { 0x9c, 3, instb,  EA,       "set? %e" }, /* setl */
  { 0x9d, 3, instb,  EA,       "set? %e" }, /* setnl */
  { 0x9e, 3, instb,  EA,       "set? %e" }, /* setle */
  { 0x9f, 3, instb,  EA,       "set? %e" }, /* setnle */

  { 0xa0, 3, inst,   0,        "push $fs" },
  { 0xa1, 3, inst,   0,        "pop $fs" },
  { 0xa2, 5, inst,   0,        "cpuid" },
  { 0xa3, 3, inst,   EA+WB,    "bt %e,%r" },
  { 0xa4, 0, instw,  EA+WB,    "shld %e,%r,%1" },
  { 0xa5, 0, instw,  EA+WB,    "shld %e,%r,#cl" },
  { 0xa6, 0, unused, 0,        0 }, /* VIA? */
  { 0xa7, 0, unused, 0,        0 }, /* VIA? */
  { 0xa8, 3, inst,   0,        "push $gs" },
  { 0xa9, 3, inst,   0,        "pop $gs" },
  { 0xaa, 5, inst,   0,        "rsm" },
  { 0xab, 3, inst,   EA+WB,    "bts %e,%r" },
  { 0xac, 0, instw,  EA+WB,    "shrd %e,%r,%1" },
  { 0xad, 0, instw,  EA+WB,    "shrd %e,%r,$cl" },
  { 0xae, 4, subgrp, 0,        sub0FAEdisp },
  { 0xaf, 0, instw,  EA+WB,    "imul %r,%e" },

  { 0xb0, 4, instb,  EA,       "cmpxchg %e,%r" },
  { 0xb1, 4, instw,  EA+WB,    "cmpxchg %e,%r" },
  { 0xb2, 3, inst,   EA+WB,    "lss %r,%e" },
  { 0xb3, 3, inst,   EA+WB,    "btr %e,%r" },
  { 0xb4, 3, inst,   EA+WB,    "lfs %r,%e" },
  { 0xb5, 3, inst,   EA+WB,    "lgs %r,%e" },
  { 0xb6, 3, instb,  EA+WB,    "movzx %r,%e" },	/* SKUM */
  { 0xb7, 3, instw,  EA+WB,    "movzx %r,%e" },	/* SKUM */
  { 0xb8, 5, instw,  EA+WB,    "popcnt %r,%e" }, /* With prefix F3. JMPE? */
  { 0xb9, 0, subgrp, 0,        sub0FB9disp },
  { 0xba, 0, subgrp, 0,        sub0FBAdisp },
  { 0xbb, 3, instw,  EA+WB,    "btc %e,%r" },
  { 0xbc, 3, instw,  EA+WB,    "bsf %r,%e" }, /* TZCNT with prefix F3. */
  { 0xbd, 3, instw,  EA+WB,    "bsr %r,%e" }, /* LZCNT with prefix F3. */
  { 0xbe, 3, instb,  EA+WB,    "movsx %r,%e" },	/* SKUM */
  { 0xbf, 3, instw,  EA+WB,    "movsx %r,%e" },	/* SKUM */

  { 0xc0, 4, instb,  EA,       "xadd %e,%r" },
  { 0xc1, 4, instw,  EA+WB,    "xadd %e,%r" },
  { 0xc2, 5, split4, 0, ((dispblock []) {
    { 0xc2, 5, prefix, EA, ((dispblock []) {
      { 0, 5, FIXME,  0, "cmpeqps %x,%e" },
      { 1, 5, FIXME,  0, "cmpltps %x,%e" },
      { 2, 5, FIXME,  0, "cmpleps %x,%e" },
      { 3, 5, FIXME,  0, "cmpunordps %x,%e" },
      { 4, 5, FIXME,  0, "cmpneqps %x,%e" },
      { 5, 5, FIXME,  0, "cmpnltps %x,%e" },
      { 6, 5, FIXME,  0, "cmpnleps %x,%e" },
      { 7, 5, FIXME,  0, "cmpordps %x,%e" },
      { 0, 0, arnold },
    })},
    { 0xc2, 5, prefix, EA, ((dispblock []) {
      { 0, 5, FIXME,  0, "cmpeqpd %x,%e" },
      { 1, 5, FIXME,  0, "cmpltpd %x,%e" },
      { 2, 5, FIXME,  0, "cmplepd %x,%e" },
      { 3, 5, FIXME,  0, "cmpunordpd %x,%e" },
      { 4, 5, FIXME,  0, "cmpneqpd %x,%e" },
      { 5, 5, FIXME,  0, "cmpnltpd %x,%e" },
      { 6, 5, FIXME,  0, "cmpnlepd %x,%e" },
      { 7, 5, FIXME,  0, "cmpordpd %x,%e" },
      { 0, 0, arnold },
    })},
    { 0xc2, 5, prefix, EA, ((dispblock []) {
      { 0, 5, FIXME,  0, "cmpeqsd %x,%e" },
      { 1, 5, FIXME,  0, "cmpltsd %x,%e" },
      { 2, 5, FIXME,  0, "cmplesd %x,%e" },
      { 3, 5, FIXME,  0, "cmpunordsd %x,%e" },
      { 4, 5, FIXME,  0, "cmpneqsd %x,%e" },
      { 5, 5, FIXME,  0, "cmpnltsd %x,%e" },
      { 6, 5, FIXME,  0, "cmpnlesd %x,%e" },
      { 7, 5, FIXME,  0, "cmpordsd %x,%e" },
      { 0, 0, arnold },
    })},
    { 0xc2, 5, prefix, EA, ((dispblock []) {
      { 0, 5, FIXME,  0, "cmpeqss %x,%e" },
      { 1, 5, FIXME,  0, "cmpltss %x,%e" },
      { 2, 5, FIXME,  0, "cmpless %x,%e" },
      { 3, 5, FIXME,  0, "cmpunordss %x,%e" },
      { 4, 5, FIXME,  0, "cmpneqss %x,%e" },
      { 5, 5, FIXME,  0, "cmpnltss %x,%e" },
      { 6, 5, FIXME,  0, "cmpnless %x,%e" },
      { 7, 5, FIXME,  0, "cmpordss %x,%e" },
      { 0, 0, arnold },
    })},
  })},
  { 0xc3, 5, FIXME,  EA,       "movnti %e,%r" },
  { 0xc4, 5, split2, EA, ((dispblock []) {
    { 0xc4, 5, FIXME,  0,        "pinsrw %m,e,%i" },
    { 0xc4, 5, FIXME,  0,        "pinsrw %x,e,%i" },
  })},
  { 0xc5, 5, split2, EA, ((dispblock []) {
    { 0xc5, 5, FIXME,  0,        "pextrw r,%m,%i" },
    { 0xc5, 5, FIXME,  0,        "pextrw r,%x,%i" },
  })},
  { 0xc6, 5, split2, EA, ((dispblock []) {
    { 0xc6, 5, FIXME,  0,        "shufps r,e,%i" },
    { 0xc6, 5, FIXME,  0,        "shufps r,e,%i" },
  })},
  { 0xc7, 5, subgrp, 0,        sub0FC7disp },
  { 0xc8, 4, inst,   WB,       "bswap %$" },
  { 0xc9, 4, inst,   WB,       "bswap %$" },
  { 0xca, 4, inst,   WB,       "bswap %$" },
  { 0xcb, 4, inst,   WB,       "bswap %$" },
  { 0xcc, 4, inst,   WB,       "bswap %$" },
  { 0xcd, 4, inst,   WB,       "bswap %$" },
  { 0xce, 4, inst,   WB,       "bswap %$" },
  { 0xcf, 4, inst,   WB,       "bswap %$" },

  { 0xd0, 5, split4, EA, ((dispblock []) {
    { 0xd0, 5, unused },
    { 0xd0, 5, FIXME,  0,        "addsubpd r,e" },
    { 0xd0, 5, FIXME,  0,        "addsubps r,e" },
    { 0xd0, 5, unused },
  })},
  { 0xd1, 5, split2, EA, ((dispblock []) {
    { 0xd1, 5, FIXME,  0,        "psrlw r,e" },
    { 0xd1, 5, FIXME,  0,        "psrlw r,e" },
  })},
  { 0xd2, 5, split2, EA, ((dispblock []) {
    { 0xd2, 5, FIXME,  0,        "psrld r,e" },
    { 0xd2, 5, FIXME,  0,        "psrld r,e" },
  })},
  { 0xd3, 5, split2, EA, ((dispblock []) {
    { 0xd3, 5, FIXME,  0,        "psrlq r,e" },
    { 0xd3, 5, FIXME,  0,        "psrlq r,e" },
  })},
  { 0xd4, 5, split2, EA, ((dispblock []) {
    { 0xd4, 5, FIXME,  0,        "paddq r,e" },
    { 0xd4, 5, FIXME,  0,        "paddq r,e" },
  })},
  { 0xd5, 5, split2, EA, ((dispblock []) {
    { 0xd5, 5, FIXME,  0,        "pmullw r,e" },
    { 0xd5, 5, FIXME,  0,        "pmullw r,e" },
  })},
  { 0xd6, 5, split4, EA, ((dispblock []) {
    { 0xd6, 5, unused },
    { 0xd6, 5, FIXME,  0,        "movq e,r" },
    { 0xd6, 5, FIXME,  0,        "movdq2q r,r" },
    { 0xd6, 5, FIXME,  0,        "movq2dq r,r" },
  })},
  { 0xd7, 5, split2, EA, ((dispblock []) {
    { 0xd7, 5, FIXME,  0,        "pmovmskb r,r" },
    { 0xd7, 5, FIXME,  0,        "pmovmskb r,r" },
  })},
  { 0xd8, 5, split2, EA, ((dispblock []) {
    { 0xd8, 5, FIXME,  0,        "psubusb r,e" },
    { 0xd8, 5, FIXME,  0,        "psubusb r,e" },
  })},
  { 0xd9, 5, split2, EA, ((dispblock []) {
    { 0xd9, 5, FIXME,  0,        "psubusw r,e" },
    { 0xd9, 5, FIXME,  0,        "psubusw r,e" },
  })},
  { 0xda, 5, split2, EA, ((dispblock []) {
    { 0xda, 5, FIXME,  0,        "pminub r,e" },
    { 0xda, 5, FIXME,  0,        "pminub r,e" },
  })},
  { 0xdb, 5, split2, EA, ((dispblock []) {
    { 0xdb, 5, FIXME,  0,        "pand r,e" },
    { 0xdb, 5, FIXME,  0,        "pand r,e" },
  })},
  { 0xdc, 5, split2, EA, ((dispblock []) {
    { 0xdc, 5, FIXME,  0,        "paddusb r,e" },
    { 0xdc, 5, FIXME,  0,        "paddusb r,e" },
  })},
  { 0xdd, 5, split2, EA, ((dispblock []) {
    { 0xdd, 5, FIXME,  0,        "paddusw r,e" },
    { 0xdd, 5, FIXME,  0,        "paddusw r,e" },
  })},
  { 0xde, 5, split2, EA, ((dispblock []) {
    { 0xde, 5, FIXME,  0,        "pmaxub r,e" },
    { 0xde, 5, FIXME,  0,        "pmaxub r,e" },
  })},
  { 0xdf, 5, split2, EA, ((dispblock []) {
    { 0xdf, 5, FIXME,  0,        "pandn r,e" },
    { 0xdf, 5, FIXME,  0,        "pandn r,e" },
  })},

  { 0xe0, 5, split2, EA, ((dispblock []) {
    { 0xe0, 5, FIXME,  0,         "pavgb r,e" },
    { 0xe0, 5, FIXME,  0,         "pavgb r,e" },
  })},
  { 0xe1, 5, split2, EA, ((dispblock []) {
    { 0xe1, 5, FIXME,  0,         "psraw r,e" },
    { 0xe1, 5, FIXME,  0,         "psraw r,e" },
  })},
  { 0xe2, 5, split2, EA, ((dispblock []) {
    { 0xe2, 5, FIXME,  0,         "psrad r,e" },
    { 0xe2, 5, FIXME,  0,         "psrad r,e" },
  })},
  { 0xe3, 5, split2, EA, ((dispblock []) {
    { 0xe3, 5, FIXME,  0,         "pavgw r,e" },
    { 0xe3, 5, FIXME,  0,         "pavgw r,e" },
  })},
  { 0xe4, 5, split2, EA, ((dispblock []) {
    { 0xe4, 5, FIXME,  0,         "pmulhuw r,e" },
    { 0xe4, 5, FIXME,  0,         "pmulhuw r,e" },
  })},
  { 0xe5, 5, split2, EA, ((dispblock []) {
    { 0xe5, 5, FIXME,  0,         "pmulhw r,e" },
    { 0xe5, 5, FIXME,  0,         "pmulhw r,e" },
  })},
  { 0xe6, 5, split4, EA, ((dispblock []) {
    { 0xe6, 5, unused },
    { 0xe6, 5, FIXME,  0,         "cvttpd2dq r,e" },
    { 0xe6, 5, FIXME,  0,         "cvtpd2dq r,e" },
    { 0xe6, 5, FIXME,  0,         "cvtdq2pd r,e" },
  })},
  { 0xe7, 5, split2, EA, ((dispblock []) {
    { 0xe7, 5, FIXME,  0,         "movntq m,r" },
    { 0xe7, 5, FIXME,  0,         "movntdq m,r" },
  })},
  { 0xe8, 5, split2, EA, ((dispblock []) {
    { 0xe8, 5, FIXME,  0,         "psubsb r,e" },
    { 0xe8, 5, FIXME,  0,         "psubsb r,e" },
  })},
  { 0xe9, 5, split2, EA, ((dispblock []) {
    { 0xe9, 5, FIXME,  0,         "psubsw r,e" },
    { 0xe9, 5, FIXME,  0,         "psubsw r,e" },
  })},
  { 0xea, 5, split2, EA, ((dispblock []) {
    { 0xea, 5, FIXME,  0,         "pminsw r,e" },
    { 0xea, 5, FIXME,  0,         "pminsw r,e" },
  })},
  { 0xeb, 5, split2, EA, ((dispblock []) {
    { 0xeb, 5, FIXME,  0,         "por r,e" },
    { 0xeb, 5, FIXME,  0,         "por r,e" },
  })},
  { 0xec, 5, split2, EA, ((dispblock []) {
    { 0xec, 5, FIXME,  0,         "paddsb r,e" },
    { 0xec, 5, FIXME,  0,         "paddsb r,e" },
  })},
  { 0xed, 5, split2, EA, ((dispblock []) {
    { 0xed, 5, FIXME,  0,         "paddsw r,e" },
    { 0xed, 5, FIXME,  0,         "paddsw r,e" },
  })},
  { 0xee, 5, split2, EA, ((dispblock []) {
    { 0xee, 5, FIXME,  0,         "pmaxsw r,e" },
    { 0xee, 5, FIXME,  0,         "pmaxsw r,e" },
  })},
  { 0xef, 5, split2, EA, ((dispblock []) {
    { 0xef, 5, FIXME,  0,         "pxor r,e" },
    { 0xef, 5, FIXME,  0,         "pxor r,e" },
  })},

  { 0xf0, 5, split4, EA, ((dispblock []) {
    { 0xf0, 0, unused },
    { 0xf0, 0, unused },
    { 0xf0, 5, FIXME,  0,         "lddqu r,e" },
    { 0xf0, 0, unused },
  })},
  { 0xf1, 5, split2, EA, ((dispblock []) {
    { 0xf1, 5, FIXME,  0,         "psllw r,e" },
    { 0xf1, 5, FIXME,  0,         "psllw r,e" },
  })},
  { 0xf2, 5, split2, EA, ((dispblock []) {
    { 0xf2, 5, FIXME,  0,         "pslld r,e" },
    { 0xf2, 5, FIXME,  0,         "pslld r,e" },
  })},
  { 0xf3, 5, split2, EA, ((dispblock []) {
    { 0xf3, 5, FIXME,  0,         "psllq r,e" },
    { 0xf3, 5, FIXME,  0,         "psllq r,e" },
  })},
  { 0xf4, 5, split2, EA, ((dispblock []) {
    { 0xf4, 5, FIXME,  0,         "pmuludq r,e" },
    { 0xf4, 5, FIXME,  0,         "pmuludq r,e" },
  })},
  { 0xf5, 5, split2, EA, ((dispblock []) {
    { 0xf5, 5, FIXME,  0,         "pmaddwd r,e" },
    { 0xf5, 5, FIXME,  0,         "pmaddwd r,e" },
  })},
  { 0xf6, 5, split2, EA, ((dispblock []) {
    { 0xf6, 5, FIXME,  0,         "psadbw r,e" },
    { 0xf6, 5, FIXME,  0,         "psadbw r,e" },
  })},
  { 0xf7, 5, split2, EA, ((dispblock []) {
    { 0xf7, 5, FIXME,  0,         "maskmovq r,r" },
    { 0xf7, 5, FIXME,  0,         "maskmovdqu r,r" },
  })},
  { 0xf8, 5, split2, EA, ((dispblock []) {
    { 0xf8, 5, FIXME,  0,         "psubb r,e" },
    { 0xf8, 5, FIXME,  0,         "psubb r,e" },
  })},
  { 0xf9, 5, split2, EA, ((dispblock []) {
    { 0xf9, 5, FIXME,  0,         "psubw r,e" },
    { 0xf9, 5, FIXME,  0,         "psubw r,e" },
  })},
  { 0xfa, 5, split2, EA, ((dispblock []) {
    { 0xfa, 5, FIXME,  0,         "psubd r,e" },
    { 0xfa, 5, FIXME,  0,         "psubd r,e" },
  })},
  { 0xfb, 5, split2, EA, ((dispblock []) {
    { 0xfb, 5, FIXME,  0,         "psubq r,e" },
    { 0xfb, 5, FIXME,  0,         "psubq r,e" },
  })},
  { 0xfc, 5, split2, EA, ((dispblock []) {
    { 0xfc, 5, FIXME,  0,         "paddb r,e" },
    { 0xfc, 5, FIXME,  0,         "paddb r,e" },
  })},
  { 0xfd, 5, split2, EA, ((dispblock []) {
    { 0xfd, 5, FIXME,  0,         "paddw r,e" },
    { 0xfd, 5, FIXME,  0,         "paddw r,e" },
  })},
  { 0xfe, 5, split2, EA, ((dispblock []) {
    { 0xfe, 5, FIXME,  0,         "paddd r,e" },
    { 0xfe, 5, FIXME,  0,         "paddd r,e" },
  })},
  { 0xff, 0, unused, 0,        0 },

  /* The following entry should not be there. */

  { 0x00, 0, arnold },
};

/* ---- Floating point opcode tables ---- */

static dispblock fltD8disp[16] = {
  { 0000, 0, inst,   SZ,       "fadd %e" }, /* real32 */
  { 0010, 0, inst,   SZ,       "fmul %e" }, /* real32 */
  { 0020, 0, inst,   SZ,       "fcom %e" }, /* real32 */
  { 0030, 0, inst,   SZ,       "fcomp %e" }, /* real32 */
  { 0040, 0, inst,   SZ,       "fsub %e" }, /* real32 */
  { 0050, 0, inst,   SZ,       "fsubr %e" }, /* real32 */
  { 0060, 0, inst,   SZ,       "fdiv %e" }, /* real32 */
  { 0070, 0, inst,   SZ,       "fdivr %e" }, /* real32 */

  { 0xc0, 0, inst,   0,        "fadd $st,$st(#)" },
  { 0xc8, 0, inst,   0,        "fmul $st,$st(#)" },
  { 0xd0, 0, inst,   0,        "fcom $st,$st(#)" },
  { 0xd8, 0, inst,   0,        "fcomp $st,$st(#)" },
  { 0xe0, 0, inst,   0,        "fsub $st,$st(#)" },
  { 0xe8, 0, inst,   0,        "fsubr $st,$st(#)" },
  { 0xf0, 0, inst,   0,        "fdiv $st,$st(#)" },
  { 0xf8, 0, inst,   0,        "fdivr $st,$st(#)" },
};

static dispblock fltD9D0disp[8] = {
  { 0xd0, 0, inst,   0,        "fnop" },
  { 0xd1, 0, unused },
  { 0xd2, 0, unused },
  { 0xd3, 0, unused },
  { 0xd4, 0, unused },
  { 0xd5, 0, unused },
  { 0xd6, 0, unused },
  { 0xd7, 0, unused },
};

static dispblock fltD9E0disp[8] = {
  { 0xe0, 0, inst,   0,        "fchs" },
  { 0xe1, 0, inst,   0,        "fabs" },
  { 0xe2, 0, unused },
  { 0xe3, 0, unused },
  { 0xe4, 0, inst,   0,        "ftst" },
  { 0xe5, 0, inst,   0,        "fxam" },
  { 0xe6, 0, unused },
  { 0xe7, 0, unused },
};

static dispblock fltD9E8disp[8] = {
  { 0xe8, 0, inst,   0,        "fld1" },
  { 0xe9, 0, inst,   0,        "fld2t" },
  { 0xea, 0, inst,   0,        "fld2e" },
  { 0xeb, 0, inst,   0,        "fldpi" },
  { 0xec, 0, inst,   0,        "fldlg2" },
  { 0xed, 0, inst,   0,        "fldln2" },
  { 0xee, 0, inst,   0,        "fldz" },
  { 0xef, 0, unused },
};

static dispblock fltD9F0disp[8] = {
  { 0xf0, 0, inst,   0,        "f2xm1" },
  { 0xf1, 0, inst,   0,        "fyl2x" },
  { 0xf2, 0, inst,   0,        "fptan" },
  { 0xf3, 0, inst,   0,        "fpatan" },
  { 0xf4, 0, inst,   0,        "fxtract" },
  { 0xf5, 0, inst,   0,        "fprem1" },
  { 0xf6, 0, inst,   0,        "fdecstp" },
  { 0xf7, 0, inst,   0,        "fincstp" },
};

static dispblock fltD9F8disp[8] = {
  { 0xf8, 0, inst,   0,        "fprem" },
  { 0xf9, 0, inst,   0,        "fyl2xp1" },
  { 0xfa, 0, inst,   0,        "fsqrt" },
  { 0xfb, 0, inst,   0,        "fsincos" },
  { 0xfc, 0, inst,   0,        "frndint" },
  { 0xfd, 0, inst,   0,        "fscale" },
  { 0xfe, 0, inst,   0,        "fsin" },
  { 0xff, 0, inst,   0,        "fcos" },
};

static dispblock fltD9disp[16] = {
  { 0000, 0, inst,   SZ,       "fld %e" }, /* real32 */
  { 0010, 0, unused, 0,        0 },
  { 0020, 0, inst,   SZ,       "fst %e" }, /* real32 */
  { 0030, 0, inst,   SZ,       "fstp %e" }, /* real32 */
  { 0040, 0, inst,   0,        "fldenv %e" }, /* ... */
  { 0050, 0, inst,   0,        "fldcw %e" }, /* 2-bytes */
  { 0060, 0, inst,   0,        "fstenv %e" }, /* ... */
  { 0070, 0, inst,   0,        "fstcw %e" }, /* 2-bytes */

  { 0xc0, 0, inst,   0,        "fld $st,$st(#)" },
  { 0xc8, 0, inst,   0,        "fxch $st,$st(#)" },
  { 0xd0, 0, splitf, 0,        fltD9D0disp },
  { 0xd8, 0, unused, 0         0 },
  { 0xe0, 0, splitf, 0,        fltD9E0disp },
  { 0xe8, 0, splitf, 0,        fltD9E8disp },
  { 0xf0, 0, splitf, 0,        fltD9F0disp },
  { 0xf8, 0, splitf, 0,        fltD9F8disp },
};

static dispblock fltDAE8disp[8] = {
  { 0xe8, 0, unused },
  { 0xe9, 0, inst,   0,        "fucompp" },
  { 0xea, 0, unused },
  { 0xeb, 0, unused },
  { 0xec, 0, unused },
  { 0xed, 0, unused },
  { 0xee, 0, unused },
  { 0xef, 0, unused },
};

static dispblock fltDAdisp[16] = {
  { 0000, 0, inst,   SZ,       "fiadd %e" }, /* int32 */
  { 0010, 0, inst,   SZ,       "fimul %e" }, /* int32 */
  { 0020, 0, inst,   SZ,       "ficom %e" }, /* int32 */
  { 0030, 0, inst,   SZ,       "ficomp %e" }, /* int32 */
  { 0040, 0, inst,   SZ,       "fisub %e" }, /* int32 */
  { 0050, 0, inst,   SZ,       "fisubr %e" }, /* int32 */
  { 0060, 0, inst,   SZ,       "fidiv %e" }, /* int32 */
  { 0070, 0, inst,   SZ,       "fidivr %e" }, /* int32 */

  { 0xc0, 0, inst,   0,        "fcmovb $st,$st(#)" },
  { 0xc8, 0, inst,   0,        "fcmove $st,$st(#)" },
  { 0xd0, 0, inst,   0,        "fcmovbe $st,$st(#)" },
  { 0xd8, 0, inst,   0,        "fcmovu $st,$st(#)" },
  { 0xe0, 0, unused },
  { 0xe8, 0, splitf, 0,        fltDAE8disp },
  { 0xf0, 0, unused },
  { 0xf8, 0, unused },
};

static dispblock fltDBE0disp[8] = {
  { 0xe0, 0, unused },
  { 0xe1, 0, unused },
  { 0xe2, 0, inst,   0,        "fclex" },
  { 0xe3, 0, inst,   0,        "finit" },
  { 0xe4, 0, unused },
  { 0xe5, 0, unused },
  { 0xe6, 0, unused },
  { 0xe7, 0, unused },
};

static dispblock fltDBdisp[16] = {
  { 0000, 0, inst,   SZ,       "fild %e" }, /* int32 */
  { 0010, 0, inst,   SZ,       "fisttp %e" }, /* int32 */
  { 0020, 0, inst,   SZ,       "fist %e" }, /* int32 */
  { 0030, 0, inst,   SZ,       "fistp %e" }, /* int32 */
  { 0040, 0, unused },
  { 0050, 0, inst,   SZ,       "fld %e" }, /* real80 */
  { 0060, 0, unused },
  { 0070, 0, inst,   SZ,       "fstp %e" }, /* real80 */

  { 0xc0, 0, inst,   0,        "fcmovnb $st,$st(#)" },
  { 0xc8, 0, inst,   0,        "fcmovne $st,$st(#)" },
  { 0xd0, 0, inst,   0,        "fcmovnbe $st,$st(#)" },
  { 0xd8, 0, inst,   0,        "fcmovnu $st,$st(#)" },
  { 0xe0, 0, splitf, 0,        fltDBE0disp },
  { 0xe8, 0, inst,   0,        "fucomi $st,$st(#)" },
  { 0xf0, 0, inst,   0,        "fcomi $st,$st(#)" },
  { 0xf8, 0, unused },
};

static dispblock fltDCdisp[16] = {
  { 0000, 0, inst,   SZ,       "fadd %e" }, /* real64 */
  { 0010, 0, inst,   SZ,       "fmul %e" }, /* real64 */
  { 0020, 0, inst,   SZ,       "fcom %e" }, /* real64 */
  { 0030, 0, inst,   SZ,       "fcomp %e" }, /* real64 */
  { 0040, 0, inst,   SZ,       "fsub %e" }, /* real64 */
  { 0050, 0, inst,   SZ,       "fsubr %e" }, /* real64 */
  { 0060, 0, inst,   SZ,       "fdiv %e" }, /* real64 */
  { 0070, 0, inst,   SZ,       "fdivr %e" }, /* real64 */

  { 0xc0, 0, inst,   0,        "fadd $st(#),$st" },
  { 0xc8, 0, inst,   0,        "fmul $st(#),$st" },
  { 0xd0, 0, unused },
  { 0xd8, 0, unused },
  { 0xe0, 0, inst,   0,        "fsub $st(#),$st" },
  { 0xe8, 0, inst,   0,        "fsubr $st(#),$st" },
  { 0xf0, 0, inst,   0,        "fdiv $st(#),$st" },
  { 0xf8, 0, inst,   0,        "fdivr $st(#),$st" },
};

static dispblock fltDDdisp[16] = {
  { 0000, 0, inst,   SZ,       "fld %e" }, /* real64 */
  { 0010, 0, inst,   SZ,       "fisttp %e" }, /* int64 */
  { 0020, 0, inst,   SZ,       "fst %e" }, /* real64 */
  { 0030, 0, inst,   SZ,       "fstp %e" }, /* real64 */
  { 0040, 0, inst,   0,        "frstor %e" }, /* <block> */
  { 0050, 0, unused },
  { 0060, 0, inst,   0,        "fnsave %e" }, /* <block> */
  { 0070, 0, inst,   SZ,       "fnstsw %e" }, /* 2-bytes */

  { 0xc0, 0, inst,   0,        "ffree $st(#)" },
  { 0xc8, 0, unused },
  { 0xd0, 0, inst,   0,        "fst $st(#)" },
  { 0xd8, 0, inst,   0,        "fstp $st(#)" },
  { 0xe0, 0, inst,   0,        "fucom $st(#)" },
  { 0xe8, 0, inst,   0,        "fucomp $st(#)" },
  { 0xf0, 0, unused },
  { 0xf8, 0, unused },
};

static dispblock fltDED8disp[8] = {
  { 0xd8, 0, unused },
  { 0xd9, 0, inst,   0,        "fcompp" },
  { 0xda, 0, unused },
  { 0xdb, 0, unused },
  { 0xdc, 0, unused },
  { 0xdd, 0, unused },
  { 0xde, 0, unused },
  { 0xdf, 0, unused },
};

static dispblock fltDEdisp[16] = {
  { 0000, 0, inst,   0,        "fiadd %e" }, /* int16 */
  { 0010, 0, inst,   0,        "fimul %e" }, /* int16 */
  { 0020, 0, inst,   0,        "ficom %e" }, /* int16 */
  { 0030, 0, inst,   0,        "ficomp %e" }, /* int16 */
  { 0040, 0, inst,   0,        "fisub %e" }, /* int16 */
  { 0050, 0, inst,   0,        "fisubr %e" }, /* int16 */
  { 0060, 0, inst,   0,        "fidiv %e" }, /* int16 */
  { 0070, 0, inst,   0,        "fidivr %e" }, /* int16 */

  { 0xc0, 0, inst,   0,        "faddp $st(#),$st" },
  { 0xc8, 0, inst,   0,        "fmulp $st(#),$st" },
  { 0xd0, 0, unused },
  { 0xd8, 0, splitf, 0,        fltDED8disp },
  { 0xe0, 0, inst,   0,        "fsubrp $st(#),$st" },
  { 0xe8, 0, inst,   0,        "fsubp $st(#),$st" },
  { 0xf0, 0, inst,   0,        "fdivrp $st(#),$st" },
  { 0xf8, 0, inst,   0,        "fdivp $st(#),$st" },
};

static dispblock fltDFE0disp[8] = {
  { 0xe0, 0, inst,   0,        "fnstsw $ax" },
  { 0xe1, 0, unused },
  { 0xe2, 0, unused },
  { 0xe3, 0, unused },
  { 0xe4, 0, unused },
  { 0xe5, 0, unused },
  { 0xe6, 0, unused },
  { 0xe7, 0, unused },
};

static dispblock fltDFdisp[16] = {
  { 0000, 0, inst,   0,        "fild %e" }, /* int16 */
  { 0010, 0, inst,   0,        "fisttp %e" }, /* int16 */
  { 0020, 0, inst,   0,        "fist %e" }, /* int16 */
  { 0030, 0, inst,   0,        "fistp %e" }, /* int16 */
  { 0040, 0, inst,   0,        "fbld %e" }, /* BCD */
  { 0050, 0, inst,   SZ,       "fild %e" }, /* int64 */
  { 0060, 0, inst,   0,        "fbstp %e" }, /* BCD */
  { 0070, 0, inst,   SZ,       "fistp %e" }, /* int64 */
  { 0xc0, 0, unused },
  { 0xc8, 0, unused },
  { 0xd0, 0, unused },
  { 0xd8, 0, unused },
  { 0xe0, 0, splitf, 0,        fltDFE0disp },
  { 0xe8, 0, inst,   0,        "fucomip $st,$st(#)" },
  { 0xf0, 0, inst,   0,        "fcomip $st,$st(#)" },
  { 0xf8, 0, unused },
};

/* ---- Main opcode table ---- */

static dispblock maindisp[256] = {
  { 0x00, 0, instb,  EA,       "add %e,%r" },
  { 0x01, 0, instw,  EA+WB,    "add %e,%r" },
  { 0x02, 0, instb,  EA,       "add %r,%e" },
  { 0x03, 0, instw,  EA+WB,    "add %r,%e" },
  { 0x04, 0, inst,   0,        "add $al,%1" },
  { 0x05, 0, inst,   WB,       "add $ax,%2" },
  { 0x06, 0, inst,   X64,      "push $es" },
  { 0x07, 0, inst,   X64,      "pop $es" },
  { 0x08, 0, instb,  EA,       "or %e,%r" },
  { 0x09, 0, instw,  EA+WB,    "or %e,%r" },
  { 0x0a, 0, instb,  EA,       "or %r,%e" },
  { 0x0b, 0, instw,  EA+WB,    "or %r,%e" },
  { 0x0c, 0, inst,   0,        "or $al,%1" },
  { 0x0d, 0, inst,   WB,       "or $ax,%2" },
  { 0x0e, 0, inst,   X64,      "push $cs" },
  { 0x0f, 0, prefix, 0,        pfx0Fdisp },

  { 0x10, 0, instb,  EA,       "adc %e,%r" },
  { 0x11, 0, instw,  EA+WB,    "adc %e,%r" },
  { 0x12, 0, instb,  EA,       "adc %r,%e" },
  { 0x13, 0, instw,  EA+WB,    "adc %r,%e" },
  { 0x14, 0, inst,   0,        "adc $al,%1" },
  { 0x15, 0, inst,   WB,       "adc $ax,%2" },
  { 0x16, 0, inst,   X64,      "push $ss" },
  { 0x17, 0, inst,   X64,      "pop $ss" },
  { 0x18, 0, instb,  EA,       "sbb %e,%r" },
  { 0x19, 0, instw,  EA+WB,    "sbb %e,%r" },
  { 0x1a, 0, instb,  EA,       "sbb %r,%e" },
  { 0x1b, 0, instw,  EA+WB,    "sbb %r,%e" },
  { 0x1c, 0, inst,   0,        "sbb $al,%1" },
  { 0x1d, 0, inst,   WB,       "sbb $ax,%2" },
  { 0x1e, 0, inst,   X64,      "push $ds" },
  { 0x1f, 0, inst,   X64,      "pop $ds" },

  { 0x20, 0, instb,  EA,       "and %e,%r" },
  { 0x21, 0, instw,  EA+WB,    "and %e,%r" },
  { 0x22, 0, instb,  EA,       "and %r,%e" },
  { 0x23, 0, instw,  EA+WB,    "and %r,%e" },
  { 0x24, 0, inst,   0,        "and $al,%1" },
  { 0x25, 0, inst,   WB,       "and $ax,%2" },
  { 0x26, 0, pfxseg, 0,        0 },   /* segment prefix, es: */
  { 0x27, 0, inst,   X64,      "daa" },
  { 0x28, 0, instb,  EA,       "sub %e,%r" },
  { 0x29, 0, instw,  EA+WB,    "sub %e,%r" },
  { 0x2a, 0, instb,  EA,       "sub %r,%e" },
  { 0x2b, 0, instw,  EA+WB,    "sub %r,%e" },
  { 0x2c, 0, inst,   0,        "sub $al,%1" },
  { 0x2d, 0, inst,   WB,       "sub $ax,%2" },
  { 0x2e, 0, pfxseg, 0,        0 },   /* segment prefix, cs: */
  { 0x2f, 0, inst,   X64,      "das" },

  { 0x30, 0, instb,  EA,       "xor %e,%r" },
  { 0x31, 0, instw,  EA+WB,    "xor %e,%r" },
  { 0x32, 0, instb,  EA,       "xor %r,%e" },
  { 0x33, 0, instw,  EA+WB,    "xor %r,%e" },
  { 0x34, 0, inst,   0,        "xor $al,%1" },
  { 0x35, 0, inst,   WB,       "xor $ax,%2" },
  { 0x36, 0, pfxseg, 0,        0 },   /* segment prefix, ss: */
  { 0x37, 0, inst,   X64,      "aaa" },
  { 0x38, 0, instb,  EA,       "cmp %e,%r" },
  { 0x39, 0, instw,  EA+WB,    "cmp %e,%r" },
  { 0x3a, 0, instb,  EA,       "cmp %r,%e" },
  { 0x3b, 0, instw,  EA+WB,    "cmp %r,%e" },
  { 0x3c, 0, inst,   0,        "cmp $al,%1" },
  { 0x3d, 0, inst,   WB,       "cmp $ax,%2" },
  { 0x3e, 0, pfxseg, 0,        0 },   /* segment prefix, ds: */
  { 0x3f, 0, inst,   X64,      "aas" },

  { 0x40, 0, inst,   WB+X64,   "inc $ax" },
  { 0x41, 0, inst,   WB+X64,   "inc $cx" },
  { 0x42, 0, inst,   WB+X64,   "inc $dx" },
  { 0x43, 0, inst,   WB+X64,   "inc $bx" },
  { 0x44, 0, inst,   WB+X64,   "inc $sp" },
  { 0x45, 0, inst,   WB+X64,   "inc $bp" },
  { 0x46, 0, inst,   WB+X64,   "inc $si" },
  { 0x47, 0, inst,   WB+X64,   "inc $di" },
  { 0x48, 0, inst,   WB+X64,   "dec $ax" },
  { 0x49, 0, inst,   WB+X64,   "dec $cx" },
  { 0x4a, 0, inst,   WB+X64,   "dec $dx" },
  { 0x4b, 0, inst,   WB+X64,   "dec $bx" },
  { 0x4c, 0, inst,   WB+X64,   "dec $sp" },
  { 0x4d, 0, inst,   WB+X64,   "dec $bp" },
  { 0x4e, 0, inst,   WB+X64,   "dec $si" },
  { 0x4f, 0, inst,   WB+X64,   "dec $di" },

  { 0x50, 0, inst,   WB,       "push %$" },
  { 0x51, 0, inst,   WB,       "push %$" },
  { 0x52, 0, inst,   WB,       "push %$" },
  { 0x53, 0, inst,   WB,       "push %$" },
  { 0x54, 0, inst,   WB,       "push %$" },
  { 0x55, 0, inst,   WB,       "push %$" },
  { 0x56, 0, inst,   WB,       "push %$" },
  { 0x57, 0, inst,   WB,       "push %$" },
  { 0x58, 0, inst,   WB,       "pop %$" },
  { 0x59, 0, inst,   WB,       "pop %$" },
  { 0x5a, 0, inst,   WB,       "pop %$" },
  { 0x5b, 0, inst,   WB,       "pop %$" },
  { 0x5c, 0, inst,   WB,       "pop %$" },
  { 0x5d, 0, inst,   WB,       "pop %$" },
  { 0x5e, 0, inst,   WB,       "pop %$" },
  { 0x5f, 0, inst,   WB,       "pop %$" },

  { 0x60, 2, inst,   X64,      "pusha" },
  { 0x61, 2, inst,   X64,      "popa" },
  { 0x62, 2, inst2w, EA+WB+X64,"bound %r%,%e" }, /* Yes, that's %, */
  { 0x63, 2, inst,   EA+WB+X64,"arpl %e,%r" },
  { 0x64, 3, pfxseg, 0,        0 },     /* segment prefix, fs: */
  { 0x65, 3, pfxseg, 0,        0 },     /* segment prefix, gs: */
  { 0x66, 3, pfx32d, 0,        0 },	/* prefix, register size = 32. */
  { 0x67, 3, pfx32a, 0,        0 },	/* prefix, address size = 32. */
  { 0x68, 0, inst,   0,        "push %2" },
  { 0x69, 1, instw,  EA+WB,    "imul %r,%e,%2" },
  { 0x6a, 0, inst,   0,        "push %1" },
  { 0x6b, 1, instw,  EA+WB+SX, "imul %r,%e,%1" },
  { 0x6c, 2, inst,   0,        "insb" },
  { 0x6d, 2, inst,   WB,       "insw" }, /* %s? */
  { 0x6e, 0, inst,   0,        "outsb" },
  { 0x6f, 0, inst,   WB,       "outsw" }, /* %s? */

  /* conditional jumps with short (8-bit) displacements: */

  { 0x70, 0, pushj,  0,        "j? %d" },
  { 0x71, 0, pushj,  0,        "j? %d" },
  { 0x72, 0, pushj,  0,        "j? %d" },
  { 0x73, 0, pushj,  0,        "j? %d" },
  { 0x74, 0, pushj,  0,        "j? %d" },
  { 0x75, 0, pushj,  0,        "j? %d" },
  { 0x76, 0, pushj,  0,        "j? %d" },
  { 0x77, 0, pushj,  0,        "j? %d" },
  { 0x78, 0, pushj,  0,        "j? %d" },
  { 0x79, 0, pushj,  0,        "j? %d" },
  { 0x7a, 0, pushj,  0,        "j? %d" },
  { 0x7b, 0, pushj,  0,        "j? %d" },
  { 0x7c, 0, pushj,  0,        "j? %d" },
  { 0x7d, 0, pushj,  0,        "j? %d" },
  { 0x7e, 0, pushj,  0,        "j? %d" },
  { 0x7f, 0, pushj,  0,        "j? %d" },

  { 0x80, 0, subgrp, 0,        sub80disp },
  { 0x81, 0, subgrp, WB,       sub80disp },
  { 0x82, 0, subgrp, SX+X64,   sub80disp },
  { 0x83, 0, subgrp, WB+SX,    sub80disp },
  { 0x84, 0, instb,  EA,       "test %r,%e" },
  { 0x85, 0, instw,  EA+WB,    "test %r,%e" },
  { 0x86, 0, instb,  EA,       "xchg %r,%e" },
  { 0x87, 0, instw,  EA+WB,    "xchg %r,%e" },
  { 0x88, 0, instb,  EA,       "mov %e,%r" },
  { 0x89, 0, instw,  EA+WB,    "mov %e,%r" },
  { 0x8a, 0, instb,  EA,       "mov %r,%e" },
  { 0x8b, 0, instw,  EA+WB,    "mov %r,%e" },
  { 0x8c, 0, instw,  EA+WB,    "mov %e,%s" },
  { 0x8d, 0, inst,   EA+WB,    "lea %r,%e" }, /* WB => 16-bit reg. */
  { 0x8e, 0, instw,  EA+WB,    "mov %s,%e" },
  { 0x8f, 0, instw,  EA+WB,    "pop %e" },

  { 0x90, 0, inst,   0,        "nop" },	/* Needs check for REX and/or PF3  */
  { 0x91, 0, inst,   WB,       "xchg $ax,$cx" },
  { 0x92, 0, inst,   WB,       "xchg $ax,$dx" },
  { 0x93, 0, inst,   WB,       "xchg $ax,$bx" },
  { 0x94, 0, inst,   WB,       "xchg $ax,$sp" },
  { 0x95, 0, inst,   WB,       "xchg $ax,$bp" },
  { 0x96, 0, inst,   WB,       "xchg $ax,$si" },
  { 0x97, 0, inst,   WB,       "xchg $ax,$di" },
  { 0x98, 0, inst,   0,        "cbw" },	/* Needs size split-up. */
  { 0x99, 0, inst,   0,        "cwd" },	/* Needs size split-up. */
  { 0x9a, 0, pushj,  X64,      "call %:" },
  { 0x9b, 0, inst,   0,        "wait" },
  { 0x9c, 0, inst,   0,        "pushf" },
  { 0x9d, 0, inst,   0,        "popf" },
  { 0x9e, 0, inst,   X64,      "sahf" },
  { 0x9f, 0, inst,   X64,      "lahf" },

  { 0xa0, 0, instb,  0,        "mov $al,%a" },
  { 0xa1, 0, instw,  WB,       "mov $ax,%a" },
  { 0xa2, 0, instb,  0,        "mov %a,$al" },
  { 0xa3, 0, instw,  WB,       "mov %a,$ax" },
  { 0xa4, 0, inst,   0,        "movsb" },
  { 0xa5, 0, inst,   0,        "movsw" },
  { 0xa6, 0, inst,   0,        "cmpsb" },
  { 0xa7, 0, inst,   0,        "cmpsw" }, /* %s? */
  { 0xa8, 0, inst,   0,        "test $al,%1" },
  { 0xa9, 0, inst,   WB,       "test $ax,%2" },
  { 0xaa, 0, inst,   0,        "stosb" },
  { 0xab, 0, inst,   0,        "stosw" }, /* %s? */
  { 0xac, 0, inst,   0,        "lodsb" },
  { 0xad, 0, inst,   0,        "lodsw" }, /* %s? */
  { 0xae, 0, inst,   0,        "scasb" },
  { 0xaf, 0, inst,   0,        "scasw" }, /* %s? */

  { 0xb0, 0, inst,   0,        "mov %$,%1" },
  { 0xb1, 0, inst,   0,        "mov %$,%1" },
  { 0xb2, 0, inst,   0,        "mov %$,%1" },
  { 0xb3, 0, inst,   0,        "mov %$,%1" },
  { 0xb4, 0, inst,   0,        "mov %$,%1" },
  { 0xb5, 0, inst,   0,        "mov %$,%1" },
  { 0xb6, 0, inst,   0,        "mov %$,%1" },
  { 0xb7, 0, inst,   0,        "mov %$,%1" },
  { 0xb8, 0, inst,   WB,       "mov %$,%2" },
  { 0xb9, 0, inst,   WB,       "mov %$,%2" },
  { 0xba, 0, inst,   WB,       "mov %$,%2" },
  { 0xbb, 0, inst,   WB,       "mov %$,%2" },
  { 0xbc, 0, inst,   WB,       "mov %$,%2" },
  { 0xbd, 0, inst,   WB,       "mov %$,%2" },
  { 0xbe, 0, inst,   WB,       "mov %$,%2" },
  { 0xbf, 0, inst,   WB,       "mov %$,%2" },

  { 0xc0, 1, subgrp, 0,        subC0disp },
  { 0xc1, 1, subgrp, WB,       subC0disp },
  { 0xc2, 0, popj,   0,        "ret %2" },
  { 0xc3, 0, popj,   0,        "ret" },
  { 0xc4, 0, inst,   EA+WB+X64,  "les %r,%e" },	/* VEX prefix... */
  { 0xc5, 0, inst,   EA+WB+X64,  "lds %r,%e" },	/* VEX prefix... */
  { 0xc6, 0, instb,  EA+SZ,    "mov %e,%1" },
  { 0xc7, 0, instw,  EA+SZ+WB, "mov %e,%2" },
  { 0xc8, 2, inst,   0,        "enter %2%,%1" }, /* Yes, that's %, */
  { 0xc9, 2, inst,   0,        "leave" },
  { 0xca, 0, popj,   0,        "retf %2" },
  { 0xcb, 0, popj,   0,        "retf" },
  { 0xcc, 0, inst,   0,        "int 3" },
  { 0xcd, 0, inst,   0,        "int %1" },
  { 0xce, 0, inst,   X64,      "into" },
  { 0xcf, 0, popj,   0,        "iret" },

  { 0xd0, 0, subgrp, 0,        subD0disp },
  { 0xd1, 0, subgrp, WB,       subD0disp },
  { 0xd2, 0, subgrp, 0,        subD2disp },
  { 0xd3, 0, subgrp, WB,       subD2disp },
  { 0xd4, 0, inst,   X64,      "aam %1" },
  { 0xd5, 0, inst,   X64,      "aad %1" },
  { 0xd6, 0, unused, 0,        0 }, /* SALC (undoc.) but not in 64-bit mode */
  { 0xd7, 0, inst,   0,        "xlat" },
  { 0xd8, 0, float,  0,        fltD8disp },
  { 0xd9, 0, float,  0,        fltD9disp },
  { 0xda, 0, float,  0,        fltDAdisp },
  { 0xdb, 0, float,  0,        fltDBdisp },
  { 0xdc, 0, float,  0,        fltDCdisp },
  { 0xdd, 0, float,  0,        fltDDdisp },
  { 0xde, 0, float,  0,        fltDEdisp },
  { 0xdf, 0, float,  0,        fltDFdisp },

  /* 8-bit disps.  Can have REX.  Investigate. */

  { 0xe0, 0, pushj,  0,        "loopnz %d" },
  { 0xe1, 0, pushj,  0,        "loopz %d" },
  { 0xe2, 0, pushj,  0,        "loop %d" },
  { 0xe3, 0, pushj,  0,        "jcxz %d" },
  { 0xe4, 0, inst,   0,        "in $al,%1" },
  { 0xe5, 0, inst,   WB,       "in $ax,%1" },
  { 0xe6, 0, inst,   0,        "out $al,%1" },
  { 0xe7, 0, inst,   WB,       "out $ax,%1" },
  { 0xe8, 0, pushj,  WB,       "call %d" },
  { 0xe9, 0, jrst,   WB,       "jmp %d" }, /* 32-bit displacement. */
  { 0xea, 0, jrst,   WB+X64,   "jmp %:" },
  { 0xeb, 0, jrst,   0,        "jmp %d" }, /* 8-bit displacement. */
  { 0xec, 0, inst,   0,        "in $al,$cx" },
  { 0xed, 0, inst,   WB,       "in $ax,$cx" },
  { 0xee, 0, inst,   0,        "out $al,$cx" },
  { 0xef, 0, inst,   WB,       "out $ax,$cx" },

  { 0xf0, 0, inst,   0,        "lock" }, /* pref? */
  { 0xf1, 0, unused, 0,        0 },
  { 0xf2, 0, inst,   0,        "rep" },	/* pref? */
  { 0xf3, 0, inst,   0,        "repz" }, /* pref? */
  { 0xf4, 0, inst,   0,        "hlt" },
  { 0xf5, 0, inst,   0,        "cmc" },
  { 0xf6, 0, subgrp, 0,        subF6disp },
  { 0xf7, 0, subgrp, WB,       subF6disp },
  { 0xf8, 0, inst,   0,        "clc" },
  { 0xf9, 0, inst,   0,        "stc" },
  { 0xfa, 0, inst,   0,        "cli" },
  { 0xfb, 0, inst,   0,        "sti" },
  { 0xfc, 0, inst,   0,        "cld" },
  { 0xfd, 0, inst,   0,        "std" },
  { 0xfe, 0, subgrp, 0,        subFEdisp },
  { 0xff, 0, subgrp, WB,       subFFdisp },
};

/*
 *  Opcodes that are different in 64-bit mode.  Lookup things here
 *  when we find the X64 bit set in the main table.
 */

static dispblock main64disp[] = {

  /* These should be done differently */

  { 0x40, 0, inst,   0,        "rex" },
  { 0x41, 0, inst,   0,        "rex.b" },
  { 0x42, 0, inst,   0,        "rex.x" },
  { 0x43, 0, inst,   0,        "rex.xb" },
  { 0x44, 0, inst,   0,        "rex.r" },
  { 0x45, 0, inst,   0,        "rex.rb" },
  { 0x46, 0, inst,   0,        "rex.rx" },
  { 0x47, 0, inst,   0,        "rex.rxb" },
  { 0x48, 0, inst,   0,        "rex.w" },
  { 0x49, 0, inst,   0,        "rex.wb" },
  { 0x4a, 0, inst,   0,        "rex.wx" },
  { 0x4b, 0, inst,   0,        "rex.wxb" },
  { 0x4c, 0, inst,   0,        "rex.wr" },
  { 0x4d, 0, inst,   0,        "rex.wrb" },
  { 0x4e, 0, inst,   0,        "rex.wrx" },
  { 0x4f, 0, inst,   0,        "rex.wrxb" },

  /* 0x63 -- MOVSXD */

  /* 0xc4 -- VEX */
  /* 0xc5 -- VEX */

  { 0x00, 0, arnold },
};

/*
 *  Ununsed, but if we are to do the NEC V25...
 */

#ifdef NEC

static dispblock v25disp[] = {
  { 0x9c, 0, inst,   0,        "btclr %1,%1,%d" },
  /* btclr <spc-fnc-reg>, <bit-num>, <disp-8> */
  { 0x25, 0, inst,   0,        "movspa" },
  { 0x2d, 0, inst,   WB,       "brkcs %v" },
  { 0x91, 0, inst,   0,        "retrbi" },
  { 0x92, 0, inst,   0,        "fint" },
  { 0x94, 0, inst,   WB,       "tsksw %v" },
  { 0x95, 0, inst,   WB,       "movspb %v" },
  { 0x9e, 0, inst,   0,        "stop" },
  { 0x00, 0, arnold },
};

#endif /* NEC */

/************************************************************************/

/*
 *  Floating point tables:
 */

/*
 *  D8:
 *
 *  D9:
 *
 *  DA:
 *
 *  DB:
 *
 *  DC:
 *
 *  DD:
 *
 *  DE:
 *
 *  DF:
 *
 */

/************************************************************************/

