#include <stdio.h>

struct foo {
  short tag;
  char length;
  char type;
  unsigned int bits;
  char* expand;
};

void fixup(struct foo f[], int item)
{
  struct foo* this;

  this = &f[item];

  this->tag = 4711;
  this->length = 42;
  this->type = 17;
  this->bits |= 0x4000;
}

void* foo;
void* bar;

#define S2VP(arg) ((void*) (((char*) 0) + arg))
#define VP2S(arg) ((short) (((char*) arg) - ((char*) 0)))

int main(int argc, char* argv[])
{
  short allan = 17, kaka = 42;

  foo = S2VP(allan);
  bar = (void*) kaka;

  allan = (short) bar;
  kaka = VP2S(foo);

  printf("allan = %d, kaka = %d\n", allan, kaka);

  allan = ((unsigned short) bar) % 11;
  kaka = ((unsigned short) VP2S(foo)) % 11;

  printf("allan = %d, kaka = %d\n", allan, kaka);
}
