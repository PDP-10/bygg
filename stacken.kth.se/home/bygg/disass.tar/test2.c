#include <stdio.h>
#include <string.h>

int main(int argc, char* argv[])
{
  char foo[] = "allan, tar, en, kaka";

  char* item;

  for (item = strtok(foo, ", "); item != NULL; item = strtok(NULL, ", ")) {
    printf("item = \"%s\"\n", item);
  }
}
