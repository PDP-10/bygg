
/*  Make code to call XSetErrorHandler & XSetIOErrorHandler */

/*
** This module implements X window junk.
*/

#include "comnd.h"
#include "disass.h"

/*
** X related include files:
*/

#include <X11/Xlib.h>
#include <X11/Xutil.h>

#include <unistd.h>
#include <sys/time.h>
#include <sys/types.h>

/*
** Local data structures:
*/

typedef struct windowblock {
  struct windowblock* next;	/* Links and rechts in the list. */
  struct windowblock* prev;
  winindex index;		/* Unique index, for ext. refs. */
  int wintype;			/* What type of window we are. */
  char* name;			/* Window name. */

  Window id;			/* id for Xlib. */
  int width;			/* Size in pixels. */
  int height;
  int x, y;			/* Position on screen. */

  bool messed;			/* If our image is messed up. */
  bool mapped;			/* If we are mapped onto the screen. */
  
  bool relocflag;		/* Relocating ourselves? */
  int relocx, relocy;		/* Offsets. */

  bool followed;		/* Are we being followed? */
  struct windowblock* target;	/* Window we are folloing. */

  address* first;		/* First address in window. */
  address* last;		/* Last address in window. */
  bool lastmapped;		/* Is win->last mapped in? */

  /* handlers etc. */

  void (*updater)(struct windowblock* win);

} windowblock;

/*
** Global variables we know about.
*/

static Display* display = NULL;
static int screen;
static GC gc;
static XFontStruct* font;
static int fontheight;
static int fontwidth;

static unsigned long standoutbackg;
static unsigned long standoutcolor;
static char* colorname = NULL;

static XTextProperty windowname;
static XTextProperty iconname;

static char inputbuffer[20];
static int inputpos;
static int inputcount = 0;

static int tfd;			/* Terminal file descriptor. */
static int xfd;			/* X window file descriptor. */

static winindex lastindex = 0;	/* Unique index. */

/* foo */

static jmp_buf rubber;		/* Try to implement safe X. */

static bool repaint;

static bool totalmess;

static windowblock* windowlist = NULL;
static windowblock* windowlast = NULL;

static windowblock* defaultwindow = NULL;

/************************************************************************/

static char* wty2name(int wintype)
{
  switch (wintype) {
    case wty_counters:   return "counters";
    case wty_dump:       return "data-dump";
    case wty_highlight:  return "highlight";
    case wty_listing:    return "listing";
    case wty_logger:     return "logger";
    case wty_notes:      return "notes";
    case wty_register:   return "register";
    case wty_status:     return "status";
    case wty_symbols:    return "symbols";
    case wty_windows:    return "windows";
    case wty_dots:       return "dots";
    case wty_patterns:   return "patterns";
    case wty_hexdump:    return "hexdump";
    case wty_rpn:        return "rpn";
    case wty_source:     return "source";
    case wty_modules:    return "modules";
    case wty_processors: return "processors";
    case wty_fields:     return "field hints";
    case wty_attributes: return "attributes";
  }
  return "unknown";
}

static windowblock* findwinindex(winindex index)
{
  windowblock* wb;

  wb = windowlist;
  while (wb != NULL) {
    if (wb->index == index) {
      return wb;
    }
    wb = wb->next;
  }
  return NULL;
}

static windowblock* findwinblock(Window win)
{
  windowblock* wb;

  wb = windowlist;
  while (wb != NULL) {
    if (wb->id == win) {
      return wb;
    }
    wb = wb->next;
  }
  return NULL;
}

static windowblock* argwindow(winindex index)
{
  if (index == 0) {
    if (defaultwindow != NULL) {
      return defaultwindow;
    }
    return windowlist;
  }
  return findwinindex(index);
}

static windowblock* makewinblock(int wintype)
{
  windowblock* win;
  char work[100];

  win = malloc(sizeof(windowblock));

  win->next = NULL;
  win->prev = windowlast;
  if (windowlast != NULL) {
    windowlast->next = win;
    windowlast = win;
  } else {
    windowlist = win;
    windowlast = win;
  }

  win->wintype = wintype;

  lastindex += 1;
  win->index = lastindex;

  win->mapped = false;
  win->messed = false;

  win->relocflag = false;

  win->first = NULL;
  win->last = NULL;
  win->lastmapped = false;

  win->followed = false;
  win->target = NULL;

  sprintf(work, "disass %s (%u)", wty2name(win->wintype), win->index);
  win->name = copystring(work, NULL);

  return win;
}

static void freewinblock(windowblock* win)
{
  windowblock* fw;

  if (win == defaultwindow) {	/* Deleting default window? */
    defaultwindow = NULL;	/* Yes, forget default. */
  }

  if (win->prev == NULL) {	/* First in list? */
    windowlist = win->next;	/* Yes. */
  } else {
    win->prev->next = win->next; /* No. */
  }
  if (win->next == NULL) {	/* Last in list? */
    windowlast = win->prev;	/* Yes. */
  } else {
    win->next->prev = win->prev; /* No. */
  }

  win->first = a_copy(NULL, win->first);	/* Zap addresses. */
  win->last = a_copy(NULL, win->last);

  win->name = copystring(NULL, win->name); /* Zap name. */

  /* XXX
  **   if we are being followed we MUST recompute the follow structs.
  **   if we are following others, we SHOULD.
  */

  if (win->followed) {
    for (fw = windowlist; fw != NULL; fw = fw->next) {
      if (fw->target == win) {
	fw->target = NULL;
      }
    }
  }

  free(win);
  wc_windows();
}

/**********************************************************************/

#define buffersize 100

static windowblock* workwin;	/* Window we are printing into. */

static bool wwmode = false;	/* If we are writing at the moment. */

static char buffer[buffersize]; /* The actual text buffer. */
static int bufcount;		/* Number of chars in buffer. */
static int wintotal;		/* Total chars on line. */
static int winxpos;		/* Where on line to start printing. */
static int winypos;		/* ... */
static int winmax;		/* Max number of chars on one line. */

static bool peekstop;		/* Stop, the window is full... */

/*
** dumpbuffer() dumps the contents of the text buffer onto the screen.
*/

static void dumpbuffer(void)
{
  if (bufcount > 0) {
    XDrawImageString(display, workwin->id, gc,
		     winxpos, winypos, buffer, bufcount);
    winxpos += fontwidth * bufcount;
    bufcount = 0;
  }
}

/*
** drawnewline() handles newlines, by clearing to end of line, and resetting
** some variables.
*/

static void drawnewline(void)
{
  dumpbuffer();

  winypos += fontheight;
  if (winypos > workwin->height) {
    peekstop = true;
  }
  winxpos = 2;
  wintotal = 0;
}

/*
** drawchar() gives one more char to the buffer.
*/

static void drawchar(char c)
{
  if (c == '\n') {
    while (wintotal < winmax) {
      drawchar(' ');
    }
    drawnewline();
  } else {
    if (bufcount >= buffersize) { /* Still more room? */
      dumpbuffer();		/* No, make some. */
    }
    buffer[bufcount] = c;
    bufcount += 1;
    wintotal += 1;
  }
}

/**********************************************************************/

static void drawarray(byte* data, int len)
{
  int i;
  byte b;

  drawchar('"');
  for(i = 0; i < len; i += 1) {
    b = data[i];
    if ((b < 32) || (b >= 127)) {
      b = 1;
    }
    drawchar(b);
  }
  drawchar('"');
}

/*
** wwbegin() sets up text output to the specified window.
*/

static void wwbegin(windowblock* win)
{
  bufxset(true);
  workwin = win;
  wwmode = true;
  bufcount = 0;
  wintotal = 0;
  winmax = win->width / fontwidth;
  winxpos = 2;
  winypos = fontheight + 2;
  peekstop = false;
}

/*
** wwend() resets things after window text output.
*/

static void wwend(void)
{
  while (!peekstop) {
    drawchar('\n');
  }
  wwmode = false;
  bufxset(false);
}

/*
 *  wincheckaddress() checks if we have an address, tries to set a
 *  good default if not.
 */

static bool wincheckaddress(windowblock* win)
{
  segment* seg;
  address* addr;

  if (win->first != NULL)
    return true;

  seg = seg_head();
  if (seg == NULL)
    return false;

  addr = seg_first(seg);
  if (addr == NULL)
    return false;

  win->first = a_copy(addr, win->first);
  return true; 
}

/*
** winpeek() performs updates for {source|listing} windows.
*/

static void winpeek(windowblock* win, bool listing)
{
  static address* pos = NULL;
  int format;

  format = listing? EX_LIST : EX_ASM;

  if (processor == NULL) {
    return;
  }

  if (wincheckaddress(win)) {
    pos = a_copy(win->first, pos);
    while(mapped(pos)) {
      if (peekstop) {
	break;
      }
      peek(pos, format, st_none);
      a_inc(pos, pb_length * pv_bpa);
    }
    if (peekstop) {
      win->last = a_copy(pos, win->last);
      win->lastmapped = true;
    } else {
      win->lastmapped = false;
    }
  }
}

/*
 *  winlisting() performs updates for listing windows.
 */

static void winlisting(windowblock* win)
{
  winpeek(win, true);
}

/*
 *  winsource() performs updates for source windows.
 */

static void winsource(windowblock* win)
{
  winpeek(win, false);
}

/*
** windata() performs updates for data-dump windows.
*/

static void windata(windowblock* win)
{
  static address* pos = NULL;
  byte b;
  int i;
  byte data[4];
  int state;

  if (wincheckaddress(win)) {
    state = 0;

    pos = a_copy(win->first, pos);
    while(mapped(pos)) {
      if (peekstop) {
	break;
      }
      if (state == 0) {
	switch (pv_abits) {
	  case 16: bufhex(a_a2w(pos), 4); break;
	  case 32: bufhex(a_a2l(pos), 8); break;
	  default: bufhex(a_a2l(pos), 8); break;
	}
	bufstring(": ");
	bufmark();
      }

      b = getmemory(pos);
      data[state] = b;
      a_inc(pos, 1);
      
      for(i = 0x80; i != 0; i >>= 1) {
	if (b & i) {
	  bufchar('1');
	} else {
	  bufchar('0');
	}
      }

      state += 1;
      if (state < 4) {
	bufstring(" ");
      } else {
	state = 0;
	bufstring(" ");
	drawarray(data, 4);
	bufnewline();
      }
    }
    if (state > 0) {
      tabto(36);
      drawarray(data, state);
    }
    if (peekstop) {
      win->last = a_copy(pos, win->last);
      win->lastmapped = true;
    } else {
      win->lastmapped = false;
    }
  }
}

/*
** winhex() updates a hex dump window.
*/

static void winhex(windowblock* win)
{
  static address* pos = NULL;
  byte b;
  int i;
  byte txt[16];

  if (wincheckaddress(win)) {
    pos = a_copy(win->first, pos);
    i = 0;

    while (mapped(pos)) {
      if (peekstop)
	break;

      if ((i & 0x0f) == 0) {
	bufhex(a_a2l(pos), 8);
	bufstring(": ");
	bufmark();
      }

      b = getmemory(pos);
      txt[i++] = b;
      a_inc(pos, 1);

      bufhex(b, 2);
      bufchar(' ');
      if ((i & 0x0f) == 8)
	bufchar(' ');
      if ((i & 0x0f) == 0) {
	bufchar(' ');
	drawarray(txt, 16);
	bufnewline();
	i = 0;
      }
    }
    if (i > 0) {
      tabto(50);
      drawarray(txt, i);
    }
    if (peekstop) {
      win->last = a_copy(pos, win->last);
      win->lastmapped = true;
    } else {
      win->lastmapped = false;
    }
  }
}

/*
** wincount() performs updates for counter windows.
*/

static void wincount(windowblock* win)
{
  int i;
  longword size;
  longword total;
  segment* seg;

  bufstring("Processor (cpu): ");
  if (procname != NULL) {
    bufstring(procname);
    if (processor != NULL)
      bufstring(", driver present");
    else
      bufstring(", no driver");
  } else {
    bufstring("<none>");
  }
  bufnewline();
  bufstring("comments:     "); bufnumber(c_count()); bufnewline();
  bufstring("descriptions: "); bufnumber(d_count()); bufnewline();
  bufstring("expansions:   "); bufnumber(e_count()); bufnewline();
  bufstring("labels:       "); bufnumber(l_count()); bufnewline();
  bufnewline();

  if (seg_count() == 0) {
    bufstring("No memory mapped.");
  } else {
    total = 0L;
    for (seg = seg_head(), i = 1; seg != NULL; seg = seg_next(seg), i += 1) {
      size = seg_length(seg);
      bufstring("Segment ");
      bufnumber(i);
      bufstring(", at ");
      bufstring(a_a2str(seg_first(seg)));
      bufstring("-");
      bufstring(a_a2str(seg_last(seg)));
      bufstring(" len ");
      if (pv_bpa > 1) {
	size = (size + pv_bpa - 1) / pv_bpa;
      }
      bufsize(size);
      total += size;
    }
    if (i > 1) {
      bufstring("Total size: ");
      bufsize(total);
    }
  }
}

/*
** update handler for "notes" windows:
*/

static void winnotes(windowblock* win)
{
  ls_notes();
}

/*
** update handler for "pattern" windows:
*/

static void winpatterns(windowblock* win)
{
  ls_patterns();
}

/*
 * update handler for module windows:
 */

static void winmodules(windowblock* win)
{
  md_list();
}
  
/*
 *  update handler for processor listing windows:
 */

static void winprocessors(windowblock* win)
{
  ls_processors();
}

/*
 *  update handler for field metadata windows:
 */

static void winfields(windowblock* win)
{
  static address* pos = NULL;
  pattern* fields;
  int i;

  if (wincheckaddress(win)) {
    pos = a_copy(win->first, pos);

    fields = f_read(pos);

    if (fields == NULL) {
      bufaddress(pos);
      bufstring(": no field data\n");
      pos = m_scan(1, pos, st_field);
    }

    while (pos != NULL) {
      fields = f_read(pos);

      for (i = 1; fields != NULL; fields = fields->next, i++) {
	/* pos n: status <stcode>, radix <radix> [, [un]signed] */

	if (fields->status == st_none &&
	    fields->radix == 0 &&
	    fields->length == 0 &&
	    fields->sign == SIGN_DEFAULT)
	  continue;

	bufaddress(pos);
	bufchar('/');
	bufnumber(i);
	bufstring(": status ");
	bufchar(st2char(fields->status));
	bufstring(", radix ");
	bufnumber(fields->radix);
	bufstring(", length ");
	bufnumber(fields->length);
	switch (fields->sign) {
	case SIGN_SIGNED:
	  bufstring(", signed");
	  break;
	case SIGN_UNSIGNED:
	  bufstring(", unsigned");
	  break;
	}
	bufnewline();
      }

      if (peekstop)
	break;

      pos = m_scan(1, pos, st_field);
    }
  }
}

/*
 *  update handler for attribute metadata windows:
 */

static void winattributes(windowblock* win)
{
  static address* pos = NULL;
  
  if (wincheckaddress(win)) {
    pos = a_copy(win->first, pos);

    while (pos != NULL) {

      bufaddress(pos);
      bufchar(':');
      if (l_exist(pos))
	bufstring(" L");
      if (c_exist(pos))
	bufstring(" C");
      if (d_exist(pos))
	bufstring(" D");
      if (e_exist(pos))
	bufstring(" E");
      if (f_read(pos) != NULL)
	bufstring(" F");
      if (ia_read(pos) != NULL)
	bufstring(" I");
      if (nrf_read(pos))
	bufstring(" N");
      bufnewline();

      if (peekstop)
	break;

      pos = m_scan(1, pos, st_attribute);
    }
  }
}

/*
** update handler for register windows:
*/

static void winregister(windowblock* win)
{
  regindex index;

  index = r_next(0);
  if (index == 0) {
    bufstring("%There are no defined registers.\n");
  }
  while (index != 0) {
    ls_register(index);
    index = r_next(index);
  }
}

/*
** update handler for rpn calculator windows:
*/

static void winrpn(windowblock* win)
{
  bufstring("x: "); bufnumber(rpn_rstack(0)); bufnewline();
  bufstring("y: "); bufnumber(rpn_rstack(1)); bufnewline();
  bufstring("z: "); bufnumber(rpn_rstack(2)); bufnewline();
  bufstring("t: "); bufnumber(rpn_rstack(3)); bufnewline();
}

/*
** update handler for "status" windows:
*/

static void winstatus(windowblock* win)
{
  static address* pos = NULL;
  int count, i, hpos;

  if (wincheckaddress(win)) {
    pos = a_copy(win->first, pos);
    
    count = seg_rest(pos) / pv_bpa;
    if (count == 0) {
      count = 100000;
    }

    win->lastmapped = false;
    while (count > 0) {
      if (peekstop) {
	win->last = a_copy(pos, win->last);
	win->lastmapped = true;
	break;
      }
      bufaddress(pos);
      bufchar(':');
      tabto(7);
      i = 64;
      if (i > count) {
	i = count;
      }
      count -= i;
      hpos = 0;
      while (i-- > 0) {
	if ((hpos & 0x0f) == 0) {
	  bufchar(' ');
	}
	hpos += 1;
	bufchar(st2char(getstatus(pos)));
	a_inc(pos, pv_bpa);
      }
      bufnewline();
    }
  }
}

/*
** update handler for "symbol" windows:
*/

static void winsymbols(windowblock* win)
{
  ls_symbols();
}

/*
** update handler for window listing windows:
*/

static void winwindows(windowblock* win)
{
  for (win = windowlist; win != NULL; win = win->next) {
    w_printinfo(win->index);
  }
}

/*
** update handler for dots windows:
*/

static void windots(windowblock* win)
{
  ls_dots();
}

/*
** update handler for logger windows:
*/

#define logmax 16

static int logcnt = 0;
static int logindex = 0;
static char* logstr[logmax];
static int lognum[logmax];

static void winlogger(windowblock* win)
{
  int i;

  for (i = 0; i < logmax; i += 1) {
    if (logstr[i] != NULL) {
      bufnumber(lognum[i]);
      bufstring(":");
      tabto(8);
      bufstring(logstr[i]);
      bufnewline();
    }
  }
}

/*
** update handler for highlight list windows:
*/

static void winhighlight(windowblock* win)
{
  ls_highlights();
}

/*
** update handler for unimplemented window types.
*/

static void winnyi(windowblock* win)
{
  bufnewline();
  bufstring("This type of window is not yet implemented.  Sorry.");
  bufnewline();
}

/**********************************************************************/

/*
 *  Set (or change) a windows address.
 */

static void setaddr(windowblock* win, address* a)
{
  windowblock* fw;

  if (win != NULL) {
    win->first = a_copy(a, win->first);
    win->messed = true;
    repaint = true;
    if (win->followed) {
      for (fw = windowlist; fw != NULL; fw = fw->next) {
	if (fw->target == win) {
	  fw->first = a_copy(a, fw->first);
	  fw->messed = true;
	}
      }
    }
  }
}

/**********************************************************************/

/*
 *  Move a window to the next address.
 */

static bool next_addr(windowblock* win)
{
  switch (win->wintype) {
  case wty_listing:		/* Listing window. */
  case wty_source:		/* Source listing window. */
  case wty_status:		/* Status map window. */
  case wty_hexdump:		/* Hex dump. */
  case wty_fields:		/* Field hints. */
  case wty_attributes:		/* Any attribute for address. */
    if (!wincheckaddress(win))
      return false;
    if (win->lastmapped == false)
      return false;
    setaddr(win, a_offset(win->first, pv_bpa));
    return true;
  }

  return false;
}

/*
 *  Move a window to the prev address.
 */

static bool prev_addr(windowblock* win)
{
  segment* s;
  longword len;

  switch (win->wintype) {
  case wty_listing:		/* Listing window. */
  case wty_source:		/* Source listing window. */
  case wty_status:		/* Status map window. */
  case wty_hexdump:		/* Hex dump. */
  case wty_fields:		/* Field hints. */
  case wty_attributes:		/* Any attribute for address. */
    if (!wincheckaddress(win))
      return false;
    s = seg_a2s(win->first);
    len = a_diff(win->first, seg_first(s));
    if (len < pv_bpa)
      return false;
    setaddr(win, a_offset(win->first, -pv_bpa));
    return true;
  }

  return false;
}

/*
 *  Move a window to the next item.
 */

static bool next_item(windowblock* win)
{
  /*
   *  First, check that windows that are supposed to have addresses
   *  actually have one.
   */

  switch (win->wintype) {
  case wty_listing:		/* Listing window. */
  case wty_source:		/* Source listing window. */
  case wty_status:		/* Status map window. */
  case wty_hexdump:		/* Hex dump. */
  case wty_fields:		/* Field hints. */
  case wty_attributes:		/* Any attribute for address. */
    if (!wincheckaddress(win))
      return false;
    if (win->lastmapped == false)
      return false;
    break;
  }

  switch (win->wintype) {
  case wty_listing:		/* Listing window. */
  case wty_source:		/* Source listing window. */
    bufshutup(true);
    peek(win->first, EX_LIST, st_none);
    bufshutup(false);
    setaddr(win, a_offset(win->first, pb_length * pv_bpa));
    return true;
  case wty_status:		/* Status map window. */
    setaddr(win, a_offset(win->first, 64));
    return true;
  case wty_hexdump:		/* Hex dump. */
    setaddr(win, a_offset(win->first, 16));
    return true;
  case wty_patterns:		/* Patterns. */
  case wty_modules:		/* Modules loaded. */
  case wty_processors:		/* Known processor drivers. */
    /*
     *  Should increment some base counter that we
     *  do not have at the moment.
     */
    return false;
  case wty_dump:		/* Dump data. */
    /*
     *  This window type should go away.
     */
    return false;
  case wty_logger:		/* Log buffer. */
  case wty_register:		/* Register. */
    /*
     *  Think about this.
     */
    return false;
  case wty_fields:		/* Field hints. */
  case wty_attributes:		/* Any attribute for address. */
    /*
     *  next address with that information, bounded by
     *  the current segment.
     */
    return false;
  default:
    return false;
  }
  return false;
}

/*
 *  Routine to handle previous item for code.  len is number of mapped
 *  bytes before the current address.
 */

static bool prev_code(windowblock* win, longword len)
{
  /*
   *  This is HARD.  Do this:
   *
   *  step 1:
   *  Scan backward for a byte with known status, skipping bytes with
   *  status st_cont.  After that, if the status is known, we are done
   *  and can safeley set the window address to result.
   *
   *  step 2:
   *  If we find st_none, check if we have a processor-specific handler
   *  for this case, i.e. a MIPS cpu has fixed instruction alignment
   *  (4 bytes), so it can just go back four bytes...
   *
   *  step 3:
   *  Finally, step back one byte at a time, checking with peek() what
   *  the length would be on the current item.  If it aligns with the
   *  window address, accept it.
   *
   *  step 4:
   *  If  all fails, just step back one byte.
   */

  char buf[60];

  int i;
  static address* pos = NULL;

  snprintf(buf, 60, "prev_code: enter, len = %u", len);
  w_logger(buf);

  if (len > 32) {
    len = 32;
  }

  pos = a_copy(win->first, pos);

  for (i = 1; i <= len; i += 1) {
    a_inc(pos, -1);
    switch (getstatus(pos)) {
    case st_none:
      goto step2;
    case st_cont:
      break;
    default:
      setaddr(win, pos);
      return true;
    }
  }

  w_logger("prev_code: step1 failed");

 step2:

  /* call eventual processor-specific routine */

  w_logger("prev_code: step2 ...");

 step3:

  bufshutup(true);
  pos = a_copy(win->first, pos);

  for (i = 1; i <= len; i += 1) {
    a_inc(pos, -1);
    peek(pos, EX_LIST, st_inst);

    snprintf(buf, 60, "prev_code: step3, len = %i, status = %i",
	     pb_length, pb_status);
    w_logger(buf);

    if (i == pb_length && pb_status == st_inst) {
      w_logger("prev_code: step3 hit");
      bufshutup(false);
      setaddr(win, pos);
      return true;
    }
  }
  bufshutup(false);

 step4:

  w_logger("prev_code: step4 hit");

  setaddr(win, a_offset(win->first, -1));
  return false;
}

/*
 *  Move a window to the prev item.
 */

static bool prev_item(windowblock* win)
{
  segment* s;
  longword len;

  switch (win->wintype) {
  case wty_listing:		/* Listing window. */
  case wty_source:		/* Source listing window. */
  case wty_status:		/* Status map window. */
  case wty_hexdump:		/* Hex dump. */
  case wty_fields:		/* Field hints. */
  case wty_attributes:		/* Any attribute for address. */
    if (!wincheckaddress(win))
      return false;
    s = seg_a2s(win->first);
    len = a_diff(win->first, seg_first(s));
    if (len == 0)
      return false;
    break;
  }

  switch (win->wintype) {
  case wty_listing:		/* Listing window. */
  case wty_source:		/* Source listing window. */
    /*
     *  This is HARD.  Use subroutine to try to handle.
     */
    return prev_code(win, len);
  case wty_status:		/* Status map window. */
    if (len > 64)
      len = 64;
    setaddr(win, a_offset(win->first, -len));
    return true;
  case wty_hexdump:		/* Hex dump. */
    if (len > 16)
      len = 16;
    setaddr(win, a_offset(win->first, -len));
    return true;
  case wty_patterns:		/* Patterns. */
  case wty_modules:		/* Modules loaded. */
  case wty_processors:		/* Known processor drivers. */
    /*
     *  Should decrement some base counter that we
     *  do not have at the moment.
     */
    return false;
  case wty_dump:		/* Dump data. */
    /*
     *  This window type should go away.
     */
    return false;
  case wty_logger:		/* Log buffer. */
  case wty_register:		/* Register. */
    /*
     *  Think about this.
     */
    return false;
  case wty_fields:		/* Field hints. */
  case wty_attributes:		/* Any attribute for address. */
    /*
     *  prev address with that information, bounded by
     *  the current segment.
     */
    return false;
  default:
    return false;
  }
  return false;
}

/*
 *  Move a window to the next screen.
 */

static bool next_screen(windowblock* win)
{
  switch (win->wintype) {
  case wty_listing:		/* Listing window. */
  case wty_source:		/* Source listing window. */
  case wty_status:		/* Status map window. */
  case wty_hexdump:		/* Hex dump. */
  case wty_fields:		/* Field hints. */
  case wty_attributes:		/* Any attribute for address. */
    if (!wincheckaddress(win))
      return false;
    if (win->lastmapped == false)
      return false;
    break;
  }

  switch (win->wintype) {
  case wty_listing:		/* Listing window. */
  case wty_source:		/* Source listing window. */
  case wty_status:		/* Status map window. */
  case wty_hexdump:		/* Hex dump. */
  case wty_fields:		/* Field hints. */
  case wty_attributes:		/* Any attribute for address. */
    setaddr(win, win->last);
    return true;
  default:			/* Any other window type. */
    /*
     *  Needs thinking.
     */
    return false;
  }
  return false;
}

/*
 *  Move a window to the prev screen.
 */

static bool prev_screen(windowblock* win)
{
  return false;
}

/**********************************************************************/

/*
** xy2addr() returns the address corresponding to the given position
** in the (listing) window.  If we can't find out that address, we
** return NULL.
*/

static address* xy2addr(int x, int y)
{
  return NULL;
}

/**********************************************************************/

/*
** doevent() handles exactly one X event.  Before we come here we
** have checked that there is one or more events in the queue.
*/

static void doevent(void) {
  XEvent report;
  windowblock* win;

  XNextEvent(display, &report);
  switch (report.type) {
  case Expose:
    if (report.xexpose.count == 0) {
      win = findwinblock(report.xexpose.window);
      if (win != NULL) {
	if (win->mapped) {
	  win->messed = true;
	  repaint = true;
	}
      }
    }
    break;
  case ConfigureNotify:
    win = findwinblock(report.xconfigure.window);
    if (win != NULL) {
      if (win->relocflag) {
	XMoveWindow(display, win->id,
		    win->relocx + 2 * win->x - report.xconfigure.x,
		    win->relocy + 2 * win->y - report.xconfigure.y);
	win->relocflag = false;
      }
      win->width = report.xconfigure.width;
      win->height = report.xconfigure.height;
      if (report.xconfigure.send_event) { /* Strange... */
	win->x = report.xconfigure.x;
	win->y = report.xconfigure.y;
      }
      wc_windows();
    }
    break;
  case MapNotify:
    win = findwinblock(report.xmap.window);
    if (win != NULL) {
      win->mapped = true;
    }
    break;
  case UnmapNotify:
    win = findwinblock(report.xunmap.window);
    if (win != NULL) {
      win->mapped = false;
    }
    break;
  case DestroyNotify:
    win = findwinblock(report.xdestroywindow.window);
    if (win != NULL) {
      freewinblock(win);
    }
    break;
  case ButtonPress:
    win = findwinblock(report.xbutton.window);
    if (win != NULL) {
      char buffer[60];
      snprintf(buffer, 60, "button press, button %d, bits %x",
	       report.xbutton.button,
	       report.xbutton.state);
      w_logger(buffer);

      switch (report.xbutton.button) {
      case 1:			/* DEBUGGING. */
      case 4:
	prev_item(win);
	break;
      case 3:			/* DEBUGGING. */
      case 5:
	next_item(win);
	break;
      }
    }
    break;
  case KeyPress:
    inputcount = XLookupString((XKeyEvent*) &report,
			       inputbuffer, 20, NULL, NULL);
    inputpos = 0;
    break;
  default:
    break;
  } /* end switch */
}

/*
** updatewindows() updates all windows that need it.
*/

void updatewindows(void)
{
  windowblock* w;

  w = windowlist;
  while (w != NULL) {
    if (w->messed || totalmess) {
      if (w->mapped) {
	wwbegin(w);
	(*w->updater)(w);
	wwend();
      }
      w->messed = false;
    }
    w = w->next;
  }
}

/*
** waitforevent() waits for the next X event or keyboard activity, and
** handles it.
*/

static void waitforevent(void)
{
  int maxfd;
  fd_set readset;
  struct timeval tv;

  if (display == NULL) {
    inputbuffer[0] = getchar();
    inputcount = 1;
    inputpos = 0;
    return;
  }

  if (setjmp(rubber) == 0) {
    while (repaint) {
      repaint = false;
      updatewindows();
      totalmess = false;
    }

    if (XPending(display) > 0) {
      doevent();			/* We have events, do one of them. */
    } else {
      maxfd = tfd;
      if (xfd > maxfd) {
	maxfd = xfd;
      }

      FD_ZERO(&readset);
      FD_SET(tfd, &readset);
      FD_SET(xfd, &readset);

      tv.tv_sec = 1;
      tv.tv_usec = 0;

      if (select(maxfd + 1, &readset, NULL, NULL, &tv) > 0) {
	if (FD_ISSET(tfd, &readset)) {
	  inputbuffer[0] = getchar();
	  inputcount = 1;
	  inputpos = 0;
	}
      }
    }
  }
}

/*
** readchar() reads characters, and handles events while waiting.
*/

static int readchar(void)
{
  char c;

  while (inputcount == 0) {
    waitforevent();
  }
  c = inputbuffer[inputpos];
  inputcount -= 1;
  inputpos += 1;
  return c;
}

/*
** setpri() fixes the fd number for the standard input.
*/

static void setpri(void)
{
  /*  tfd = fileno(cmcsb._cmij); */
}

/*
** getcolor() allocates a standout color.
*/

static void getcolor(char* color, bool fg)
{
  XColor use;
  XColor exact;

  if (color == NULL) {
    color = "red";
  }

  if (fg) {
    colorname = copystring(color, colorname);
  }

  if (display != NULL) {
    XAllocNamedColor(display, XDefaultColormap(display, screen),
		     color,  &use, &exact);
    if (fg) {
      standoutcolor = use.pixel;
    } else {
      standoutbackg = use.pixel;
    }
  }
}

/*
** openup() is the routine that opens the display.
*/

static void openup(int wintype)
{
  windowblock* win;

  if (display == NULL) {
    display = XOpenDisplay(NULL);
    if (display == NULL) {
      bufstring("%Can't connect to X server.\n");
      return;
    }

    screen = DefaultScreen(display);

    font = XLoadQueryFont(display, "fixed");
    if (font == NULL) {
      bufstring("%Can't load font.\n");
      XCloseDisplay(display);
      display = NULL;
      return;
    }
    fontheight = font->ascent + font->descent;
    fontwidth = font->max_bounds.width;

    getcolor(colorname, true);
    standoutbackg = WhitePixel(display, screen);

    /*
    ** We should check for failure below.
    */

    gc = XCreateGC(display, RootWindow(display, screen), 0, NULL);

    XSetForeground(display, gc, BlackPixel(display, screen));
    XSetBackground(display, gc, WhitePixel(display, screen));
    XSetFont(display, gc, font->fid);

    tfd = fileno(stdin);
    xfd = XConnectionNumber(display);

    cm_setinput(readchar);

    /*
      (void) XSetErrorHandler(eh);
      (void) XSetIOErrorHandler(ioeh);
    */
  }

  /*
  ** now the display is open.  Fix up a new window.
  */

  win = makewinblock(wintype);

  if (win != NULL) {
    switch (wintype) {
    case wty_attributes:
      win->width = 400; win->height = 450;
      win->updater = winattributes;
      break;
    case wty_counters:
      win->width = 400; win->height = 150;
      win->updater = wincount;
      break;
    case wty_dots:
      win->width = 400; win->height = 150;
      win->updater = windots;
      break;
    case wty_dump:
      win->width = 400; win->height = 450;
      win->updater = windata;
      break;
    case wty_fields:
      win->width = 400; win->height = 450;
      win->updater = winfields;
      break;
    case wty_hexdump:
      win->width = 475; win->height = 450;
      win->updater = winhex;
      break;
    case wty_highlight:
      win->width = 400; win->height = 200;
      win->updater = winhighlight;
      break;
    case wty_listing:
      win->width = 450; win->height = 550;
      win->updater = winlisting;
      break;
    case wty_logger:
      win->width = 400; win->height = 220;
      win->updater = winlogger;
      break;
    case wty_modules:
      win->width = 400; win->height = 150;
      win->updater = winmodules;
      break;
    case wty_notes:
      win->width = 400; win->height = 200;
      win->updater = winnotes;
      break;
    case wty_patterns:
      win->width = 400; win->height = 200;
      win->updater = winpatterns;
      break;
    case wty_processors:
      win->width = 400; win->height = 300;
      win->updater = winprocessors;
      break;
    case wty_register:
      win->width = 400; win->height = 450;
      win->updater = winregister;
      break;
    case wty_rpn:
      win->width = 200; win->height =  60;
      win->updater = winrpn;
      break;
    case wty_source:
      win->width = 450; win->height = 550;
      win->updater = winsource;
      break;
    case wty_status:
      win->width = 460; win->height = 220;
      win->updater = winstatus;
      break;
    case wty_symbols:
      win->width = 400; win->height = 150;
      win->updater = winsymbols;
      break;
    case wty_windows:
      win->width = 400; win->height = 150;
      win->updater = winwindows;
      break;
    default:
      win->width = 400; win->height = 450;
      win->updater = winnyi;
      break;
    }

    win->id = XCreateSimpleWindow(display, RootWindow(display, screen),
				  0, 0,         /* x, y */
				  win->width, win->height, 1,
				  BlackPixel(display, screen),
				  WhitePixel(display, screen));
    /*
    ** Set up our names:
    */

    /*
    ** ... seems like the nice, well thought out XLib requires the
    ** user to deallocate the "value" subfield of TextPropertys if
    ** he wants to reuse them or forget them.
    */

    if (XStringListToTextProperty(&win->name, 1, &windowname) != 0) {
      XSetWMName(display, win->id, &windowname);
    }

    if (XStringListToTextProperty(&win->name, 1, &iconname) != 0) {
      XSetWMIconName(display, win->id, &iconname);
    }

    XSelectInput(display, win->id,
		 ExposureMask | KeyPressMask | ButtonPressMask |
		 StructureNotifyMask);

    XMapWindow(display, win->id);
  }
}

/**********************************************************************/

void w_open(int wintype)
{
  openup(wintype);
}

/**********************************************************************/

void w_close(winindex index)
{
  windowblock* win;

  win = argwindow(index);
  if (win != NULL) {
    XDestroyWindow(display, win->id);
  }
}

/**********************************************************************/

/*
** Handlers to be called when something in the universe changes, and
** we might have to redraw some windows.  First a common routine:
*/

static void wctype(int wintype)
{
  windowblock* w;

  for (w = windowlist; w != NULL; w = w->next) {
    if (w->wintype == wintype) {
      w->messed = true;
      repaint = true;
    }
  }
}

/*
** Total change.
*/

void wc_total(void)
{
  totalmess = true;		/* Trivial. */
  repaint = true;
}

/*
** Change local to address.
*/

void wc_local(address* a)
{
  wctype(wty_listing);
  wctype(wty_counters);		/* FOO */
}

/*
** Code might have changed apperance.
*/

void wc_code(void)
{
  wctype(wty_listing);
}

/*
** Note add/delete.
*/

void wc_notes(void)
{
  wctype(wty_notes);
}

/*
** pattern change.
*/

void wc_patterns(void)
{
  wctype(wty_patterns);
}

/*
** register change.
*/

void wc_register(regindex index)
{
  wctype(wty_listing);
  wctype(wty_register);
}

/*
** calculator change.
*/

void wc_rpn(void)
{
  wctype(wty_rpn);
}

/*
** Segment data change.
*/

void wc_segment(void)
{
  totalmess = true;		/* Simple version. */
  repaint = true;
}

/*
** symbol change.
*/

void wc_symbols(void)
{
  wctype(wty_symbols);
}

/*
** window add/delete.
*/

void wc_windows(void)
{
  wctype(wty_windows);
}

/*
** dot change.
*/

void wc_dots(void)
{
  wctype(wty_dots);
}

/*
** log buffer change.
*/

void wc_log(void)
{
  wctype(wty_logger);
}

/*
 * module change.
 */

void wc_module(void)
{
  wctype(wty_modules);
  wctype(wty_processors);
}

/*
** highlight list change.
*/

void wc_highlight(void)
{
  wctype(wty_listing);
  wctype(wty_highlight);
}

/*
 * field change.
 */

void wc_fields(void)
{
  wctype(wty_fields);
}

/*
 * attribute change.
 */

void wc_attributes(void)
{
  wctype(wty_attributes);
}

/**********************************************************************/

/*
** w_next() is used to step over all existing windows.  If the argument
** is zero, we return the first window.  If the argument is non-zero,
** we return the next window after that one.  If there are no more
** windows, we return zero.
*/

winindex w_next(winindex index)
{
  windowblock* w;

  if (index == 0) {
    if (windowlist == NULL) {
      return 0;
    }
    return windowlist->index;
  }
  w = findwinindex(index);
  if (w == NULL) {
    return 0;
  }
  w = w->next;
  if (w == NULL) {
    return 0;
  }
  return w->index;
}

/**********************************************************************/

void w_printinfo(winindex index)
{
  windowblock* win;

  win = findwinindex(index);
  if (win != NULL) {
    bufstring("Window # "); bufnumber(index);
    bufstring(" ("); bufstring(wty2name(win->wintype)); bufstring(")");
    bufstring(", h="); bufnumber(win->height);
    bufstring(", w="); bufnumber(win->width);
    bufstring(", x="); bufnumber(win->x);
    bufstring(", y="); bufnumber(win->y);
    bufnewline();
  }
}

/**********************************************************************/

address* w_getaddr(winindex index)
{
  static address* work = NULL;
  windowblock* win;

  win = argwindow(index);
  if (win != NULL) {
    work = a_copy(win->first, work);
    return work;
  }
  return NULL;
}

/**********************************************************************/

void w_setaddr(winindex index, address* a)
{
  windowblock* win;

  win = argwindow(index);
  if (win != NULL) {
    setaddr(win, a);
  }
}

/**********************************************************************/

void w_setcolor(char* color)
{
  getcolor(color, true);
  wc_highlight();
}

/**********************************************************************/

void w_setinverse(void)
{
  static int mode = 1;

  if (mode++ & 1)
    getcolor("grey", false);
  else
    getcolor("white", false);

  wc_highlight();
}

/**********************************************************************/

void w_setcurrent(winindex index)
{
  windowblock* win;

  win = findwinindex(index);
  if (win != NULL) {
    defaultwindow = win;
  }
}

/**********************************************************************/

void w_putc(char c)
{
  /*
  ** here we get a character to output to whatever window we are
  ** working with at the moment.  Handle it.
  */
  drawchar(c);
}

/**********************************************************************/

void w_highlight(bool enterflag)
{
  if (wwmode) {			/* Only do this when we are at it. */
    dumpbuffer();
    if (enterflag) {
      XSetForeground(display, gc, standoutcolor);
      XSetBackground(display, gc, standoutbackg);
      w_logger("set highlight");
    } else {
      XSetForeground(display, gc, BlackPixel(display, screen));
      XSetBackground(display, gc, WhitePixel(display, screen));
      w_logger("clr highlight");
    }
  }
}

/**********************************************************************/

void w_extend(winindex index, winindex target)
{
  /* this should be like w_follow(), but should extend (mainly)
  ** listing windows so that the second one starts where the first
  ** one ended.
  **
  ** Need to think about implementation.
  */
}

/**********************************************************************/

void w_follow(winindex index, winindex target)
{
  windowblock* win;
  windowblock* targ;

  win = argwindow(index);
  targ = findwinindex(target);

  if (win == NULL || targ == NULL) return;

  if (win == targ) {
    win->target = NULL;
    /* XXX should recompute the followed flags. */
  } else {
    targ->followed = true;
    win->target = targ;
    win->first = a_copy(targ->first, win->first);
    win->messed = true;
    repaint = true;
  }
}

/**********************************************************************/

void w_lower(winindex index)
{
  windowblock* win;

  win = argwindow(index);
  if (win != NULL) {
    XLowerWindow(display, win->id);
  }
}

/**********************************************************************/

void w_move(winindex index, int xdiff, int ydiff)
{
  windowblock* win;

  win = argwindow(index);
  if (win != NULL) {
    win->relocflag = true;
    win->relocx = xdiff;
    win->relocy = ydiff;
    XMoveWindow(display, win->id, win->x, win->y);
  }
}

/**********************************************************************/

void w_naddr(winindex index)
{
  windowblock* win;

  win = argwindow(index);
  if (win != NULL) {
    (void) next_addr(win);
  }
}

/**********************************************************************/

void w_nitem(winindex index)
{
  windowblock* win;

  win = argwindow(index);
  if (win != NULL) {
    (void) next_item(win);
  }
}

/**********************************************************************/

void w_nscreen(winindex index)
{
  windowblock* win;

  win = argwindow(index);
  if (win != NULL) {
    (void) next_screen(win);
  }
}

/**********************************************************************/

void w_paddr(winindex index)
{
  windowblock* win;

  win = argwindow(index);
  if (win != NULL) {
    (void) prev_addr(win);
  }
}

/**********************************************************************/

void w_pitem(winindex index)
{
  windowblock* win;

  win = argwindow(index);
  if (win != NULL) {
    (void) prev_item(win);
  }
}

/**********************************************************************/

void w_pscreen(winindex index)
{
  windowblock* win;

  win = argwindow(index);
  if (win != NULL) {
    (void) prev_screen(win);
  }
}

/**********************************************************************/

void w_raise(winindex index)
{
  windowblock* win;

  win = argwindow(index);
  if (win != NULL) {
    XRaiseWindow(display, win->id);
  }
}

/**********************************************************************/

void w_test(void)
{
  /* nothing at the moment. */

#if 0
  bufstring("Default window = ");
  if (defaultwindow != NULL) {
    bufnumber(defaultwindow->index);
  } else {
    bufstring("<none>");
  }
  bufnewline();
#endif
}

/**********************************************************************/

void w_logger(char* s)
{
  logcnt += 1;
  logindex += 1;
  if (logindex >= logmax) {
    logindex = 0;
  }
  logstr[logindex] = copystring(s, logstr[logindex]);
  lognum[logindex] = logcnt;

  wc_log();
}

/**********************************************************************/

/* end of file */
