/*
** Ethernet module for linux.  Included from sim_eth.c, see that file for
** copyrights etc.
*/

#include "eth_dummy.h"		/* ... since this code is not yet written. */
