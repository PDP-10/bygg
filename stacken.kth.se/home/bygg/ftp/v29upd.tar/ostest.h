/*
** Try to figure out what kind of OS we are using:
*/

#if defined (VMS)
  /* ... */
#endif

#if defined (__OS2__)
  /* ... */
#endif

#if defined (_WIN32)
  /* ... */
#endif

#if defined (macintosh)
  /* ... */
#endif

#if defined (__linux__)
  /* ... */
#endif

#if defined (__FreeBSD__)
  /* ... */
#endif

#if defined (__NetBSD__)
  /* ... */
#endif

#if defined (__OpenBSD__)
  /* ... */
#endif
