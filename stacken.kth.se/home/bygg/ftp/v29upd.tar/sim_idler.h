/*
** sim_idler.h: os-dependent idle header file.
*/

/*
** Written 2002 by Johnny Eriksson <bygg@stacken.kth.se>
*/

/*
** Revision history:
**
** 2002-04-16    Made into a module.
*/

int32 sim_idle(int32 cycles);
