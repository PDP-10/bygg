/*
** sync line module for linux.  Included from sim_sync.c, see that file for
** copyrights etc.
*/

#include "sync_dummy.h"		/* ... since this code is not yet written. */
