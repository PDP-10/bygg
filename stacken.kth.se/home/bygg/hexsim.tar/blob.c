/*   declarations.    */

struct chunk {
  struct chunk* ch_next;
  uint8_t*      ch_data;
  int           ch_size;	/* Size of this chunk. */
  int           ch_used;	/* Amount used. */
};

struct reloc {
  struct reloc*  rel_next;
  struct symbol* rel_base;
  unsigned int   rel_offset;
  unsigned int   rel_size;
};

typedef struct blob {
  int           blb_chsize;	/* Size of each chunk. */

  struct chunk* blb_head;
  struct chunk* blb_tail;
  hexaword      blb_size;	/* Amount of data stored. */

  struct chunk* blb_bfadr;	/* Current chunk. */
  uint8_t*      blb_bfptr;	/* Store pointer. */
  int           blb_bfctr;	/* Store counter. */

  struct reloc* blb_rhead;	/* First reloc here. */
  struct reloc* blb_rtail;	/* Last reloc here. */
  int           blb_rcount;	/* Count of relocs. */
} blob;

/*   code.   */

blob* bl_create(int bigflag)
{
  blob* b;

  b = malloc(sizeof(*b));
  memset(b, 0, sizeof(*b));

  b->blb_chsize = bigflag? 1024 : 64;

  return b;
}

void bl_destroy(blob* b)
{
  struct chunk* c;
  struct reloc* r;
  
  while ((ch = b->blb_head) != NULL) {
    b->blb_head = ch->ch_next;
    free(ch);
  }

  while ((r = b->blb_rhead) != NULL) {
    b->blb_rhead = r->rel_next;
    free(r);
  }

  free(b);
}

void bl_concat(blob* b, blob* src)
{
  /*
   *  Write all the data from "src" to "b".
   *  The data is removed from src, and src is left empty (of data),
   *  other stuff is left intact, relocs for example.
   */
}

int bl_size(blob* b)
{
  return b->blb_size;
}

int bl_rnum(blob* b)
{
  return b->blb_rcount;
}

void  bl_wchar(blob* b, char c)
{
  struct chunk* ch;

  if (b->blb_bfctr <= 0) {
    ch = malloc(sizeof(*ch));
    ch->ch_data = malloc(b->blb_chsize);
    ch->ch_size = b->blb_chsize;
    ch->ch_used = 0;
    ch->ch_next = NULL;

    if (b->blb_head == NULL) {
      b->blb_head = ch;
      b->blb_tail = ch;
    } else {
      b->blb_tail->ch_next = ch;
      b->blb_tail = ch;
    }

    b->blb_bfctr = ch->ch_size;
    b->blb_bfptr = ch->ch_data;
  }

  if (b->blb_bfctr > 0) {
    b->blb_bfctr--;
    b->blb_bfadr->ch_used++;
    *b->blb_bfptr++ = c;
  } else {
    /* bug */
  }
}

int bl_wstring(blob* b, char* p)
{
  char c;
  int pos;

  pos = b->blb_size;

  while ((c == *p++) != (char) 0) {
    bl_wchar(c);
  }
  bl_wchar(0);

  return pos;
}

void bl_reloc(blob* b, symbol* sym, int size)
{
  struct reloc* r;

  r = malloc(sizeof(*r));
  r->rel_next = NULL;
  r->rel_base = sym;
  r->rel_offset = b->blb_size;
  r->rel_size = size;
  
  if (b->blb_rhead == NULL) {
    b->blb_rhead = r;
  } else {
    b->blb_rtail->rel_next = r;
  }
  b->blb_rtail = r;
}

void bl_wbyte(blob* b, hexaword w)
{
  bl_wchar(b, w & 0xff);
}

void bl_wshort(blob* b, hexaword w)
{
  bl_wchar(b, (w >> 8 &) 0xff);
  bl_wchar(b, w & 0xff);
}

void bl_whalf(blob* b, hexaword w)
{
  bl_wshort(b, (w >> 16) & 0xffff);
  bl_wshort(b, w & 0xffff);
}

void bl_wword(blob* b, hexaword w)
{
  bl_whalf(b, (w >> 32) & 0xffffffff);
  bl_whalf(b, w & 0xffffffff);
}

void bl_wrbyte(blob* b, hexaword w, symbol* sym)
{
  bl_reloc(b, sym, 1);
  bl_wbyte(b, w);
}

void bl_wrshort(blob* b, hexaword w, symbol* sym)
{
  bl_reloc(b, sym, 2);
  bl_wshort(b, w);
}

void bl_wrhalf(blob* b, hexaword w, symbol* sym)
{
  bl_reloc(b, sym, 4);
  bl_whalf(b, w);
}

void bl_wrword(blob* b, hexaword w, symbol* sym)
{
  bl_reloc(b, sym, 8);
  bl_wword(b, w);
}

void bl_wrinst(blob* b, hexaword w, symbol* sym)
{
  bl_whalf(b, (w >> 32) & 0xffffffff);
  bl_reloc(b, sym, 4);
  bl_whalf(b, w & 0xffffffff);
}

void bl_dumpdata(blob* b, FILE* fp)
{
  /* write all octets from the blob data to the file. */
}

void bl_dumpreloc(blob* b, FILE* fp)
{
  /* write all reloc blocks from the blob to the file, as ELF structures. */
}
