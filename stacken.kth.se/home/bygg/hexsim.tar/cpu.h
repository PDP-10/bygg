/*
 *  Global routines and data from cpu.c:
 */

/*
 *  Hardware-type defs.
 */

#define CTX_USER  0		/* User context. */
#define CTX_EXEC  1		/* Exec context. */
#define CTX_PFH   2		/* Page fault handler. */
#define CTX_INT0  3		/* Interrupt level 0. (soft) */
#define CTX_INT1  4		/* Interrupt level 1. */
#define CTX_INT2  5		/* Interrupt level 2. */
#define CTX_INT3  6		/* Interrupt level 3. */
#define CTX_NMI   7		/* NMI/trap handler. */

#define CTXNUM    8		/* Number of real contexts we have. */

#define CTX_CURRENT   9		/* Virtual context # for current. */
#define CTX_PHYSICAL 10		/* Virtual context # for physical. */

/*
 *  Data others need, i.e. cpu registers.
 */

extern hexaword ICT;		/* Instruction Counter. */

extern hexaword AR, ARX;	/* "A" (arithmetic) register with extension. */
extern hexaword BR, BRX;	/* "B" (buffer) register with extension. */

extern hexaword EBR;		/* The Exec Base Register. */
extern hexaword UBR;		/* The User Base Register. */
extern hexaword SPT;		/* SPT base address. */
extern hexaword CST;		/* CST base address. */

/*
 *  Globally known constants:
 */

extern const hexaword FWMASK;
extern const hexaword LHMASK;
extern const hexaword RHMASK;
extern const hexaword RHSIGN;
extern const hexaword SIGNBIT;
extern const hexaword ZERO;

/*
 *  Routines:
 */

extern void cpu_init(void);

extern int cpu_disass(hexaword data, char buf[]);
extern int cpu_execute(void);

extern void cpu_show_context(int ctx);
extern void cpu_show_hw_regs(void);

extern void uart_input(char c);

/*
 *  Register access:
 */

extern hexaword reg_read(uint8_t reg, int ctx);
extern void     reg_write(uint8_t reg, int ctx, hexaword data);
extern void     reg_deposit(uint8_t reg, int ctx, hexaword data);
extern uint16_t reg_rcmask(int ctx);

extern hexaword fac_read(void);
extern void     fac_write(hexaword val);

extern hexaword iac_read(int i);
extern void     iac_write(int i, hexaword val);

/*
 *  PC access:
 */

extern hexaword pc_examine(int ctx);
extern void     pc_deposit(int ctx, hexaword val);

/*
 *  PSW bits etc.
 */

#define PSW_NII   0x00000001	/* Next Instruction Inhibit. */
#define PSW_CRY   0x00000010	/* Carry bit. */
#define PSW_OVF   0x00000020	/* Overflow bit. */

extern uint32_t psw_read(int ctx);
extern void     psw_write(int ctx, uint32_t val);
extern void     psw_setbit(uint32_t bit);
extern void     psw_clrbit(uint32_t bit);
extern int      psw_chkbit(uint32_t bit);
