/*
 *  Assorted symbols needed to work with the ELF format.
 */

typedef struct {
  unsigned char   e_ident[16];
#   define EI_MAG0   0		/* Should hold 0x7f */
#   define EI_MAG1   1		/* Should hold "E" */
#   define EI_MAG2   2		/* Should hold "L" */
#   define EI_MAG3   3		/* Should hold "F" */
#   define EI_CLASS  4		/* Class of machine */
#     define ELFCLASS64  2	/*   Value for above */
#   define EI_DATA   5		/* Data format. */
#     define ELFDATA2MSB	/*   Value for above */

  Elf64_Half      e_type;	/* ET_REL */
  Elf64_Half      e_machine;	/* EM_NONE? */
  Elf64_Word      e_version;	/*  */
  Elf64_Addr      e_entry;
  Elf64_Off       e_phoff;
  Elf64_Off       e_shoff;
  Elf64_Word      e_flags;
  Elf64_Half      e_ehsize;
  Elf64_Half      e_phentsize;
  Elf64_Half      e_phnum;
  Elf64_Half      e_shentsize;
  Elf64_Half      e_shnum;
  Elf64_Half      e_shstrndx;
} Elf64_Ehdr;
