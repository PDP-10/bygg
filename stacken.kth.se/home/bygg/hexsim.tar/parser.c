/*
 * Command parser for hexsim.
 */

#include "hexsim.h"
#include "comnd.h"

int argwinindex;

hexaword parse_hw(char* help)
{
  cm_pnum(help, NUM_US, 16);
  return pval.num.magnitude;
}

int parse_number(char* help)
{
  cm_pnum(help, NUM_US, 10);
  return (int) pval.num.number;
}

int parse_user_exec(void)
{
  static cmkeyword level[] = {
    { "user", 0, (void*) 0 },  
    { "exec", 0, (void*) 1 },
    { NULL },
  };

  cm_pkey("level, ", 0, level, 0);
  return VP2I(pval.kw->data);
}

int parse_cpu_level(void)
{
  static cmkeyword level[] = {
    { "user", 0, (void*) 0 },
    { "exec", 0, (void*) 1 },
    { "pfh",  0, (void*) 2 },
    { "int0", 0, (void*) 3 },
    { "int1", 0, (void*) 4 },
    { "int2", 0, (void*) 5 },
    { "int3", 0, (void*) 6 },
    { "nmi",  0, (void*) 7 },
    { NULL },
  };

  cm_pkey("level, ", 0, level, 0);
  return VP2I(pval.kw->data);
}

void cmd_close(void)
{
  int win;

  cm_pnum("window index", 0, 10);
  win = (int) pval.num.number;
  cm_confirm();
  w_close(win);
}

void cmd_exit(void)
{
  cm_noise("this program");
  cm_confirm();

  exit(0);
}

void cmd_halt(void)
{
  cm_confirm();

  bg_stop();
}

void cmd_help(void)
{
  cm_confirm();

  printf("help string...\n");
}

void cmd_load(void)
{
  cm_noise("file");
  cm_default("hex.out");
  cm_pfil("input file", 0);
  cm_confirm();

  mem_load_file(atombuffer);
}

void cmd_run(void)
{
  cm_confirm();

  bg_run();
}

/*
 *  Set commands.  Structured with some helper functions since
 *  we have shortcuts here and there.
 */

void set_mem_helper(int ctx)
{
  hexaword addr;
  uint8_t buf[256];
  int pos = 0;
  int i;
  cmfdb* f;

  addr = parse_hw("address");

  cm_noise("value");

  cm_default("0");

  for (;;) {
    f = cm_chain(cm_fdb(_CMCFM, NULL, 0, NULL),
		 cm_fdb(_CMNUM, "byte to set",
			NUM_US+NUM_UNIX, (void*) 16),
		 cm_fdb(_CMQST, "text string", 0, NULL),
		 NULL);
    if (pos == 0)
      f = f->next;
    cm_parse(f);
    if (pval.used->function == _CMCFM)
      break;
    if (pval.used->function == _CMQST) {
      for (i = 0; atombuffer[i] != 0; i++) {
	if (pos < 256) {
	  buf[pos++] = atombuffer[i];
	}
      }
    } else {
      if (pos < 256)
	buf[pos++] = (int) pval.num.number;
    }
  }

  for (i = 0; i < pos; i++) {

    /* XXX use ctx here XXX */

    (void) mem_deposit(ASP_PHYS, addr, buf[i]);
    addr += 1;
  }
  wc_memory();
}

void set_pc_helper(int ctx)
{
  hexaword newpc;

  newpc = parse_hw("new PC");
  cm_confirm();

  pc_deposit(ctx, newpc);
}

void set_psw_helper(int ctx)
{
  hexaword bits;

  bits = parse_hw("new value");
  cm_confirm();

  psw_write(ctx, bits);
}

void set_reg_helper(int ctx)
{
  int reg;
  hexaword newval;

  cm_pnum("register", NUM_US, 10);
  reg = (int) pval.num.number;

  cm_noise("value");
  newval = parse_hw("register value");

  cm_confirm();

  reg_deposit(reg, ctx, newval);
}

void set_context(void)
{
  enum {
    SC_MEM,
    SC_PC,
    SC_PSW,
    SC_REG,
  };

  static cmkeyword vars[] = {
    { "memory",   0, (void*) SC_MEM, 0, "set context memory" },
    { "register", 0, (void*) SC_REG, 0, "set context register" },
    { "pc",       0, (void*) SC_PC,  0, "set context pc" },
    { "psw",      0, (void*) SC_PSW, 0, "set context psw" },
    { NULL },
  };

  int ctx;

  ctx = parse_cpu_level();

  cm_pkey("context data, ", 0, vars, 0);

  switch (VP2I(pval.kw->data)) {
  case SC_MEM:
    set_mem_helper(ctx);
    break;
  case SC_REG:
    set_reg_helper(ctx);
    break;
  case SC_PC:
    set_pc_helper(ctx);
    break;
  case SC_PSW:
    set_psw_helper(ctx);
    break;
  }
}

void set_ips(void)
{
  cm_pnum("instructions/second", NUM_US, 10);
  cm_confirm();

  bg_ips_set((int) pval.num.number);
}

void set_mem(void)
{
  set_mem_helper(CTX_PHYSICAL);
}

enum {
  PAG_REG_CST,
  PAG_REG_EBR,
  PAG_REG_SPT,
  PAG_REG_UBR,
};

void set_pager(void)
{
  static cmkeyword regs[] = {
    { "cst", 0, (void*) PAG_REG_CST, 0, "CST base address" },
    { "ebr", 0, (void*) PAG_REG_EBR, 0, "Exec Base Register" },
    { "spt", 0, (void*) PAG_REG_SPT, 0, "SPT base address" },
    { "ubr", 0, (void*) PAG_REG_UBR, 0, "User Base Register" },
  };

  int reg;
  hexaword val;

  cm_pkey("pager register", 0, regs, 0);
  reg = VP2I(pval.kw->data);

  val = parse_hw("value");

  cm_confirm();

  switch (reg) {
  case PAG_REG_CST:
    CST = val;
    break;
  case PAG_REG_EBR:
    EBR = val;
    break;
  case PAG_REG_SPT:
    SPT = val;
    break;
  case PAG_REG_UBR:
    UBR = val;
    break;
  default:
    /* internal error */
    break;
  }

  wc_cpu();
}

void set_pc(void)
{
  set_pc_helper(CTX_CURRENT);
}

void set_psw(void)
{
  set_psw_helper(CTX_CURRENT);
}

void set_reg(void)
{
  set_reg_helper(CTX_CURRENT);
}

void win_address(void)
{
  hexaword addr;

  addr = parse_hw("new address");
  cm_confirm();

  w_setaddress(argwinindex, addr);
}

void win_name(void)
{
  /*
   *  Set window name.
   */

  cm_confirm();

  printf("not quite yet...\n");
}

void set_win(void)
{
  static cmkeyword wincmds[] = {
    { "address",   0, 0, win_address, "set window address" },
    { "name",      0, 0, win_name,    "set window name" },
    { NULL },
  };

  cm_pnum("window index", NUM_US, 10);
  argwinindex = (int) pval.num.number;

  cm_pcmd("window parameter, ", 0, wincmds, 0);
}

void cmd_set(void)
{
  static cmkeyword setcmds[] = {
    { "context",   0, 0, set_context,"set context data" },
    { "ips",       0, 0, set_ips,    "set instr/second" },
    { "memory",    0, 0, set_mem,    "set memory contents" },
    { "pager",     0, 0, set_pager,  "set pager registers" },
    { "pc",        0, 0, set_pc,     "set new PC value" },
    { "psw",       0, 0, set_psw,    "set new PSW value" },
    { "register",  0, 0, set_reg,    "set register" },
    { "window",    0, 0, set_win,    "set window params" },
    { NULL },
  };

  cm_pcmd("Subcommand, ", 0, setcmds, 0);
}

void show_context(void)
{
  int ctx;

  ctx = parse_cpu_level();
  cm_confirm();

  cpu_show_context(ctx);
}

void show_cpu(void)
{
  cm_confirm();

  cpu_show_hw_regs();
}

void show_ips(void)
{
  cm_confirm();

  printf("current ips = %u\n", bg_ips_get());
}

void show_tlb(void)
{
  cm_confirm();

  tlb_show();
}

void cmd_show(void)
{
  static cmkeyword showcmds[] = {
    { "context",   0, 0, show_context, "show a context" },
    { "cpu",       0, 0, show_cpu,     "show cpu registers" },
    { "ips",       0, 0, show_ips,     "show ips" },
    { "tlb",       0, 0, show_tlb,     "show tlb" },
    { NULL },
  };

  cm_pcmd("Subcommand, ", 0, showcmds, 0);
}

void c_tlb_insert(void)
{
  hexaword addr, page;
  int level;

  addr = parse_hw("virtual address");
  level = parse_user_exec();

  page = parse_hw("physical address");

  cm_confirm();

  tlb_insert(addr, level, page, 0);
}

void c_tlb_inval_all(void)
{
  cm_confirm();
  tlb_invalidate_all();
}

void c_tlb_inval_user(void)
{
  cm_confirm();
  tlb_invalidate_user();
}

void c_tlb_invalidate(void)
{
  static cmkeyword inval[] = {
    { "all",   0, 0, c_tlb_inval_all,   "invalidate the whole tlb" },
    { "user",  0, 0, c_tlb_inval_user,  "invalidate all user mappings" },
    { NULL },
  };

  cm_default("all");
  cm_pcmd("Subcommand, ", 0, inval, 0);
}

void c_tlb_lookup(void)
{
  hexaword addr;
  int level;
  int i;

  addr = parse_hw("virtual address");
  level = parse_user_exec();

  cm_confirm();

  i = tlb_lookup(addr, level);

  if (i < 0) {
    bufstring("address not in tlb\n");
  } else {
    tlb_print(i);
  }
}

void c_tlb_modify(void)
{
  int i;
  int func;
  uint16_t bit;

  static cmkeyword fname[] = {
    { "clear", 0, (void*) TLB_MODIFY_FUNC_CLEAR },
    { "set",   0, (void*) TLB_MODIFY_FUNC_SET },
    { NULL },
  };

  static cmkeyword bname[] = {
    { "cacheable",  0, (void*) TLB_BIT_CACHEABLE },
    { "executeable",0, (void*) TLB_BIT_EXECUTE },
    { "keep",       0, (void*) TLB_BIT_KEEP },
    { "modified",   0, (void*) TLB_BIT_MODIFIED },
    { "writeable",  0, (void*) TLB_BIT_WRITE },
    { NULL },
  };

  i = parse_number("entry number");

  cm_pkey("function, ", 0, fname, 0);
  func = VP2I(pval.kw->data);

  cm_pkey("bit, ", 0, bname, 0);
  bit = VP2I(pval.kw->data);

  cm_confirm();

  tlb_modify(i, func, bit);
}

void c_tlb_show(void)
{
  cm_confirm();

  tlb_show();
}

void c_tlb_translate(void)
{
  static cmkeyword accnames[] = {
    { "read",    0, (void*) TLB_ACC_READ },
    { "write",   0, (void*) TLB_ACC_WRITE },
    { "execute", 0, (void*) TLB_ACC_EXECUTE },
  };

  hexaword addr;
  int level;
  int i;
  hexaword result;
  int access;

  addr = parse_hw("virtual address");
  level = parse_user_exec();

  cm_default("read");
  cm_pkey("access type, ", 0, accnames, 0);
  access = VP2I(pval.kw->data);

  cm_confirm();

  i = tlb_translate(addr, level, access, &result);

  switch (i) {
  case PFC_OK:
    bufstring("Maps to ");
    bufhw(result);
    break;
  case PFC_NOMEM:
    bufstring("Not mapped.");
    break;
  case PFC_NOWRITE:
    bufstring("No write access");
    break;
  case PFC_NOEXEC:
    bufstring("No execute access");
    break;
  case PFC_NOTINCORE:
    bufstring("Paged out");
    break;
  case PFC_OUTOFBOUNDS:
    bufstring("Virtual address out of bounds.");
    break;
  case PFC_PHYSICAL_NXM:
    bufstring("Physical memory not there.");
    break;
  case PFC_NOT_IMPLEMENT:
    bufstring("Mapping via SPT not yet implemented.");
    break;
  default:
    bufstring("Return code ");
    bufnumber(i);
    bufstring(", result = ");
    bufhw(result);
    break;
  }
  bufnewline();
}

void cmd_tlb(void)
{
  static cmkeyword tlbfuncs[] = {
    { "insert",     0, 0, c_tlb_insert,    "insert a new tlb entry" },
    { "i", KEY_INV+KEY_ABR, "insert" },
    { "in", KEY_INV+KEY_ABR, "insert" },
    { "invalidate", 0, 0, c_tlb_invalidate,"invalidate (part of) tlb" },
    { "lookup",     0, 0, c_tlb_lookup,    "lookup an address" },
    { "modify",     0, 0, c_tlb_modify,    "modify an entry" },
    { "show",       0, 0, c_tlb_show,      "show the tlb" },
    { "translate",  0, 0, c_tlb_translate, "translate an address" },
    { NULL },
  };

  cm_pcmd("tlb function, ", 0, tlbfuncs, 0);
}

void cmd_window(void)
{
  int winindex;
  int wintype;
  int subtype;

  static cmkeyword wtypes[] = {
    { "context",    0, (void*) wty_context,   0, "context registers" },
    { "cpu-regs",   0, (void*) wty_cpu,       0, "global cpu registers" },
    { "hexdump",    0, (void*) wty_hexdump,   0, "hexdump of phys. mem." },
    { "memory",     0, (void*) wty_memory,    0, "memory" },
    { "registers",  0, (void*) wty_registers, 0, "current registers" },
    { "terminal",   0, (void*) wty_terminal,  0, "console terminal" },
    { "tlb",        0, (void*) wty_tlb,       0, "translation buffer" },
    { "windows",    0, (void*) wty_windows,   0, "list of windows" },
    { NULL },
  };

  static cmkeyword asp[] = {
    { "user",     0, (void*) 0 },
    { "exec",     0, (void*) 1 },
    { "physical", 0, (void*) 8 },
    { NULL },
  };

  cm_pkey("window type, ", 0, wtypes, 0);
  wintype = VP2I(pval.kw->data);

  switch (wintype) {
  case wty_memory:
    cm_default("physical");
    cm_pkey("address space, ", 0, asp, 0);
    subtype = VP2I(pval.kw->data);
    break;
  case wty_context:
    cm_default("user");
    subtype = parse_cpu_level();
    break;
  default:
    subtype = 0;
    break;
  }

  cm_confirm();
  winindex = w_open(wintype, subtype);
  if (winindex != 0) {
    switch (wintype) {
    case wty_registers:
      w_setinput(winindex, wi_reg);
      break;
    case wty_terminal:
      w_setinput(winindex, uart_input);
      break;
    }
  }
}

void cmd_step(void)
{
  int i, stat;

  cm_default("1");
  cm_pnum("number of instructions", 0, 10);
  i = (int) pval.num.number;

  cm_confirm();

  if (bg_is_running()) {
    printf("Can't single-step when the CPU is running.\n");
    return;
  }
  
  if (i > 0) {
    while (i-- > 0) {
      stat = cpu_execute();
      if (stat != 0)
	break;
    }

    if (stat != 0)
      printf("  return = %d\n", stat);
  }
}

static cmkeyword cmds[] = {
  { "close",    0,      0, cmd_close,    "close a window" },
  { "exit",	0,	0, cmd_exit,     "exits program" },
  { "halt",     0,      0, cmd_halt,     "halt the cpu" },
  { "help",	0,	0, cmd_help,     "gives help" },
  { "load",     0,      0, cmd_load,     "load file into mem" },
  { "quit",    KEY_INV, 0, cmd_exit,     NULL },
  { "run",      0,      0, cmd_run,      "start the cpu" },
  { "set",      0,      0, cmd_set,      "sets things" },
  { "show",     0,      0, cmd_show,     "shows things" },
  { "step",     0,      0, cmd_step,     "single-step cpu" },
  { "tlb",      0,      0, cmd_tlb,      "manipulate the tlb" },
  { "window",   0,      0, cmd_window,   "manipulate windows" },
  { NULL },
};

void toploop(void)
{
  for (;;) {
    cm_prompt("hexsim> ");
    cm_pcmd("Command, ", 0, cmds, 0);
  }
}
