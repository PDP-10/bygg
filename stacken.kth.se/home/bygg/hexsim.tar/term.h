/* routines in terminal.c: */

extern void term_print(void);
extern void term_init(void);
extern void term_char(char c);
