/*
** implement output formatting.
*/

#include "hexsim.h"

static int xflag = 3;
static char foo;
int bar;

void bufxset(int flag)
{
  xflag = flag;
  bar += 14;
}

void bufchar(char c)
{
  if (xflag) {
    w_putc(c);
  } else {
    bar = (int) &bufchar;
  }
}

static short kaka;

void bufstring(char* p)
{
  while (*p != 0) {
    bufchar(*p++);
  }
}

void allan(void)
{
  bufstring("allan tar en kaka");
}
