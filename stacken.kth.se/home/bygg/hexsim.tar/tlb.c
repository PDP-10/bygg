/* tlb.c -- implements the Translation Buffer. */

#include "hexsim.h"

/*
 *  The page size is 8192 octets.  This means that we use 13 bits
 *  as the in-page address.
 */

#define TLBSIZE 32		/* Must be a power of 2. */
#define TLBMASK (TLBSIZE - 1)	/* (this is why) */

struct tlb_entry {
  uint64_t tlb_tag;
#   define TLB_TAG_VALID 0x0000000000000001ULL
#   define TLB_TAG_EXEC  0x0000000000000002ULL
#   define TLB_TAG_PAGE  0xffffffffffffe000ULL
  uint64_t tlb_data;
#   define TLB_DATA_BITS 0x0000000000000fffULL
#   define TLB_DATA_PAGE 0xffffffffffffe000ULL
} tlb[TLBSIZE];

uint8_t tlb_next;

/*
 *  Translate a virtual address in user (level==0) or exec (level > 0)
 *  address space to a physical address.  If it is not in the tlb,
 *  follow the paging pointers and create a new tlb entry, at offset
 *  tlb_next, and bump it.  Returns 0 if all is well, else returns
 *  a page fault code, with result being set to the info.
 */ 

int tlb_translate(hexaword addr, int level, int access,
		  hexaword* result)
{
  static struct {
    hexaword mask;
    uint8_t bits;
    uint8_t shift;
  } split[3] = {
    { 0x0000001f00000000ULL,  5, 32 }, /* Section. */
    { 0x00000000ff800000ULL,  9, 23 }, /* Super-page. */
    { 0x00000000007fe000ULL, 10, 13 }, /* Page. */
  };

  int i;
  uint16_t bits;
  uint16_t offset;
  hexaword paddr;
  hexaword pptr;

  i = tlb_lookup(addr, level);

  if (i >= 0) {
    *result = (tlb[i].tlb_data & TLB_DATA_PAGE) + (addr & ~TLB_DATA_PAGE);
    bits = tlb[i].tlb_data & TLB_DATA_BITS;
    goto found;
  }

  if (addr & 0xffffffe000000000ULL) /* Outside what we implement? */
    return PFC_OUTOFBOUNDS;	/* Yes, page fault. */

  if (level > 0)
    paddr = EBR;
  else
    paddr = UBR;

  paddr &= ~0xff;		/* First table is 32 entries of 64 bits. */
  bits = 0x370;			/* All bits to start with. */

  for (i = 0; i < 3; i += 1) {
    offset = (addr & split[i].mask) >> split[i].shift;
    if (mem_read(8, ASP_PHYS, paddr + 8 * offset, &pptr) != MST_OK)
      return PFC_PHYSICAL_NXM;

    switch (pptr & 3) {
    case 0:			/* No access. */
      return PFC_NOMEM;
    case 2:			/* Not-in-mem. */
      return PFC_NOTINCORE;
    case 3:			/* Shared/indirect. */
      return PFC_NOT_IMPLEMENT;
    }

    bits &= pptr;		/* Collect bits. */
    paddr = pptr & 0xfffffffffffff000ULL;
  }

  tlb_insert(addr, level, paddr, bits);
  *result = paddr + (addr & 0x1fff);

 found:

  switch (access) {
  case TLB_ACC_EXECUTE:
    if (!(bits & 0x040))
      return PFC_NOEXEC;
    break;
  case TLB_ACC_WRITE:
    if (!(bits & 0x020))
      return PFC_NOWRITE;
    break;
  default:
    break;
  }
  
  return PFC_OK;
}

/*
 *  Lookup a virtual address, return tlb offset if found, -1 if not.
 */

int tlb_lookup(hexaword addr, uint8_t level)
{
  int i;
  hexaword tag;

  tag = addr & TLB_TAG_PAGE;
  if (level > 0)
    tag |= TLB_TAG_EXEC;
  tag |= TLB_TAG_VALID;

  i = tlb_next + TLBSIZE;
  while (i-- > tlb_next) {
    if (tlb[i & TLBMASK].tlb_tag == tag)
      return i & TLBMASK;
  }

  return -1;
}

/*
 *  Insert a new entry at offset tlb_next.
 */

void tlb_insert(hexaword addr, uint8_t level, hexaword value, uint16_t bits)
{
  hexaword tag;
  
  tag = addr & TLB_TAG_PAGE;
  if (level > 0)
    tag |= TLB_TAG_EXEC;
  tag |= TLB_TAG_VALID;

  tlb[tlb_next & TLBMASK].tlb_tag = tag;
  tlb[tlb_next & TLBMASK].tlb_data = value & TLB_TAG_PAGE;
  tlb[tlb_next & TLBMASK].tlb_data |= (bits & TLB_DATA_BITS);
  tlb_next = (tlb_next + 1) & TLBMASK;

  wc_tlb();
}

/*
 *  Invalidate the whole tlb.
 */

void tlb_invalidate_all(void)
{
  int i;

  for (i = 0; i < TLBSIZE; i += 1)
    tlb[i].tlb_tag &= ~TLB_TAG_VALID;

  wc_tlb();
}

/*
 *  Invalidate all user entries in the tlb.
 */

void tlb_invalidate_user(void)
{
  int i;

  for (i = 0; i < TLBSIZE; i += 1) {
    if (!(tlb[i].tlb_tag & TLB_TAG_EXEC))
      tlb[i].tlb_tag &= ~TLB_TAG_VALID;
  }

  wc_tlb();
}

/*
 *  Modify a tlb entry (bits).
 */

void tlb_modify(int num, int func, uint16_t bits)
{
  struct tlb_entry* t = &tlb[num & TLBMASK];
  
  if (func == TLB_MODIFY_FUNC_CLEAR) {
    t->tlb_data &= ~bits;
  } else {
    t->tlb_data |= bits;
  }

  wc_tlb();
}

/*
 *  Print a single entry.
 */

void tlb_print(int num)
{
  struct tlb_entry* t = &tlb[num & TLBMASK];
  uint16_t bits = t->tlb_data & TLB_DATA_BITS;

  if (num == tlb_next)
    bufchar('>');
  else
    bufchar(' ');
  if (num < 10)
    bufchar(' ');
  bufnumber(num);
  bufchar(' ');
  if (t->tlb_tag & TLB_TAG_VALID)
    bufchar('V');
  else
    bufchar(' ');
  if (t->tlb_tag & TLB_TAG_EXEC)
    bufstring("E ");
  else
    bufstring("U ");

  bufchar(bits & TLB_BIT_MODIFIED?  'M' : ' ');
  bufchar(bits & TLB_BIT_WRITE?     'W' : ' ');
  bufchar(bits & TLB_BIT_EXECUTE?   'X' : ' ');
  bufchar(' ');
  bufchar(bits & TLB_BIT_CACHEABLE? 'C' : ' ');
  bufchar(bits & TLB_BIT_KEEP?      'K' : ' ');
  bufstring("  ");

  bufhw(t->tlb_tag & TLB_TAG_PAGE);
  bufstring("  ");

  bufhw(t->tlb_data & TLB_DATA_PAGE);
  bufnewline();
}

/*
 *  Show the whole tlb.
 */

void tlb_show(void)
{
  int i;

  /*        ">nn VE CK XWM  01234567,,01234567  01234567,,01234567" */
  bufstring("   flags/bits     virtual address    physical address\n\n");

  for (i = 0; i < TLBSIZE; i += 1) {
    tlb_print(i);
  }
}
