/*
 *  Global routines in tlb.c
 */

/* Types of access: */

enum {
  TLB_ACC_READ,			/* Read reference. */
  TLB_ACC_WRITE,		/* Write reference. */
  TLB_ACC_EXECUTE,		/* Execute reference. */
};

#define TLB_BIT_CACHEABLE 0x200
#define TLB_BIT_KEEP      0x100

#define TLB_BIT_EXECUTE   0x040
#define TLB_BIT_WRITE     0x020
#define TLB_BIT_MODIFIED  0x010

#define TLB_MODIFY_FUNC_CLEAR 0
#define TLB_MODIFY_FUNC_SET   1

/*
 *  Page fault codes:
 */

#define PFC_OK            0	/* All OK. */
#define PFC_NOMEM         1	/* No memory. */
#define PFC_NOWRITE       2	/* No write access. */
#define PFC_NOEXEC	  3	/* No execute access. */
#define PFC_NOTINCORE     4	/* Not in core (paged out). */

#define PFC_OUTOFBOUNDS   10	/* Virtual address out of bounds. */
#define PFC_PHYSICAL_NXM  11	/* Physical NXM (should trap to CPU). */
#define PFC_NOT_IMPLEMENT 12	/* Not (yet) implemented. */

/*
 *  Routines:
 */

extern int  tlb_translate(hexaword addr, int level, int access,
			  hexaword* result);
extern int  tlb_lookup(hexaword addr, uint8_t level);
extern void tlb_insert(hexaword addr, uint8_t level,
		       hexaword value, uint16_t bits);
extern void tlb_invalidate_all(void);
extern void tlb_invalidate_user(void);
extern void tlb_modify(int num, int func, uint16_t bits);
extern void tlb_print_bits(uint8_t bits);
extern void tlb_print(int num);
extern void tlb_show(void);
