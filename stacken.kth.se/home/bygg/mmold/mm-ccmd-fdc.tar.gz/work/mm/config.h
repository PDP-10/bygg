/*
 * Copyright (c) 1986-2002 by The Trustees of Columbia University
 * in the City of New York.  Permission is granted to any individual or
 * institution to use, copy, or redistribute this software so long as it
 * is not sold for profit, provided this copyright notice is retained.
 */

#ifdef RCSID
#ifndef lint
static char *config_rcsid = "$Header: /src/acis/mm/src/RCS/config.h,v 2.7 1997/10/21 19:33:32 howie Exp $";
#endif
#endif /* RCSID */

/*
 * Configuration file for cunixa, cunixb, cunixd
 */

/* First get general sys-dependent stuff for appropriate OS
 */
#include "sysh/s-sun58.h"

/* Now apply any desired modifications to stuff from s-*.h
 */
#undef HAVE_GETHOSTBYNAME	/* undef'd in original s-sol25.h file */
#define HAVE_UNAME		/* def'd ditto */
#undef  SPOOL_DIRECTORY
#define SPOOL_DIRECTORY "/var/spool/mail"


/* Now set anything from pathnames.h where we don't like the defaults
 */


/* Now apply certain config settings that used to be in the s-*.h files
 * but really are installation specific.  For a full list of these, see
 * the file config.h-generic.
 */
/*#define HOSTNAME "myhost"*/		/* local hostname if cannot lookup */
/*#define LOCALDOMAIN ".mydomain.edu"*/	/* local domain if cannot lookup  */
/*#define HIDDENNET "mailhost.mydomain.edu"*/	/* fake outgoing host name */
#define FORWARD_FILE ".forward"		/* .forward file name if used */
#define GNUEMACS "emacs"		/* name of GNU Emacs if present */
#undef HAVE_YP				/* use yp? */
#define HAVE_NFS			/* NFS used for some mail files? */
#undef HAVE_QUOTAS			/* have and use quota support? */

#define USAGE				/* Compile usage logging */
