typedef int (* cmprocptr)();
typedef int keyval;
