/*
 * Copyright (c) 1986, 1990 by The Trustees of Columbia University in
 * the City of New York.  Permission is granted to any individual or
 * institution to use, copy, or redistribute this software so long as it
 * is not sold for profit, provided this copyright notice is retained.
 */

#ifdef RCSID
#ifndef lint
static char *babyl_rcsid = "$Header: /w/src1/sun4.bin/cucca/mm/RCS/babyl.h,v 2.1 90/10/04 18:23:33 melissa Exp $";
#endif
#endif /* RCSID */

struct flagword {
    char *name;
    u_long flag;
};

