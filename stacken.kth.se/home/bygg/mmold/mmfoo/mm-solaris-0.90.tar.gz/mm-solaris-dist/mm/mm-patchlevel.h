/*
 * Copyright (c) 1986, 1990 by The Trustees of Columbia University in
 * the City of New York.  Permission is granted to any individual or
 * institution to use, copy, or redistribute this software so long as it
 * is not sold for profit, provided this copyright notice is retained.
 */

/*
 * update MM_PATCH here when sending out official patches to the current 
 * release.  Don't forget to send diffs for this file in the patch file.
 */

#define MM_PATCH 4
