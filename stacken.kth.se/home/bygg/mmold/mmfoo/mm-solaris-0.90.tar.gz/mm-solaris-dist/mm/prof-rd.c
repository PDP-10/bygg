/*
 * Copyright (c) 1986, 1987, 1988 by The Trustees of Columbia University
 * in the City of New York.  Permission is granted to any individual or
 * institution to use, copy, or redistribute this software so long as it
 * is not sold for profit, provided this copyright notice is retained.
 */

#define  babyl_probe	null
#define  babyl_open	null
#define  babyl_close	null
#define  babyl_lock	null
#define  babyl_unlock	null
#define  babyl_read	null
#define  babyl_write	null
#define  babyl_same_p	null
#define  babyl_backup	null
#define  babyl_restore	null
#define  babyl_delete	null
#define  babyl_append	null
#define  babyl_rdmsg	null
#define  babyl_wrmsg	null
#define  babyl_rdidx	null
#define  babyl_wridx	null
#define  mbox_probe	null
#define  mbox_open	null
#define  mbox_close	null
#define  mbox_lock	null
#define  mbox_unlock	null
#define  mbox_read	null
#define  mbox_write	null
#define  mbox_same_p	null
#define  mbox_backup	null
#define  mbox_restore	null
#define  mbox_delete	null
#define  mbox_append	null
#define  mbox_rdmsg	null
#define  mbox_wrmsg	null
#define  mbox_rdidx	null
#define  mbox_wridx	null
#define  mh_probe	null
#define  mh_open	null
#define  mh_close	null
#define  mh_lock	null
#define  mh_unlock	null
#define  mh_read	null
#define  mh_write	null
#define  mh_same_p	null
#define  mh_backup	null
#define  mh_restore	null
#define  mh_delete	null
#define  mh_append	null
#define  mh_rdmsg	null
#define  mh_wrmsg	null
#define  mh_rdidx	null
#define  mh_wridx	null
#define  mtxt_probe	null
#define  mtxt_open	null
#define  mtxt_close	null
#define  mtxt_lock	null
#define  mtxt_unlock	null
#define  mtxt_read	null
#define  mtxt_write	null
#define  mtxt_same_p	null
#define  mtxt_backup	null
#define  mtxt_restore	null
#define  mtxt_delete	null
#define  mtxt_append	null
#define  mtxt_rdmsg	null
#define  mtxt_wrmsg	null
#define  mtxt_rdidx	null
#define  mtxt_wridx	null
#define  pop2_probe	null
#define  pop2_open	null
#define  pop2_close	null
#define  pop2_lock	null
#define  pop2_unlock	null
#define  pop2_read	null
#define  pop2_write	null
#define  pop2_same_p	null
#define  pop2_backup	null
#define  pop2_restore	null
#define  pop2_delete	null
#define  pop2_append	null
#define  pop2_rdmsg	null
#define  pop2_wrmsg	null
#define  pop2_rdidx	null
#define  pop2_wridx	null
#define  pop3_probe	null
#define  pop3_open	null
#define  pop3_close	null
#define  pop3_lock	null
#define  pop3_unlock	null
#define  pop3_read	null
#define  pop3_write	null
#define  pop3_same_p	null
#define  pop3_backup	null
#define  pop3_restore	null
#define  pop3_delete	null
#define  pop3_append	null
#define  pop3_rdmsg	null
#define  pop3_wrmsg	null
#define  pop3_rdidx	null
#define  pop3_wridx	null

#include "rd.c"


null() {}
